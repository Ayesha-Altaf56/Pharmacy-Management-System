'use strict';

const { getConnection } = require('../config/oracledb');

// GET all users
async function getAllUsers(req, res) {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT ID, NAME, USERNAME, ROLE, DOB, PHONE, ADDRESS, SALARY, IS_ACTIVE, CREATED_AT FROM USERS ORDER BY ID ASC`,
      [],
      { outFormat: 4002 }
    );
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching users:', err);
    res.status(500).json({ message: 'Error fetching users' });
  } finally {
    if (conn) await conn.close();
  }
}

// ADD new user
async function addUser(req, res) {
  const { name, username, password, role, dob, phone, address, salary } = req.body;
  if (!name || !username || !password || !role) {
    return res.status(400).json({ message: 'Name, Username, Password, and Role are required' });
  }

  let conn;
  try {
    conn = await getConnection();
    await conn.execute(
      `INSERT INTO USERS (NAME, USERNAME, PASSWORD, ROLE, DOB, PHONE, ADDRESS, SALARY)
       VALUES (:name, :username, :password, :role, TO_DATE(:dob, 'YYYY-MM-DD'), :phone, :address, :salary)`,
      {
        name, username, password, role,
        dob: dob || null,
        phone: phone || null,
        address: address || null,
        salary: salary || 0
      },
      { autoCommit: true }
    );
    res.json({ message: 'User added successfully' });
  } catch (err) {
    console.error('Error adding user:', err);
    res.status(500).json({ message: 'Error adding user' });
  } finally {
    if (conn) await conn.close();
  }
}

// UPDATE user
async function updateUser(req, res) {
  const { id } = req.params;
  const { name, role, phone, address, salary, is_active } = req.body;

  let conn;
  try {
    conn = await getConnection();
    await conn.execute(
      `UPDATE USERS SET 
       NAME = :name, 
       ROLE = :role, 
       PHONE = :phone, 
       ADDRESS = :address, 
       SALARY = :salary,
       IS_ACTIVE = :isActive
       WHERE ID = :id`,
      {
        name, role, phone, address, salary,
        isActive: is_active,
        id
      },
      { autoCommit: true }
    );
    res.json({ message: 'User updated successfully' });
  } catch (err) {
    console.error('Error updating user:', err);
    res.status(500).json({ message: 'Error updating user' });
  } finally {
    if (conn) await conn.close();
  }
}

// DELETE user
async function deleteUser(req, res) {
  const { id } = req.params;
  let conn;
  try {
    conn = await getConnection();
    await conn.execute(
      `DELETE FROM USERS WHERE ID = :id`,
      [id],
      { autoCommit: true }
    );
    res.json({ message: 'User deleted successfully' });
  } catch (err) {
    console.error('Error deleting user:', err);
    res.status(500).json({ message: 'Error deleting user' });
  } finally {
    if (conn) await conn.close();
  }
}

module.exports = { getAllUsers, addUser, updateUser, deleteUser };