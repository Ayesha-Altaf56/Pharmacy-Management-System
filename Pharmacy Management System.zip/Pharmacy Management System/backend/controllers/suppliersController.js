const { getConnection } = require('../config/oracledb');
const Supplier = require('../models/mongo/Supplier');

const getAllSuppliers = async (req, res) => {
    let conn;
    try {
        conn = await getConnection();
        const result = await conn.execute('SELECT * FROM SUPPLIERS ORDER BY NAME ASC');

        if (result.rows && result.rows.length > 0) {
            return res.status(200).json(result.rows);
        }

        // Fallback to Mongo
        const mongoSuppliers = await Supplier.find({}).sort({ name: 1 });
        res.status(200).json(mongoSuppliers);

    } catch (error) {
        console.error('Error fetching suppliers:', error);
        res.status(500).json({ message: 'Error fetching suppliers' });
    } finally {
        if (conn) {
            try {
                await conn.close();
            } catch (e) {
                console.error('Error closing Oracle connection:', e);
            }
        }
    }
};

const addSupplier = async (req, res) => {
    const { name, contact_person, email, phone, address } = req.body;

    if (!name) {
        return res.status(400).json({ message: 'Supplier name is required' });
    }

    let conn;
    try {
        // 1. Oracle
        conn = await getConnection();
        await conn.execute(
            `INSERT INTO SUPPLIERS (NAME, CONTACT_PERSON, EMAIL, PHONE, ADDRESS) 
       VALUES (:name, :contact_person, :email, :phone, :address)`,
            { name, contact_person, email, phone, address },
            { autoCommit: true }
        );

        // 2. Mongo
        const newSupplier = new Supplier({ name, contact_person, email, phone, address });
        await newSupplier.save();

        res.status(201).json({ message: 'Supplier added successfully' });

    } catch (error) {
        console.error('Error adding supplier:', error);
        res.status(500).json({ message: 'Error adding supplier' });
    } finally {
        if (conn) {
            try {
                await conn.close();
            } catch (e) {
                console.error('Error closing Oracle connection:', e);
            }
        }
    }
};

const deleteSupplier = async (req, res) => {
    const { id } = req.params; // Expecting Oracle ID for now, or we can use Name if ID is tricky across DBs. 
    // Let's assume we pass Name for consistency across both DBs for now, or ID if we handle mapping.
    // Given the dual DB nature, ID might be different. Let's use Name for delete/update for simplicity if unique?
    // Or better, pass both or handle separately.
    // For this project, let's try to use ID from Oracle as primary reference in frontend if possible, 
    // but Mongo has _id.
    // Let's use ID for Oracle and Name for Mongo delete? Or just Name?
    // Let's stick to ID for Oracle and try to find by Name in Mongo?
    // Actually, let's use ID.

    // WAIT: The user request didn't specify ID management details. 
    // Let's use ID for SQL and _id for Mongo? No, that's messy.
    // Let's use ID for SQL and delete by Name in Mongo (assuming unique names).

    // Re-reading: "Supplier Management: Add/Edit/Delete suppliers".

    // Let's use ID for the route param.

    let conn;
    try {
        conn = await getConnection();

        // Get name first to delete from Mongo
        const result = await conn.execute('SELECT NAME FROM SUPPLIERS WHERE ID = :id', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Supplier not found' });
        }
        const name = result.rows[0].NAME;

        // Delete from Oracle
        await conn.execute('DELETE FROM SUPPLIERS WHERE ID = :id', [id], { autoCommit: true });

        // Delete from Mongo
        await Supplier.deleteOne({ name: name });

        res.status(200).json({ message: 'Supplier deleted successfully' });

    } catch (error) {
        console.error('Error deleting supplier:', error);
        res.status(500).json({ message: 'Error deleting supplier' });
    } finally {
        if (conn) {
            try {
                await conn.close();
            } catch (e) {
                console.error('Error closing Oracle connection:', e);
            }
        }
    }
};

module.exports = { getAllSuppliers, addSupplier, deleteSupplier };
