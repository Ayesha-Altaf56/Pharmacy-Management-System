'use strict';

const { getConnection } = require('../config/oracledb');
const { MessageHistory } = require('../models/mongo/MessageHistory');

// GET all message history records
async function getAllMessageHistory(req, res) {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute('SELECT * FROM MESSAGE_HISTORY');

    if (result.rows && result.rows.length > 0) {
      return res.json({ status: true, data: result.rows });
    }

    // Fallback to MongoDB
    console.log('OracleDB returned 0 message history records, fetching from MongoDB...');
    const mongoMessages = await MessageHistory.find({});
    return res.json({ status: true, data: mongoMessages });

  } catch (err) {
    console.error('Error fetching message history from Oracle:', err.message);

    // Fallback to MongoDB on error
    try {
      console.log('Attempting fetch from MongoDB...');
      const mongoMessages = await MessageHistory.find({});
      return res.json({ status: true, data: mongoMessages });
    } catch (mongoErr) {
      console.error('Error fetching message history from MongoDB:', mongoErr);
      return res.status(500).json({
        status: false,
        message: 'Failed to fetch message history',
        error: err.message
      });
    }
  } finally {
    if (conn) {
      try {
        await conn.close();
      } catch (e) {
        console.error('Error closing Oracle connection:', e);
      }
    }
  }
}

// ADD a new message history record
async function addMessageHistory(req, res) {
  const { from, to, text } = req.body;

  // Input validation
  if (!from || !to || !text) {
    return res.status(400).json({
      status: false,
      message: 'All fields (from, to, text) are required'
    });
  }

  let conn;
  try {
    conn = await getConnection();
    await conn.execute(
      `INSERT INTO MESSAGE_HISTORY (MESSAGE_FROM, MESSAGE_TO, MESSAGE_TEXT)
       VALUES (:from, :to, :text)`,
      {
        from,
        to,
        text
      },
      { autoCommit: true }
    );

    res.json({
      status: true,
      message: 'Message history added successfully'
    });
  } catch (err) {
    console.error('Error adding message history:', err);
    res.status(500).json({
      status: false,
      message: 'Failed to add message history',
      error: err.message
    });
  } finally {
    if (conn) await conn.close();
  }
}

module.exports = { getAllMessageHistory, addMessageHistory };
