const { getConnection } = require('../config/oracledb');
const { Company } = require('../models/mongo/Company');

// --- CRUD Operations ---

const getAllCompanies = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute('SELECT * FROM COMPANIES ORDER BY NAME ASC', [], { outFormat: 4002 });
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching companies:', err);
    res.status(500).json({ message: 'Error fetching companies' });
  } finally {
    if (conn) await conn.close();
  }
};

const addCompany = async (req, res) => {
  const { name, address, phone } = req.body;
  let conn;
  try {
    conn = await getConnection();
    // Oracle
    await conn.execute(
      'INSERT INTO COMPANIES (NAME, ADDRESS, PHONE) VALUES (:name, :address, :phone)',
      { name, address, phone },
      { autoCommit: true }
    );

    // Mongo (Best effort)
    try {
      const newCompany = new Company({ name, address, phone });
      await newCompany.save();
    } catch (mongoErr) {
      console.error('Mongo save failed:', mongoErr);
    }

    res.status(201).json({ message: 'Company added successfully' });
  } catch (err) {
    console.error('Error adding company:', err);
    res.status(500).json({ message: 'Error adding company' });
  } finally {
    if (conn) await conn.close();
  }
};

const updateCompany = async (req, res) => {
  const { id } = req.params;
  const { name, address, phone } = req.body;
  let conn;
  try {
    conn = await getConnection();
    // Oracle
    await conn.execute(
      'UPDATE COMPANIES SET NAME = :name, ADDRESS = :address, PHONE = :phone WHERE ID = :id',
      { name, address, phone, id },
      { autoCommit: true }
    );

    // Mongo (Update by name as ID might differ, or skip if strict sync not needed)
    // Ideally we sync by a unique identifier. Here assuming Name is unique-ish or we just update Oracle primarily.
    try {
      await Company.findOneAndUpdate({ name: name }, { address, phone });
    } catch (mongoErr) {
      console.error('Mongo update failed:', mongoErr);
    }

    res.json({ message: 'Company updated successfully' });
  } catch (err) {
    console.error('Error updating company:', err);
    res.status(500).json({ message: 'Error updating company' });
  } finally {
    if (conn) await conn.close();
  }
};

const deleteCompany = async (req, res) => {
  const { id } = req.params;
  let conn;
  try {
    conn = await getConnection();

    // Get name first to delete from Mongo
    const result = await conn.execute('SELECT NAME FROM COMPANIES WHERE ID = :id', [id], { outFormat: 4002 });
    const companyName = result.rows[0]?.NAME;

    // Oracle
    await conn.execute('DELETE FROM COMPANIES WHERE ID = :id', [id], { autoCommit: true });

    // Mongo
    if (companyName) {
      try {
        await Company.deleteOne({ name: companyName });
      } catch (mongoErr) {
        console.error('Mongo delete failed:', mongoErr);
      }
    }

    res.json({ message: 'Company deleted successfully' });
  } catch (err) {
    console.error('Error deleting company:', err);
    res.status(500).json({ message: 'Error deleting company' });
  } finally {
    if (conn) await conn.close();
  }
};

// --- Statistics & History ---

const getCompanyStats = async (req, res) => {
  const { name } = req.query; // Company Name
  if (!name) return res.status(400).json({ message: 'Company name is required' });

  let conn;
  try {
    conn = await getConnection();

    // 1. Total Stock & Products Count
    const stockResult = await conn.execute(
      `SELECT COUNT(*) AS PRODUCT_COUNT, SUM(QUANTITY) AS TOTAL_STOCK 
       FROM DRUGS d
       JOIN COMPANIES c ON d.COMPANY_ID = c.ID
       WHERE LOWER(c.NAME) = LOWER(:name)`,
      [name],
      { outFormat: 4002 }
    );

    // 2. Total Sales Value (Join History with Drugs)
    const salesResult = await conn.execute(
      `SELECT SUM(h.QUANTITY * h.PRICE) AS TOTAL_SALES
       FROM HISTORY_SALES h
       JOIN DRUGS d ON h.BARCODE = d.BARCODE
       JOIN COMPANIES c ON d.COMPANY_ID = c.ID
       WHERE LOWER(c.NAME) = LOWER(:name)`,
      [name],
      { outFormat: 4002 }
    );

    const stats = {
      productCount: stockResult.rows[0]?.PRODUCT_COUNT || 0,
      totalStock: stockResult.rows[0]?.TOTAL_STOCK || 0,
      totalSales: salesResult.rows[0]?.TOTAL_SALES || 0
    };

    res.json(stats);
  } catch (err) {
    console.error('Error fetching company stats:', err);
    res.status(500).json({ message: 'Error fetching company stats' });
  } finally {
    if (conn) await conn.close();
  }
};

const getCompanyPurchaseHistory = async (req, res) => {
  const { name } = req.query;
  if (!name) return res.status(400).json({ message: 'Company name is required' });

  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT p.*, d.NAME AS DRUG_NAME 
       FROM PURCHASES p
       JOIN COMPANIES c ON p.COMPANY_ID = c.ID
       JOIN DRUGS d ON p.BARCODE = d.BARCODE
       WHERE LOWER(c.NAME) = LOWER(:name) 
       ORDER BY p.PURCHASE_DATE DESC`,
      [name],
      { outFormat: 4002 }
    );
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching purchase history:', err);
    res.status(500).json({ message: 'Error fetching purchase history' });
  } finally {
    if (conn) await conn.close();
  }
};

module.exports = {
  getAllCompanies,
  addCompany,
  updateCompany,
  deleteCompany,
  getCompanyStats,
  getCompanyPurchaseHistory
};
