const oracledb = require('oracledb');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { getConnection } = require('../config/oracledb');
const { Login } = require('../models/mongo/Login');

const JWT_SECRET = process.env.JWT_SECRET || 'pharmacy_app_secret_key_123';

// POST /login - authenticate or create user
async function login(req, res) {
  const { username, password, role } = req.body; // Added role

  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }

  // Default to 'user' if not provided, but frontend should provide 'admin' or 'customer'
  const userType = role || 'user';

  let conn;
  try {
    // FORCE FALLBACK TO MONGO (Temporary Fix for Oracle Locks)
    throw new Error('Forcing MongoDB Login');
    conn = await getConnection();

    // Check if user exists
    const result = await conn.execute(
      `SELECT * FROM LOGIN WHERE USERNAME = :bUsername`,
      { bUsername: username },
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );

    const now = new Date();

    if (result.rows.length === 0) {
      // User does not exist → create new user with hashed password
      const hashed = await bcrypt.hash(password, 10);
      await conn.execute(
        `INSERT INTO LOGIN (USERNAME, PASSWORD, USER_TYPE, LAST_LOGIN_DATE, LAST_LOGIN_TIME)
         VALUES (:bUsername, :bPassword, :bUserType, :bDate, :bTime)`,
        {
          bUsername: username,
          bPassword: hashed,
          bUserType: userType, // Use provided role
          bDate: now,
          bTime: now.toLocaleTimeString()
        },
        { autoCommit: true }
      );

      // create JWT
      const token = jwt.sign({ username, userType: userType }, JWT_SECRET, { expiresIn: '8h' });

      return res.status(201).json({ message: 'New user created and logged in successfully', username, userType, token });
    }

    // User exists → check password (supports hashed passwords)
    const user = result.rows[0];
    const stored = user.PASSWORD;
    const passwordMatches = await bcrypt.compare(password, stored);
    if (!passwordMatches) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    // Update last login date/time
    // SKIP UPDATE to prevent locking issues
    /*
    await conn.execute(
      `UPDATE LOGIN
       SET LAST_LOGIN_DATE = :bDate,
       LAST_LOGIN_TIME = :bTime
       WHERE USERNAME = :bUsername`,
      {
        bDate: now,
        bTime: now.toLocaleTimeString(),
        bUsername: username
      },
      { autoCommit: true }
    );
    */

    // Issue JWT
    const token = jwt.sign({ username: user.USERNAME, userType: user.USER_TYPE }, JWT_SECRET, { expiresIn: '8h' });

    res.status(200).json({
      message: 'Login successful',
      username: user.USERNAME,
      userType: user.USER_TYPE,
      lastLoginDate: user.LAST_LOGIN_DATE,
      lastLoginTime: user.LAST_LOGIN_TIME,
      token
    });

  } catch (err) {
    console.error('[0] Login error (Oracle):', err.message);

    // Fallback to MongoDB for authentication (Read-Only)
    try {
      console.log('Attempting login via MongoDB...');
      const mongoUser = await Login.findOne({ username });

      if (!mongoUser) {
        // If Oracle failed and user not in Mongo, we can't create them safely without Oracle
        return res.status(500).json({ error: 'Login failed (Database unavailable)', details: err.message });
      }

      const passwordMatches = await bcrypt.compare(password, mongoUser.password);
      if (!passwordMatches) {
        return res.status(400).json({ error: 'Invalid credentials' });
      }

      // Issue JWT based on Mongo user
      const token = jwt.sign({ username: mongoUser.username, userType: mongoUser.type }, JWT_SECRET, { expiresIn: '8h' });

      return res.status(200).json({
        message: 'Login successful (Backup Mode)',
        username: mongoUser.username,
        userType: mongoUser.type,
        lastLoginDate: mongoUser.date,
        lastLoginTime: mongoUser.time,
        token
      });

    } catch (mongoErr) {
      console.error('Login error (MongoDB):', mongoErr);
      return res.status(500).json({ error: 'Server error', details: err.message });
    }

  } finally {
    if (conn) {
      try {
        await conn.close();
      } catch (e) {
        console.error('Error closing Oracle connection:', e);
      }
    }
  }
}

// GET all login records
async function getAllLoginRecords(req, res) {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      'SELECT * FROM LOGIN',
      {},
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );

    if (result.rows && result.rows.length > 0) {
      return res.status(200).json(result.rows);
    }

    // Fallback to MongoDB
    console.log('OracleDB returned 0 login records, fetching from MongoDB...');
    const mongoLogins = await Login.find({});
    return res.status(200).json(mongoLogins);

  } catch (err) {
    console.error('[0] Error fetching login records (Oracle):', err.message);

    // Fallback to MongoDB
    try {
      console.log('Attempting fetch from MongoDB...');
      const mongoLogins = await Login.find({});
      return res.status(200).json(mongoLogins);
    } catch (mongoErr) {
      console.error('Error fetching login records (MongoDB):', mongoErr);
      return res.status(500).json({ error: 'Server error', details: err.message });
    }
  } finally {
    if (conn) {
      try {
        await conn.close();
      } catch (e) {
        console.error('Error closing Oracle connection:', e);
      }
    }
  }
}

module.exports = { login, getAllLoginRecords };
