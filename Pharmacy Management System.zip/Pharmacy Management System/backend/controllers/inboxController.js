'use strict';

const { getConnection } = require('../config/oracledb');
const { Inbox } = require('../models/mongo/Inbox');

// GET inbox messages for a specific user
async function getInboxMessages(req, res) {
  const { user } = req.query; // Current user name
  if (!user) return res.status(400).json({ message: 'User is required' });

  let conn;
  try {
    conn = await getConnection();
    // If user is 'Admin', show all messages. Otherwise filter by recipient
    let query, binds;
    if (user.toLowerCase() === 'admin') {
      query = `SELECT * FROM INBOX ORDER BY ID DESC`;
      binds = {};
    } else {
      query = `SELECT * FROM INBOX WHERE LOWER(MESSAGE_TO) = LOWER(:username) OR LOWER(MESSAGE_TO) = 'all' ORDER BY ID DESC`;
      binds = { username: user };
    }

    const result = await conn.execute(query, binds, { outFormat: 4002 });
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching inbox:', err);
    res.status(500).json({ message: 'Error fetching inbox' });
  } finally {
    if (conn) await conn.close();
  }
}

// GET sent messages for a specific user
async function getSentMessages(req, res) {
  const { user } = req.query;
  if (!user) return res.status(400).json({ message: 'User is required' });

  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT * FROM INBOX WHERE LOWER(MESSAGE_FROM) = LOWER(:username) ORDER BY ID DESC`,
      { username: user }, // Use object for named bind
      { outFormat: 4002 }
    );
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching sent messages:', err);
    res.status(500).json({ message: 'Error fetching sent messages' });
  } finally {
    if (conn) await conn.close();
  }
}

// SEND a new message
async function sendMessage(req, res) {
  const { from, to, message } = req.body;
  if (!from || !to || !message) return res.status(400).json({ message: 'All fields are required' });

  let conn;
  try {
    conn = await getConnection();
    await conn.execute(
      `INSERT INTO INBOX (MESSAGE_FROM, MESSAGE_TO, MESSAGE_TEXT, DATE_SENT)
       VALUES (:sender, :recipient, :msg, CURRENT_TIMESTAMP)`,
      { sender: from, recipient: to, msg: message }, // Changed bind names to be safe
      { autoCommit: true }
    );
    res.json({ message: 'Message sent successfully' });
  } catch (err) {
    console.error('Error sending message:', err);
    res.status(500).json({ message: 'Error sending message' });
  } finally {
    if (conn) await conn.close();
  }
}

// DELETE a message
async function deleteMessage(req, res) {
  const { id } = req.params;
  let conn;
  try {
    conn = await getConnection();
    await conn.execute(
      `DELETE FROM INBOX WHERE ID = :msgId`,
      { msgId: id }, // Use object and safe name
      { autoCommit: true }
    );
    res.json({ message: 'Message deleted successfully' });
  } catch (err) {
    console.error('Error deleting message:', err);
    res.status(500).json({ message: 'Error deleting message' });
  } finally {
    if (conn) await conn.close();
  }
}

module.exports = { getInboxMessages, getSentMessages, sendMessage, deleteMessage };
