const { getConnection } = require('../config/oracledb');
const { HistorySales } = require('../models/mongo/HistorySales');

const getAllHistorySales = async (req, res) => {
  const { startDate, endDate, search } = req.query;
  let conn;
  let oracleResults = [];
  let mongoResults = [];

  // 1. Fetch from Oracle
  try {
    conn = await getConnection();
    let query = `
      SELECT h.*, d.NAME, d.TYPE, d.DOSE, (h.QUANTITY * h.PRICE) AS AMOUNT
      FROM HISTORY_SALES h
      JOIN DRUGS d ON h.BARCODE = d.BARCODE
      WHERE 1=1`;
    const binds = {};

    if (startDate) {
      query += ` AND h.SALE_DATE >= TO_TIMESTAMP(:startDate, 'YYYY-MM-DD"T"HH24:MI:SS.FF3"Z"')`;
      binds.startDate = new Date(startDate).toISOString();
    }
    if (endDate) {
      query += ` AND h.SALE_DATE <= TO_TIMESTAMP(:endDate, 'YYYY-MM-DD"T"HH24:MI:SS.FF3"Z"')`;
      binds.endDate = new Date(endDate).toISOString();
    }
    if (search) {
      query += ` AND (LOWER(d.NAME) LIKE '%' || :search || '%' OR LOWER(h.BARCODE) LIKE '%' || :search || '%')`;
      binds.search = search.toLowerCase();
    }

    query += ' ORDER BY h.SALE_DATE DESC';
    const result = await conn.execute(query, binds, { outFormat: 4002 });
    oracleResults = result.rows || [];
  } catch (error) {
    console.error('Error fetching sales history from Oracle:', error.message);
  } finally {
    if (conn) {
      try { await conn.close(); } catch (e) { console.error('Error closing Oracle connection:', e); }
    }
  }

  // 2. Fetch from MongoDB
  try {
    const mongoSearch = {};
    if (startDate || endDate) {
      mongoSearch.date = {};
      if (startDate) mongoSearch.date.$gte = new Date(startDate);
      if (endDate) mongoSearch.date.$lte = new Date(endDate);
    }
    if (search) {
      mongoSearch.$or = [
        { drugName: { $regex: search, $options: 'i' } },
        { barcode: { $regex: search, $options: 'i' } }
      ];
    }
    mongoResults = await HistorySales.find(mongoSearch).sort({ date: -1 });
  } catch (mongoErr) {
    console.error('Error fetching sales history from MongoDB:', mongoErr.message);
  }

  // 3. Merge and Deduplicate (Heuristic: same barcode, same quantity, same-ish time)
  // We prioritize Oracle records but include Mongo records that don't seem to be in Oracle
  const merged = [...oracleResults];

  const oracleFingerprints = new Set(oracleResults.map(r =>
    `${r.BARCODE}-${r.QUANTITY}-${new Date(r.SALE_DATE).getTime()}`
  ));

  mongoResults.forEach(m => {
    const fingerprint = `${m.barcode}-${m.quantity}-${new Date(m.date).getTime()}`;
    // If not obviously a duplicate, add it.
    // Also, we can use a small time window check, but for now simple fingerprint is okay.
    if (!oracleFingerprints.has(fingerprint)) {
      merged.push({
        ID: m._id,
        BARCODE: m.barcode,
        NAME: m.drugName,
        TYPE: m.type,
        DOSE: m.dose,
        QUANTITY: m.quantity,
        PRICE: m.price,
        AMOUNT: m.amount,
        SALE_DATE: m.date,
        SALE_TIME: m.time ? new Date(m.time).toLocaleTimeString() : null,
        USER_NAME: m.user_name || 'Admin'
      });
    }
  });

  // Final sort by date
  merged.sort((a, b) => new Date(b.SALE_DATE || b.date) - new Date(a.SALE_DATE || a.date));

  return res.status(200).json(merged);
};

const addHistorySale = async (req, res) => {
  const { userName, barcode, name, type, dose, quantity, price, amount, saleDate, saleTime } = req.body;

  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `INSERT INTO HISTORY_SALES (
        USER_NAME, BARCODE, QUANTITY, PRICE, SALE_DATE, SALE_TIME) 
       VALUES (
        :userName, :barcode, :quantity, :price, :saleDate, :saleTime)`,
      {
        userName, barcode, quantity, price,
        saleDate: new Date(saleDate),
        saleTime
      },
      { autoCommit: true }
    );
    res.status(201).send({ message: 'History sale added successfully', rowsAffected: result.rowsAffected });
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: 'Error adding history sale', error: error.message });
  } finally {
    if (conn) await conn.close();
  }
};

const deleteHistorySale = async (req, res) => {
  const { id } = req.params;
  let conn;
  let saleData = null;
  let isOracleId = !isNaN(id);

  try {
    // 1. Find the sale data first to know what to restore
    if (isOracleId) {
      try {
        conn = await getConnection();
        const oracleResult = await conn.execute(
          `SELECT * FROM HISTORY_SALES WHERE ID = :id`,
          [id],
          { outFormat: 4002 }
        );
        if (oracleResult.rows.length > 0) {
          saleData = {
            barcode: oracleResult.rows[0].BARCODE,
            quantity: oracleResult.rows[0].QUANTITY,
            source: 'oracle'
          };
        }
      } catch (err) {
        console.error('Error fetching sale from Oracle:', err.message);
      }
    }

    // Try MongoDB if not found in Oracle or if it's a string ID
    if (!saleData) {
      try {
        const mongoSale = await HistorySales.findById(id);
        if (mongoSale) {
          saleData = {
            barcode: mongoSale.barcode,
            quantity: mongoSale.quantity,
            source: 'mongo'
          };
        }
      } catch (err) {
        console.error('Error fetching sale from MongoDB:', err.message);
      }
    }

    if (!saleData) {
      return res.status(404).json({ message: 'Sale record not found in either database' });
    }

    // 2. Perform Deletion
    if (saleData.source === 'oracle' && conn) {
      await conn.execute(`DELETE FROM HISTORY_SALES WHERE ID = :id`, [id]);
      await conn.commit();
    } else {
      await HistorySales.findByIdAndDelete(id);
      // Also attempt to delete from the daily sales collection if it exists there
      const { Sales } = require('../models/mongo/Sales');
      await Sales.findOneAndDelete({ barcode: saleData.barcode, quantity: saleData.quantity, date: saleData.date });
    }

    // 3. Restore Stock in BOTH databases
    // Restore in Oracle
    let oracleStockRestored = false;
    try {
      if (!conn) conn = await getConnection();
      await conn.execute(
        `UPDATE DRUGS SET QUANTITY = QUANTITY + :qty WHERE BARCODE = :barcode`,
        { qty: saleData.quantity, barcode: saleData.barcode }
      );
      await conn.commit();
      oracleStockRestored = true;
    } catch (err) {
      console.error('Failed to restore stock in Oracle:', err.message);
    }

    // Restore in MongoDB
    let mongoStockRestored = false;
    try {
      const { Drug } = require('../models/mongo/Drug');
      await Drug.updateOne(
        { barcode: saleData.barcode },
        { $inc: { quantity: saleData.quantity } }
      );
      mongoStockRestored = true;
    } catch (err) {
      console.error('Failed to restore stock in MongoDB:', err.message);
    }

    res.status(200).json({
      message: 'Sale deleted successfully',
      stockRestored: { oracle: oracleStockRestored, mongo: mongoStockRestored }
    });

  } catch (error) {
    console.error('Critical error in deleteHistorySale:', error);
    if (conn) try { await conn.rollback(); } catch (e) { }
    res.status(500).json({ message: 'Error deleting sale', error: error.message });
  } finally {
    if (conn) {
      try { await conn.close(); } catch (e) { }
    }
  }
};

module.exports = { getAllHistorySales, addHistorySale, deleteHistorySale };