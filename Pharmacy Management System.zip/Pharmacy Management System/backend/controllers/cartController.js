const { getConnection } = require('../config/oracledb');
const { Cart } = require('../models/mongo/Cart');
const { Drug } = require('../models/mongo/Drug');

// GET Cart items for a user
async function getCart(req, res) {
    const { username } = req.params;
    let conn;
    try {
        conn = await getConnection();
        const result = await conn.execute(
            `SELECT * FROM CART WHERE USERNAME = :username ORDER BY CREATED_AT DESC`,
            { username },
            { outFormat: 4002 }
        );
        res.json(result.rows);
    } catch (err) {
        console.error('Error fetching cart:', err);
        res.status(500).json({ message: 'Error fetching cart' });
    } finally {
        if (conn) await conn.close();
    }
}

// ADD Item to Cart
async function addToCart(req, res) {
    console.log('addToCart called with body:', req.body);
    const { username, barcode, quantity } = req.body;

    if (!username || !barcode || !quantity) {
        return res.status(400).json({ message: 'Username, Barcode, and Quantity are required' });
    }

    let conn;
    try {
        conn = await getConnection();

        // 1. Get Drug Details
        const drugResult = await conn.execute(
            `SELECT * FROM DRUGS WHERE BARCODE = :barcode`,
            { barcode },
            { outFormat: 4002 }
        );

        if (drugResult.rows.length === 0) {
            return res.status(404).json({ message: 'Drug not found' });
        }

        const drug = drugResult.rows[0];
        const price = drug.SELLING_PRICE;
        const total = price * quantity;

        // 2. Add to Cart (Oracle)
        await conn.execute(
            `INSERT INTO CART (USERNAME, BARCODE, DRUG_NAME, PRICE, QUANTITY, TOTAL)
       VALUES (:username, :barcode, :name, :price, :quantity, :total)`,
            {
                username,
                barcode,
                name: drug.NAME,
                price,
                quantity,
                total
            },
            { autoCommit: true }
        );

        // 3. Add to Cart (Mongo - Sync)
        const newCartItem = new Cart({
            username,
            barcode,
            drugName: drug.NAME,
            price,
            quantity,
            total
        });
        await newCartItem.save();

        res.json({ message: 'Item added to cart' });

    } catch (err) {
        console.error('Error adding to cart:', err);
        res.status(500).json({ message: 'Error adding to cart' });
    } finally {
        if (conn) await conn.close();
    }
}

// REMOVE Item from Cart
async function removeFromCart(req, res) {
    const { id } = req.params;
    let conn;
    try {
        conn = await getConnection();
        await conn.execute(
            `DELETE FROM CART WHERE ID = :id`,
            [id],
            { autoCommit: true }
        );
        res.json({ message: 'Item removed from cart' });
    } catch (err) {
        console.error('Error removing from cart:', err);
        res.status(500).json({ message: 'Error removing from cart' });
    } finally {
        if (conn) await conn.close();
    }
}

// CLEAR Cart
async function clearCart(req, res) {
    const { username } = req.params;
    let conn;
    try {
        conn = await getConnection();
        await conn.execute(
            `DELETE FROM CART WHERE USERNAME = :username`,
            { username },
            { autoCommit: true }
        );

        // Sync Mongo
        await Cart.deleteMany({ username });

        res.json({ message: 'Cart cleared' });
    } catch (err) {
        console.error('Error clearing cart:', err);
        res.status(500).json({ message: 'Error clearing cart' });
    } finally {
        if (conn) await conn.close();
    }
}

module.exports = { getCart, addToCart, removeFromCart, clearCart };
