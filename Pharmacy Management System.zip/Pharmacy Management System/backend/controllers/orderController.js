const oracledb = require('oracledb');
const { getConnection } = require('../config/oracledb');
const { Order } = require('../models/mongo/Orders');
const { Sales } = require('../models/mongo/Sales');
const { HistorySales } = require('../models/mongo/HistorySales');
const { Drug } = require('../models/mongo/Drug');

// CHECKOUT
async function checkout(req, res) {
    const { username } = req.body;
    if (!username) return res.status(400).json({ message: 'Username is required' });

    let conn;
    try {
        conn = await getConnection();

        // 1. Get Cart Items
        console.log('Fetching cart for:', username);
        const cartResult = await conn.execute(
            `SELECT * FROM CART WHERE USERNAME = :bUsername`,
            { bUsername: username },
            { outFormat: oracledb.OUT_FORMAT_OBJECT }
        );

        const cartItems = cartResult.rows;
        if (cartItems.length === 0) {
            return res.status(400).json({ message: 'Cart is empty' });
        }

        // 2. Calculate Total
        const totalAmount = cartItems.reduce((sum, item) => sum + item.TOTAL, 0);
        console.log('Total Amount:', totalAmount);

        // 3. Create Order (Oracle)
        console.log('Creating Order...');
        await conn.execute(
            `INSERT INTO ORDERS (USERNAME, TOTAL_AMOUNT, STATUS) 
       VALUES (:bUsername, :bTotal, 'COMPLETED')`,
            {
                bUsername: username,
                bTotal: totalAmount
            },
            { autoCommit: false }
        );

        // Fetch the ID of the order we just created
        const idResult = await conn.execute(
            `SELECT MAX(ID) AS MAX_ID FROM ORDERS WHERE USERNAME = :bUsername`,
            { bUsername: username },
            { outFormat: oracledb.OUT_FORMAT_OBJECT }
        );

        const orderId = idResult.rows[0].MAX_ID;

        // 4. Process Each Item (Move to Sales, Update Stock)
        for (const item of cartItems) {
            // Check Stock
            const drugCheck = await conn.execute(
                `SELECT QUANTITY FROM DRUGS WHERE BARCODE = :bBarcode`,
                { bBarcode: item.BARCODE }
            );

            if (drugCheck.rows.length === 0) {
                throw new Error(`Drug not found: ${item.DRUG_NAME} (${item.BARCODE})`);
            }

            const currentStock = drugCheck.rows[0][0]; // Assuming default array output format
            if (currentStock < item.QUANTITY) {
                throw new Error(`Insufficient stock for ${item.DRUG_NAME}. Available: ${currentStock}, Requested: ${item.QUANTITY}`);
            }

            // Add to Sales
            const saleDate = new Date();
            const salesQuery = `INSERT INTO SALES (BARCODE, NAME, TYPE, DOSE, QUANTITY, PRICE, AMOUNT, SALE_DATE, SALE_TIME, USER_NAME)
         VALUES (:bBarcode, :bName, 'N/A', 'N/A', :bQty, :bPrice, :bAmount, :bDate, :bTime, :bUser)`;
            console.log('SALES INSERT QUERY:', salesQuery);
            await conn.execute(
                salesQuery,
                {
                    bBarcode: item.BARCODE,
                    bName: item.DRUG_NAME,
                    bQty: item.QUANTITY,
                    bPrice: item.PRICE,
                    bAmount: item.TOTAL,
                    bDate: saleDate,
                    bTime: saleDate.toLocaleTimeString(),
                    bUser: username
                },
                { autoCommit: false }
            );

            // Update Stock
            await conn.execute(
                `UPDATE DRUGS SET QUANTITY = QUANTITY - :bQty WHERE BARCODE = :bBarcode`,
                { bQty: item.QUANTITY, bBarcode: item.BARCODE },
                { autoCommit: false }
            );
        }

        // 5. Clear Cart (Oracle)
        await conn.execute(
            `DELETE FROM CART WHERE USERNAME = :bUsername`,
            { bUsername: username },
            { autoCommit: false }
        );

        await conn.commit();

        // 6. Sync Mongo (Best Effort)
        try {
            const newOrder = new Order({
                username,
                items: cartItems,
                totalAmount,
                status: 'COMPLETED'
            });
            await newOrder.save();
        } catch (e) {
            console.error('Mongo sync error:', e);
        }

        res.json({
            message: 'Checkout successful',
            orderId,
            items: cartItems,
            totalAmount
        });

    } catch (err) {
        console.error('Checkout error:', err);
        if (conn) {
            try { await conn.rollback(); } catch (e) { }
        }
        res.status(500).json({ message: 'Checkout failed', error: err.message });
    } finally {
        if (conn) await conn.close();
    }
}

// GET Receipt
async function getReceipt(req, res) {
    const { id } = req.params;
    res.json({ message: 'Receipt not implemented yet' });
}

module.exports = { checkout, getReceipt };
