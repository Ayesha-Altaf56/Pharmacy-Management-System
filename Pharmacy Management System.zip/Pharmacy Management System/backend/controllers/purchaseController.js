const { getConnection } = require('../config/oracledb');
const { Purchase } = require('../models/mongo/Purchase');
const { Drug } = require('../models/mongo/Drug');

const getAllPurchases = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(`
      SELECT p.*, d.NAME AS DRUG_NAME, c.NAME AS COMPANY_NAME
      FROM PURCHASES p
      JOIN DRUGS d ON p.BARCODE = d.BARCODE
      JOIN COMPANIES c ON p.COMPANY_ID = c.ID
      ORDER BY p.PURCHASE_DATE DESC
    `, [], { outFormat: 4002 });

    if (result.rows && result.rows.length > 0) {
      return res.status(200).json(result.rows);
    }

    const mongoPurchases = await Purchase.find({}).sort({ date: -1 });
    res.status(200).json(mongoPurchases);

  } catch (error) {
    console.error('Error fetching purchases:', error);
    res.status(500).json({ message: 'Error fetching purchases' });
  } finally {
    if (conn) {
      try {
        await conn.close();
      } catch (e) {
        console.error('Error closing Oracle connection:', e);
      }
    }
  }
};

const addPurchase = async (req, res) => {
  const { barcode, drugName, type, company_name, quantity, price, supplier_name } = req.body;

  if (!barcode || !quantity || !price) {
    return res.status(400).json({ message: 'Barcode, Quantity, and Price are required' });
  }

  const amount = quantity * price;
  const purchaseDate = new Date();

  let conn;
  try {
    conn = await getConnection();

    // 1. Get COMPANY_ID from company_name
    const companyRes = await conn.execute(
      `SELECT ID FROM COMPANIES WHERE LOWER(NAME) = LOWER(:compName)`,
      { compName: company_name },
      { outFormat: 4002 }
    );

    let companyId = 1; // Default fallback
    if (companyRes.rows && companyRes.rows.length > 0) {
      companyId = companyRes.rows[0].ID || companyRes.rows[0][0]; // Handle different outFormats
    }

    // 2. Insert Purchase into Oracle
    await conn.execute(
      `INSERT INTO PURCHASES (BARCODE, COMPANY_ID, QUANTITY, PRICE, AMOUNT, PURCHASE_DATE, SUPPLIER_NAME) 
       VALUES (:barcode, :companyId, :quantity, :price, :amount, :purchaseDate, :supplier_name)`,
      { barcode, companyId, quantity, price, amount, purchaseDate, supplier_name },
      { autoCommit: true }
    );

    // 2. Insert Purchase into Mongo
    const newPurchase = new Purchase({
      barcode, drugName, type, company_name, quantity, price, amount, date: purchaseDate, supplier_name
    });
    await newPurchase.save();

    // 3. Update Inventory (Oracle)
    await conn.execute(
      `UPDATE DRUGS SET QUANTITY = QUANTITY + :quantity WHERE BARCODE = :barcode`,
      { quantity, barcode },
      { autoCommit: true }
    );

    // 4. Update Inventory (Mongo)
    await Drug.updateOne(
      { barcode: barcode },
      { $inc: { quantity: quantity } }
    );

    res.status(201).json({ message: 'Purchase added and stock updated successfully' });

  } catch (error) {
    console.error('Error adding purchase:', error);
    res.status(500).json({ message: 'Error adding purchase' });
  } finally {
    if (conn) {
      try {
        await conn.close();
      } catch (e) {
        console.error('Error closing Oracle connection:', e);
      }
    }
  }
};

module.exports = { getAllPurchases, addPurchase };
