const { getConnection } = require('../config/oracledb');

const getExpiryReport = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();

    // Fetch all drugs with expiration dates
    // Removed ID, using BARCODE as identifier
    const query = `
      SELECT d.NAME, d.BARCODE, d.QUANTITY, d.EXPIRATION_DATE, c.NAME AS COMPANY_NAME
      FROM DRUGS d
      LEFT JOIN COMPANIES c ON d.COMPANY_ID = c.ID
      WHERE d.EXPIRATION_DATE IS NOT NULL
      ORDER BY d.EXPIRATION_DATE ASC
    `;

    const result = await conn.execute(query, [], { outFormat: 4002 });
    const drugs = result.rows;

    const today = new Date();
    const sevenDays = new Date(today); sevenDays.setDate(today.getDate() + 7);
    const thirtyDays = new Date(today); thirtyDays.setDate(today.getDate() + 30);
    const ninetyDays = new Date(today); ninetyDays.setDate(today.getDate() + 90);

    const report = {
      expired: [],
      expiring7: [],
      expiring30: [],
      expiring90: [],
      all: drugs
    };

    drugs.forEach(drug => {
      const expDate = new Date(drug.EXPIRATION_DATE);

      if (expDate < today) {
        report.expired.push(drug);
      } else if (expDate <= sevenDays) {
        report.expiring7.push(drug);
        report.expiring30.push(drug); // Also in 30
        report.expiring90.push(drug); // Also in 90
      } else if (expDate <= thirtyDays) {
        report.expiring30.push(drug);
        report.expiring90.push(drug);
      } else if (expDate <= ninetyDays) {
        report.expiring90.push(drug);
      }
    });

    res.json(report);

  } catch (err) {
    console.error('Error fetching expiry report:', err);
    res.status(500).json({ message: 'Error fetching expiry report' });
  } finally {
    if (conn) await conn.close();
  }
};

const removeExpiredStock = async (req, res) => {
  const { id } = req.params; // This is the BARCODE passed from frontend
  let conn;
  try {
    conn = await getConnection();

    // Using BARCODE as the identifier
    await conn.execute(
      `UPDATE DRUGS SET QUANTITY = 0 WHERE BARCODE = :id`,
      [id],
      { autoCommit: true }
    );

    res.json({ message: 'Stock removed successfully' });
  } catch (err) {
    console.error('Error removing expired stock:', err);
    res.status(500).json({ message: 'Error removing expired stock' });
  } finally {
    if (conn) await conn.close();
  }
};

module.exports = {
  getExpiryReport,
  removeExpiredStock
};