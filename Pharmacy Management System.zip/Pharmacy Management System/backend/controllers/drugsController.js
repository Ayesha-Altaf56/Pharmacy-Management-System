const { getConnection } = require('../config/oracledb');
const { Drug } = require('../models/mongo/Drug');

const getAllDrugs = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    // JOIN with COMPANIES to get the company name for the frontend
    const result = await conn.execute(`
      SELECT d.*, c.NAME AS COMPANY_NAME 
      FROM DRUGS d 
      LEFT JOIN COMPANIES c ON d.COMPANY_ID = c.ID
    `, [], { outFormat: 4002 });

    if (result.rows && result.rows.length > 0) {
      return res.status(200).json(result.rows);
    }

    // Fallback to MongoDB if Oracle returns empty
    console.log('OracleDB returned 0 drugs, fetching from MongoDB...');
    const mongoDrugs = await Drug.find({});
    return res.status(200).json(mongoDrugs);

  } catch (error) {
    console.error('Error fetching drugs from Oracle:', error.message);

    // Fallback to MongoDB on error
    try {
      console.log('Attempting fetch from MongoDB...');
      const mongoDrugs = await Drug.find({});
      return res.status(200).json(mongoDrugs);
    } catch (mongoErr) {
      console.error('Error fetching drugs from MongoDB:', mongoErr);
      return res.status(500).send({ message: 'Error fetching drugs', error: error.message });
    }
  } finally {
    if (conn) {
      try {
        await conn.close();
      } catch (e) {
        console.error('Error closing Oracle connection:', e);
      }
    }
  }
};

const addDrug = async (req, res) => {
  const drugName = req.body.name;
  const drugType = req.body.type;
  const drugQty = req.body.quantity ? parseInt(req.body.quantity) : 0;
  const drugPlace = req.body.place;
  const drugSellingPrice = (req.body.sellingPrice || req.body.selling_price) ? parseFloat(req.body.sellingPrice || req.body.selling_price) : 0;
  const drugCostPrice = (req.body.costPrice || req.body.cost_price) ? parseFloat(req.body.costPrice || req.body.cost_price) : 0;
  const drugCompany = req.body.companyName || req.body.company_name;

  if (!drugName || !drugType || !drugQty || !drugSellingPrice || !drugCompany || !drugPlace) {
    return res.status(400).json({ message: 'Missing required fields: name, type, quantity, selling_price, company_name, place' });
  }

  const barcode = req.body.barcode || `BRC${Math.floor(Math.random() * 100000)}`;
  const dose = req.body.dose || 'N/A';
  const code = req.body.code || 'N/A';
  const expiry = req.body.expiry || 'N/A';
  const pDate = req.body.productionDate || req.body.production_date;
  const eDate = req.body.expirationDate || req.body.expiration_date;

  const productionDate = pDate ? new Date(pDate) : new Date();
  const expirationDate = eDate ? new Date(eDate) : new Date(new Date().setFullYear(new Date().getFullYear() + 1));

  let conn;
  let oracleStatus = 'idle';
  try {
    conn = await getConnection();
    oracleStatus = 'connecting';

    // 1. Get COMPANY_ID from COMPANY_NAME
    const companyRes = await conn.execute(
      `SELECT ID FROM COMPANIES WHERE LOWER(NAME) = LOWER(:compName)`,
      { compName: drugCompany },
      { outFormat: 4002 }
    );

    let companyId = 1; // Default
    if (companyRes.rows && companyRes.rows.length > 0) {
      companyId = companyRes.rows[0].ID;
    }

    // 2. Insert into OracleDB
    await conn.execute(
      `INSERT INTO DRUGS (
        NAME, TYPE, BARCODE, DOSE, CODE, COST_PRICE, SELLING_PRICE, EXPIRY, COMPANY_ID, 
        PRODUCTION_DATE, EXPIRATION_DATE, PLACE, QUANTITY) 
       VALUES (
        :name, :type, :barcode, :dose, :code, :costPrice, :sellingPrice, :expiry, :companyId, 
        :productionDate, :expirationDate, :place, :quantity)`,
      {
        name: drugName,
        type: drugType,
        barcode: barcode,
        dose: dose,
        code: code,
        costPrice: drugCostPrice,
        sellingPrice: drugSellingPrice,
        expiry: expiry,
        companyId: companyId,
        productionDate: productionDate,
        expirationDate: expirationDate,
        place: drugPlace,
        quantity: drugQty
      },
      { autoCommit: true }
    );
    oracleStatus = 'success';
  } catch (error) {
    console.error('OracleDB Error adding drug:', error.message);
    oracleStatus = 'failed';
  } finally {
    if (conn) {
      try { await conn.close(); } catch (e) { console.error('Error closing Oracle connection:', e); }
    }
  }

  // 3. Insert into MongoDB (Fallback/Sync)
  try {
    const newDrug = new Drug({
      name: drugName,
      type: drugType,
      barcode: barcode,
      dose: dose,
      code: code,
      cost_price: drugCostPrice,
      selling_price: drugSellingPrice,
      expiry: expiry,
      company_name: drugCompany,
      production_date: productionDate,
      expiration_date: expirationDate,
      place: drugPlace,
      quantity: drugQty
    });
    await newDrug.save();

    if (oracleStatus === 'success') {
      return res.status(201).json({ message: 'Drug added successfully (Synced)', database: 'Both' });
    } else {
      return res.status(201).json({
        message: 'Drug added successfully (Backup Mode)',
        database: 'MongoDB Only',
        warning: 'OracleDB was unavailable'
      });
    }

  } catch (mongoErr) {
    console.error('MongoDB Error adding drug:', mongoErr.message);
    if (oracleStatus === 'success') {
      return res.status(201).json({ message: 'Drug added successfully but Mongo sync failed', database: 'Oracle Only' });
    } else {
      return res.status(500).json({ message: 'Error adding drug (Both Databases Failed)', oralceError: oracleStatus === 'failed', mongoError: mongoErr.message });
    }
  }
};

const deleteDrug = async (req, res) => {
  const { barcode } = req.params;
  if (!barcode) return res.status(400).json({ message: 'Barcode is required' });

  let conn;
  let oracleDeleted = false;
  let oracleError = null;

  try {
    conn = await getConnection();
    const result = await conn.execute(`DELETE FROM DRUGS WHERE BARCODE = :barcode`, { barcode }, { autoCommit: true });
    oracleDeleted = (result.rowsAffected > 0);
  } catch (error) {
    console.error('OracleDB Error deleting drug:', error.message);
    oracleError = error.message;
  } finally {
    if (conn) await conn.close();
  }

  // MongoDB Deletion
  try {
    const mongoResult = await Drug.deleteOne({ barcode });
    const mongoDeleted = (mongoResult.deletedCount > 0);

    if (!oracleDeleted && !mongoDeleted && !oracleError) {
      return res.status(404).json({ message: 'Drug not found in either database' });
    }

    if (oracleDeleted || mongoDeleted) {
      return res.status(200).json({
        message: 'Drug deleted successfully',
        oracle: oracleDeleted ? 'Success' : (oracleError ? 'Failed' : 'Not Found'),
        mongo: mongoDeleted ? 'Success' : 'Not Found'
      });
    } else {
      return res.status(500).json({ message: 'Failed to delete drug', oracleError });
    }

  } catch (mongoErr) {
    console.error('MongoDB Error deleting drug:', mongoErr.message);
    if (oracleDeleted) {
      return res.status(200).json({ message: 'Drug deleted from Oracle (Mongo delete failed)' });
    } else {
      return res.status(500).json({ message: 'Error deleting drug from both databases', oracleError, mongoError: mongoErr.message });
    }
  }
};

const updateDrug = async (req, res) => {
  const { barcode } = req.params;
  const updates = req.body;

  if (!barcode) return res.status(400).json({ message: 'Barcode is required' });
  if (Object.keys(updates).length === 0) return res.status(400).json({ message: 'No fields to update' });

  let conn;
  let oracleUpdated = false;
  let oracleError = null;

  try {
    conn = await getConnection();

    // Map fields
    const fieldMap = {
      name: 'NAME', type: 'TYPE', dose: 'DOSE', code: 'CODE',
      costPrice: 'COST_PRICE', cost_price: 'COST_PRICE',
      sellingPrice: 'SELLING_PRICE', selling_price: 'SELLING_PRICE',
      expiry: 'EXPIRY', place: 'PLACE', quantity: 'QUANTITY',
      productionDate: 'PRODUCTION_DATE', production_date: 'PRODUCTION_DATE',
      expirationDate: 'EXPIRATION_DATE', expiration_date: 'EXPIRATION_DATE'
    };

    const updateFields = [];
    const bindParams = { barcode };

    for (const [key, value] of Object.entries(updates)) {
      if (fieldMap[key]) {
        const isDate = key.toLowerCase().includes('date');
        const isNumber = ['quantity', 'costPrice', 'cost_price', 'sellingPrice', 'selling_price'].includes(key);
        bindParams[key] = isDate ? (value ? new Date(value) : null) : (isNumber ? (value === '' ? 0 : parseFloat(value)) : value);
        updateFields.push(`${fieldMap[key]} = :${key}`);
      }
    }

    // Special handling for Company Name -> ID
    const newCompanyName = updates.companyName || updates.company_name;
    if (newCompanyName) {
      const companyRes = await conn.execute(
        `SELECT ID FROM COMPANIES WHERE LOWER(NAME) = LOWER(:compName)`,
        { compName: newCompanyName },
        { outFormat: 4002 }
      );
      if (companyRes.rows && companyRes.rows.length > 0) {
        bindParams.companyId = companyRes.rows[0].ID;
        updateFields.push(`COMPANY_ID = :companyId`);
      }
    }

    if (updateFields.length > 0) {
      const query = `UPDATE DRUGS SET ${updateFields.join(', ')} WHERE BARCODE = :barcode`;
      await conn.execute(query, bindParams, { autoCommit: true });
      oracleUpdated = true;
    }
  } catch (error) {
    console.error('OracleDB Error updating drug:', error.message);
    oracleError = error.message;
  } finally {
    if (conn) await conn.close();
  }

  // MongoDB Update
  try {
    const mongoUpdates = {};
    for (const [key, value] of Object.entries(updates)) {
      if (key.includes('price')) mongoUpdates[key.includes('cost') ? 'cost_price' : 'selling_price'] = parseFloat(value);
      else if (key.includes('date')) mongoUpdates[key.includes('production') ? 'production_date' : 'expiration_date'] = new Date(value);
      else if (key === 'quantity') mongoUpdates.quantity = parseInt(value);
      else if (key === 'companyName' || key === 'company_name') mongoUpdates.company_name = value;
      else mongoUpdates[key] = value;
    }
    const mongoResult = await Drug.updateOne({ barcode }, { $set: mongoUpdates });
    const mongoUpdated = (mongoResult.modifiedCount > 0 || mongoResult.matchedCount > 0);

    if (oracleUpdated || mongoUpdated) {
      return res.status(200).json({
        message: 'Drug updated successfully',
        oracle: oracleUpdated ? 'Success' : (oracleError ? 'Failed' : 'Not Found/No Change'),
        mongo: mongoUpdated ? 'Success' : 'Not Found/No Change'
      });
    } else {
      if (oracleError) {
        return res.status(500).json({ message: 'Failed to update drug in Oracle, and not found in Mongo', oracleError });
      }
      return res.status(404).json({ message: 'Drug not found to update' });
    }

  } catch (mongoErr) {
    console.error('MongoDB Error updating drug:', mongoErr.message);
    if (oracleUpdated) {
      return res.status(200).json({ message: 'Drug updated in Oracle (Mongo update failed)' });
    } else {
      return res.status(500).json({ message: 'Error updating drug in both databases', oracleError, mongoError: mongoErr.message });
    }
  }
};

module.exports = { getAllDrugs, addDrug, deleteDrug, updateDrug };
