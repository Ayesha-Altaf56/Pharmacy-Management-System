const { getConnection } = require('../config/oracledb');
const { Sales } = require('../models/mongo/Sales');

const getAllSales = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(`
      SELECT s.*, d.NAME, d.TYPE, d.DOSE 
      FROM SALES s
      JOIN DRUGS d ON s.BARCODE = d.BARCODE
      ORDER BY s.SALE_DATE DESC
    `, [], { outFormat: 4002 });

    if (result.rows && result.rows.length > 0) {
      return res.status(200).json(result.rows);
    }

    // Fallback to MongoDB
    console.log('OracleDB returned 0 sales records, fetching from MongoDB...');
    const mongoSales = await Sales.find({}).sort({ date: -1 });
    return res.status(200).json(mongoSales);

  } catch (error) {
    console.error('Error fetching sales records from Oracle:', error.message);

    // Fallback to MongoDB on error
    try {
      console.log('Attempting fetch from MongoDB...');
      const mongoSales = await Sales.find({}).sort({ date: -1 });
      return res.status(200).json(mongoSales);
    } catch (mongoErr) {
      console.error('Error fetching sales records from MongoDB:', mongoErr);
      return res.status(500).send({ message: 'Error fetching sales records', error: error.message });
    }
  } finally {
    if (conn) {
      try {
        await conn.close();
      } catch (e) {
        console.error('Error closing Oracle connection:', e);
      }
    }
  }
};

const addSale = async (req, res) => {
  const barcode = req.body.barcode;
  const quantity = parseInt(req.body.quantity);

  if (!barcode || !quantity) {
    return res.status(400).json({ message: 'Barcode and Quantity are required' });
  }

  const { Drug } = require('../models/mongo/Drug');
  const { HistorySales } = require('../models/mongo/HistorySales');

  let conn;
  let oracleStatus = 'idle';
  let drugData = null;
  let userName = 'Admin';
  let saleDate = new Date();
  let saleTime = saleDate.toLocaleTimeString();

  // 1. Try Oracle first
  try {
    conn = await getConnection();
    oracleStatus = 'connecting';

    const drugResult = await conn.execute(
      `SELECT * FROM DRUGS WHERE BARCODE = :barcode`,
      { barcode },
      { outFormat: 4002 }
    );

    if (drugResult.rows.length > 0) {
      drugData = drugResult.rows[0];
      // Normalize field names from Oracle (uppercase) to match logic
      drugData.name = drugData.NAME;
      drugData.sellingPrice = drugData.SELLING_PRICE;
      drugData.quantity = drugData.QUANTITY;
      drugData.expirationDate = new Date(drugData.EXPIRATION_DATE || drugData.EXPIRY);
    } else {
      oracleStatus = 'not_found';
    }
  } catch (error) {
    console.error('OracleDB Error during sale (Fetch Drug):', error.message);
    oracleStatus = 'failed';
  }

  // 2. If Oracle failed or didn't find the drug, try MongoDB
  if (!drugData || oracleStatus === 'failed') {
    try {
      const mongoDrug = await Drug.findOne({ barcode });
      if (mongoDrug) {
        drugData = {
          BARCODE: mongoDrug.barcode,
          NAME: mongoDrug.name,
          TYPE: mongoDrug.type,
          DOSE: mongoDrug.dose,
          QUANTITY: mongoDrug.quantity,
          SELLING_PRICE: mongoDrug.selling_price,
          EXPIRATION_DATE: mongoDrug.expiration_date || new Date(mongoDrug.expiry)
        };
      } else {
        return res.status(404).json({ message: 'Drug not found in either database' });
      }
    } catch (mongoErr) {
      console.error('MongoDB Error during sale (Fetch Drug):', mongoErr.message);
      return res.status(500).json({ message: 'Error fetching drug data', error: mongoErr.message });
    }
  }

  // 3. Validations
  if (drugData.QUANTITY < quantity) {
    return res.status(400).json({ message: `Insufficient stock. Available: ${drugData.QUANTITY}` });
  }
  if (new Date(drugData.EXPIRATION_DATE) < new Date()) {
    return res.status(400).json({ message: `Cannot sell expired drug. Expired on: ${new Date(drugData.EXPIRATION_DATE).toDateString()}` });
  }

  const price = drugData.SELLING_PRICE;
  const amount = price * quantity;

  // 4. Update Oracle if it was working
  let oracleSuccess = false;
  if (oracleStatus !== 'failed' && conn) {
    try {
      // Insert Sale
      await conn.execute(
        `INSERT INTO SALES (BARCODE, QUANTITY, PRICE, AMOUNT, SALE_DATE, SALE_TIME, USER_NAME) 
         VALUES (:barcode, :quantity, :price, :amount, :saleDate, :saleTime, :userName)`,
        {
          barcode: drugData.BARCODE,
          quantity, price, amount, saleDate, saleTime, userName
        }
      );

      // Insert History
      await conn.execute(
        `INSERT INTO HISTORY_SALES (BARCODE, QUANTITY, PRICE, SALE_DATE, SALE_TIME, USER_NAME) 
         VALUES (:barcode, :quantity, :price, :saleDate, :saleTime, :userName)`,
        {
          barcode: drugData.BARCODE,
          quantity, price, saleDate, saleTime, userName
        }
      );

      // Update Stock
      await conn.execute(
        `UPDATE DRUGS SET QUANTITY = QUANTITY - :qty WHERE BARCODE = :barcode`,
        { qty: quantity, barcode: barcode }
      );

      await conn.commit();
      oracleSuccess = true;
    } catch (oracleErr) {
      console.error('OracleDB Error recording sale:', oracleErr.message);
      await conn.rollback();
    } finally {
      await conn.close();
    }
  }

  // 5. Update MongoDB
  let mongoSuccess = false;
  try {
    const newSale = new Sales({
      barcode: drugData.BARCODE,
      drugName: drugData.NAME,
      type: drugData.TYPE,
      dose: drugData.DOSE,
      quantity, price, amount,
      date: saleDate
    });
    await newSale.save();

    const newHistorySale = new HistorySales({
      barcode: drugData.BARCODE,
      drugName: drugData.NAME,
      type: drugData.TYPE,
      dose: drugData.DOSE,
      quantity, price, amount,
      date: saleDate, time: saleDate,
      user_name: userName
    });
    await newHistorySale.save();

    await Drug.updateOne(
      { barcode: barcode },
      { $inc: { quantity: -quantity } }
    );
    mongoSuccess = true;
  } catch (mongoErr) {
    console.error('MongoDB Error recording sale:', mongoErr.message);
  }

  // 6. Response
  if (oracleSuccess || mongoSuccess) {
    return res.status(201).json({
      message: oracleSuccess ? 'Sale recorded successfully' : 'Sale recorded in Backup Mode (MongoDB)',
      db: oracleSuccess ? (mongoSuccess ? 'Both' : 'Oracle Only') : 'MongoDB Only',
      sale: {
        drug: drugData.NAME,
        quantity,
        amount,
        remainingStock: drugData.QUANTITY - quantity
      }
    });
  } else {
    return res.status(500).json({ message: 'Error processing sale in both databases' });
  }
};

module.exports = { getAllSales, addSale };