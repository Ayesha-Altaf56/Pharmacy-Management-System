// backend/utils/validateForm.js

const isNotEmpty = (value) => value !== null && value !== undefined && value.toString().trim() !== '';

const isNumber = (value) => {
  if (value === null || value === undefined || value === '') return false;
  return !isNaN(Number(value));
};

const isPositiveNumber = (value) => {
  if (value === null || value === undefined || value === '') return false;
  const num = Number(value);
  return !isNaN(num) && num > 0;
};

const isEmail = (value) => {
  if (!value) return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
};

const isPhoneNumber = (value) => {
  if (!value) return false;
  return /^[0-9]{10,15}$/.test(value.toString());
};

module.exports = {
  isNotEmpty,
  isNumber,
  isPositiveNumber,
  isEmail,
  isPhoneNumber,
};
