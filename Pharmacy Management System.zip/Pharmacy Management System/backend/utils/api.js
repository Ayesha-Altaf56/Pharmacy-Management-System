// backend/utils/api.js
const axios = require('axios');

const API_BASE_URL = 'http://localhost:3000/api';

/**
 * Creates the configuration object, adding the Authorization header if a token is present.
 * @param {string} [authToken=null] - The JWT token for authentication.
 */
const createConfig = (authToken) => ({
  headers: {
    'Content-Type': 'application/json',
    ...(authToken && { 'Authorization': `Bearer ${authToken}` }),
  },
});

const fetchData = async (endpoint, authToken = null) => {
  try {
    const res = await axios.get(`${API_BASE_URL}/${endpoint}`, createConfig(authToken)); 
    return res.data;
  } catch (err) {
    console.error(`Error fetching ${endpoint}:`, err);
    throw err;
  }
};

const postData = async (endpoint, payload, authToken = null) => {
  try {
    const res = await axios.post(`${API_BASE_URL}/${endpoint}`, payload, createConfig(authToken)); 
    return res.data;
  } catch (err) {
    console.error(`Error posting to ${endpoint}:`, err);
    throw err;
  }
};

const putData = async (endpoint, payload, authToken = null) => {
  try {
    const res = await axios.put(`${API_BASE_URL}/${endpoint}`, payload, createConfig(authToken)); 
    return res.data;
  } catch (err) {
    console.error(`Error updating ${endpoint}:`, err);
    throw err;
  }
};

const deleteData = async (endpoint, authToken = null) => {
  try {
    const res = await axios.delete(`${API_BASE_URL}/${endpoint}`, createConfig(authToken));
    return res.data;
  } catch (err) {
    console.error(`Error deleting ${endpoint}:`, err);
    throw err;
  }
};

module.exports = {
  fetchData,
  postData,
  putData,
  deleteData,
};
