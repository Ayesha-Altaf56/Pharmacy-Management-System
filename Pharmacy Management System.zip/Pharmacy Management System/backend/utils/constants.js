// backend/utils/constants.js

const ROLES = {
  ADMIN: 'admin',
  USER: 'user',
  CUSTOMER: 'customer',
};

const DRUG_TYPES = {
  TABLET: 'Tablet',
  SYRUP: 'Syrup',
  INJECTION: 'Injection',
};

const STATUS = {
  ACTIVE: 'Active',
  INACTIVE: 'Inactive',
  EXPIRED: 'Expired',
};

const API_ENDPOINTS = {
  COMPANY: 'company',
  DRUGS: 'drugs',
  EXPIRY: 'expiry',
  HISTORY_SALES: 'history-sales',
  INBOX: 'inbox',
  LOGIN: 'login',
  MESSAGE_HISTORY: 'message-history',
  PURCHASE: 'purchase',
  SALES: 'sales',
  USERS: 'users',
};

module.exports = {
  ROLES,
  DRUG_TYPES,
  STATUS,
  API_ENDPOINTS,
};
