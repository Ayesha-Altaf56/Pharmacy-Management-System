// backend/utils/formatNumber.js

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('en-PK', {
    style: 'currency',
    currency: 'PKR'
  }).format(amount);
};

const formatNumber = (num) => {
  return new Intl.NumberFormat('en-PK').format(num);
};

module.exports = {
  formatCurrency,
  formatNumber,
};
