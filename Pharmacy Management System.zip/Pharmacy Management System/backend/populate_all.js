const { getConnection } = require('./config/oracledb');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
require('./config/mongodb'); // Initialize Mongo connection

// Import Mongo Models
const { Company } = require('./models/mongo/Company');
const { Drug } = require('./models/mongo/Drug');
const { Expiry } = require('./models/mongo/Expiry');
const { HistorySales } = require('./models/mongo/HistorySales');
const { Inbox } = require('./models/mongo/Inbox');
const { Login } = require('./models/mongo/Login');
const { MessageHistory } = require('./models/mongo/MessageHistory');
const { Purchase } = require('./models/mongo/Purchase');
const { Sales } = require('./models/mongo/Sales');
const { Users } = require('./models/mongo/Users');

// --- DATA DEFINITIONS ---

const companies = [
    { id: 1, name: 'PharmaOne', address: '12 Health St, Lahore', phone: '03001230001' },
    { id: 2, name: 'MedSupply', address: '45 Wellness Ave, Karachi', phone: '03001230002' },
    { id: 3, name: 'CareMeds', address: '78 Cure Rd, Islamabad', phone: '03001230003' },
    { id: 4, name: 'GSK', address: '123 GSK Rd', phone: '03001111111' },
    { id: 5, name: 'Abbott', address: '456 Abbott Ave', phone: '03002222222' },
    { id: 6, name: 'Sanofi', address: '789 Sanofi St', phone: '03003333333' },
    { id: 7, name: 'Novartis', address: '101 Novartis Ln', phone: '03004444444' },
    { id: 8, name: 'Atco', address: '202 Atco Blvd', phone: '03005555555' },
    { id: 9, name: 'ICI', address: '303 ICI Rd', phone: '03006666666' },
    { id: 10, name: 'Getz', address: '404 Getz Way', phone: '03007777777' },
    { id: 11, name: 'Barrett', address: '505 Barrett St', phone: '03008888888' },
    { id: 12, name: 'AGP', address: '606 AGP Ave', phone: '03009999999' },
    { id: 13, name: 'Bayer', address: '707 Bayer Rd', phone: '03000000000' },
    { id: 14, name: 'Merck', address: '808 Merck Ln', phone: '03001212121' }
];

const usersData = [
    { id: 1, name: 'ayesha', username: 'ayesha', dob: '1998-05-12', address: 'Lahore', phone: '03001234567', salary: 50000, password: 'pass123', role: 'Admin', is_active: 1 },
    { id: 2, name: 'Ali', username: 'ali', dob: '1995-08-21', address: 'Karachi', phone: '03007654321', salary: 60000, password: 'ali2025', role: 'Pharmacist', is_active: 1 },
    { id: 3, name: 'Sara Ahmed', username: 'sara', dob: '2000-01-15', address: 'Islamabad', phone: '03005556677', salary: 45000, password: 'sara987', role: 'Staff', is_active: 1 },
    { id: 11, name: 'Maryam Admin', username: 'maryam', dob: '1995-01-01', address: 'Admin Office', phone: '03000000000', salary: 100000, password: 'maryam123', role: 'Admin', is_active: 1 },
    { id: 12, name: 'Ayesha Altaf', username: 'Ayesha_Altaf', dob: '1998-05-12', address: 'Lahore', phone: '03001230000', salary: 0, password: 'pass123', role: 'customer', is_active: 1 },
];

const logins = [
    { username: 'ayesha', password: 'pass123', user_type: 'admin' },
    { username: 'maryam', password: 'maryam123', user_type: 'admin' },
    { username: 'ali', password: 'ali2025', user_type: 'user' },
    { username: 'sara', password: 'sara987', user_type: 'user' },
    { username: 'Ayesha_Altaf', password: 'pass123', user_type: 'customer' }
];

const drugs = [
    {
        name: 'Panadol Extra', type: 'Tablet', barcode: 'BRC2001', dose: '500mg', code: 'P2001',
        costPrice: 12, sellingPrice: 18, expiry: '2026-12-31', companyName: 'GSK',
        productionDate: new Date('2024-01-15'), expirationDate: new Date('2026-12-31'),
        place: 'Shelf A', quantity: 200
    },
    {
        name: 'Augmentin', type: 'Tablet', barcode: 'BRC2002', dose: '625mg', code: 'A2002',
        costPrice: 45, sellingPrice: 60, expiry: '2025-11-30', companyName: 'GSK',
        productionDate: new Date('2023-11-01'), expirationDate: new Date('2025-11-30'),
        place: 'Shelf B', quantity: 100
    },
    {
        name: 'Brufen', type: 'Syrup', barcode: 'BRC2003', dose: '120ml', code: 'B2003',
        costPrice: 80, sellingPrice: 110, expiry: '2025-08-20', companyName: 'Abbott',
        productionDate: new Date('2023-08-01'), expirationDate: new Date('2025-08-20'),
        place: 'Shelf C', quantity: 50
    },
    {
        name: 'Flagyl', type: 'Tablet', barcode: 'BRC2004', dose: '400mg', code: 'F2004',
        costPrice: 8, sellingPrice: 12, expiry: '2027-01-15', companyName: 'Sanofi',
        productionDate: new Date('2024-01-01'), expirationDate: new Date('2027-01-15'),
        place: 'Shelf A', quantity: 300
    },
    {
        name: 'Caflam', type: 'Tablet', barcode: 'BRC2005', dose: '50mg', code: 'C2005',
        costPrice: 15, sellingPrice: 25, expiry: '2026-05-10', companyName: 'Novartis',
        productionDate: new Date('2024-02-01'), expirationDate: new Date('2026-05-10'),
        place: 'Shelf A', quantity: 150
    },
    {
        name: 'Ascard', type: 'Tablet', barcode: 'BRC2006', dose: '75mg', code: 'A2006',
        costPrice: 5, sellingPrice: 8, expiry: '2026-09-30', companyName: 'Atco',
        productionDate: new Date('2024-03-01'), expirationDate: new Date('2026-09-30'),
        place: 'Shelf B', quantity: 500
    },
    {
        name: 'Zestril', type: 'Tablet', barcode: 'BRC2007', dose: '10mg', code: 'Z2007',
        costPrice: 20, sellingPrice: 30, expiry: '2025-12-12', companyName: 'ICI',
        productionDate: new Date('2023-12-01'), expirationDate: new Date('2025-12-12'),
        place: 'Shelf B', quantity: 120
    },
    {
        name: 'Ventolin', type: 'Inhaler', barcode: 'BRC2008', dose: '100mcg', code: 'V2008',
        costPrice: 300, sellingPrice: 450, expiry: '2026-02-28', companyName: 'GSK',
        productionDate: new Date('2024-01-01'), expirationDate: new Date('2026-02-28'),
        place: 'Counter', quantity: 40
    },
    {
        name: 'Risek', type: 'Capsule', barcode: 'BRC2009', dose: '40mg', code: 'R2009',
        costPrice: 25, sellingPrice: 40, expiry: '2025-10-15', companyName: 'Getz',
        productionDate: new Date('2023-10-01'), expirationDate: new Date('2025-10-15'),
        place: 'Shelf C', quantity: 200
    },
    {
        name: 'Cefspan', type: 'Capsule', barcode: 'BRC2010', dose: '400mg', code: 'C2010',
        costPrice: 60, sellingPrice: 90, expiry: '2025-07-20', companyName: 'Barrett',
        productionDate: new Date('2023-07-01'), expirationDate: new Date('2025-07-20'),
        place: 'Shelf B', quantity: 80
    },
    {
        name: 'Arinac', type: 'Tablet', barcode: 'BRC2011', dose: '200mg', code: 'A2011',
        costPrice: 10, sellingPrice: 15, expiry: '2026-11-11', companyName: 'Abbott',
        productionDate: new Date('2024-01-01'), expirationDate: new Date('2026-11-11'),
        place: 'Shelf A', quantity: 250
    },
    {
        name: 'Rigix', type: 'Syrup', barcode: 'BRC2012', dose: '60ml', code: 'R2012',
        costPrice: 70, sellingPrice: 100, expiry: '2025-09-05', companyName: 'AGP',
        productionDate: new Date('2023-09-01'), expirationDate: new Date('2025-09-05'),
        place: 'Shelf C', quantity: 60
    },
    {
        name: 'Surbex Z', type: 'Tablet', barcode: 'BRC2013', dose: 'N/A', code: 'S2013',
        costPrice: 15, sellingPrice: 22, expiry: '2027-03-15', companyName: 'Abbott',
        productionDate: new Date('2024-03-01'), expirationDate: new Date('2027-03-15'),
        place: 'Shelf D', quantity: 180
    },
    {
        name: 'Kestine', type: 'Tablet', barcode: 'BRC2014', dose: '10mg', code: 'K2014',
        costPrice: 18, sellingPrice: 28, expiry: '2026-06-30', companyName: 'Bayer',
        productionDate: new Date('2024-01-01'), expirationDate: new Date('2026-06-30'),
        place: 'Shelf A', quantity: 140
    },
    {
        name: 'Glucophage', type: 'Tablet', barcode: 'BRC2015', dose: '500mg', code: 'G2015',
        costPrice: 8, sellingPrice: 12, expiry: '2026-08-15', companyName: 'Merck',
        productionDate: new Date('2024-02-01'), expirationDate: new Date('2026-08-15'),
        place: 'Shelf B', quantity: 300
    }
];

const historySalesData = [
    { user_id: 1, barcode: 'BRC2001', drugName: 'Panadol Extra', type: 'Tablet', dose: '500mg', quantity: 3, price: 18, amount: 54, date: new Date(), time: new Date() }
];

const inboxMessages = [
    { message_from: 'Supplier', message_to: 'Pharmacy', message_text: 'New shipment arriving tomorrow.' }
];

const messageHistoryData = [
    { message_from: 'ayesha', message_to: 'ali', message_text: 'Please check shelf B stock.' }
];

const purchasesData = [
    { barcode: 'BRC2001', drugName: 'Panadol Extra', type: 'Tablet', company_name: 'GSK', company_id: 4, quantity: 200, price: 12, amount: 2400, date: new Date() }
];

const salesData = [
    { barcode: 'BRC2001', drugName: 'Panadol Extra', type: 'Tablet', dose: '500mg', quantity: 5, price: 18, amount: 90, date: new Date() }
];

// --- MAIN FUNCTION ---

async function populateAll() {
    let conn;
    try {
        console.log('Connecting to OracleDB...');
        conn = await getConnection();
        console.log('Connected to OracleDB.');

        console.log('Waiting for MongoDB connection...');
        if (mongoose.connection.readyState !== 1) {
            await new Promise(resolve => mongoose.connection.once('open', resolve));
        }
        console.log('Connected to MongoDB.');

        // 0. CLEAR PREVIOUS DATA (Correct SQL Order)
        console.log('Clearing previous data...');
        const sqlTables = [
            'HISTORY_SALES', 'SALES', 'PURCHASES', 'MESSAGE_HISTORY',
            'INBOX', 'DRUGS', 'USERS', 'LOGIN', 'COMPANIES'
        ];
        for (const table of sqlTables) {
            try {
                await conn.execute(`DELETE FROM ${table}`, [], { autoCommit: true });
                console.log(`Cleared SQL ${table} table.`);
            } catch (e) { console.error(`Error clearing SQL ${table} table:`, e.message); }
        }

        await Company.deleteMany({});
        await Drug.deleteMany({});
        await Expiry.deleteMany({});
        await HistorySales.deleteMany({});
        await Inbox.deleteMany({});
        await Login.deleteMany({});
        await MessageHistory.deleteMany({});
        await Purchase.deleteMany({});
        await Sales.deleteMany({});
        await Users.deleteMany({});
        console.log('Cleared all MongoDB collections.');

        // 1. COMPANIES
        console.log('Populating COMPANIES...');
        await Company.insertMany(companies.map(c => ({ name: c.name, address: c.address, phone: c.phone })));
        for (const c of companies) {
            try {
                await conn.execute(
                    `INSERT INTO COMPANIES (ID, NAME, ADDRESS, PHONE) VALUES (:id, :name, :address, :phone)`,
                    { id: c.id, name: c.name, address: c.address, phone: c.phone },
                    { autoCommit: true }
                );
            } catch (e) { console.error('Error inserting company:', e.message); }
        }

        // 2. USERS
        console.log('Populating USERS...');
        const hashedUsers = [];
        for (const u of usersData) {
            const hashed = await bcrypt.hash(u.password, 10);
            hashedUsers.push({ ...u, password: hashed });
            try {
                await conn.execute(
                    `INSERT INTO USERS (ID, NAME, USERNAME, PASSWORD, ROLE, DOB, ADDRESS, PHONE, SALARY, IS_ACTIVE)
                     VALUES (:id, :name, :username, :password, :role, TO_DATE(:dob, 'YYYY-MM-DD'), :address, :phone, :salary, :is_active)`,
                    {
                        id: u.id, name: u.name, username: u.username, password: hashed,
                        role: u.role, dob: u.dob, address: u.address,
                        phone: u.phone, salary: u.salary, is_active: u.is_active
                    }, { autoCommit: true }
                );
            } catch (e) { console.error('Error inserting user:', e.message); }
        }
        await Users.insertMany(hashedUsers);

        // 3. LOGIN
        console.log('Populating LOGIN...');
        const hashedLogins = [];
        for (const l of logins) {
            const hashed = await bcrypt.hash(l.password, 10);
            hashedLogins.push({ ...l, password: hashed, type: l.user_type });
            try {
                await conn.execute(
                    `INSERT INTO LOGIN (USERNAME, PASSWORD, USER_TYPE, LAST_LOGIN_DATE, LAST_LOGIN_TIME) 
                     VALUES (:username, :password, :user_type, SYSDATE, TO_CHAR(SYSDATE, 'HH24:MI:SS'))`,
                    { username: l.username, password: hashed, user_type: l.user_type }, { autoCommit: true }
                );
            } catch (e) { console.error('Error inserting login:', e.message); }
        }
        await Login.insertMany(hashedLogins);

        // 4. DRUGS
        console.log('Populating DRUGS...');
        for (const d of drugs) {
            const company = companies.find(c => c.name === d.companyName);
            const companyId = company ? company.id : 1;
            try {
                await conn.execute(
                    `INSERT INTO DRUGS (NAME, TYPE, BARCODE, DOSE, CODE, COST_PRICE, SELLING_PRICE, EXPIRY, COMPANY_ID, PRODUCTION_DATE, EXPIRATION_DATE, PLACE, QUANTITY)
                     VALUES (:name, :type, :barcode, :dose, :code, :cost_price, :selling_price, :expiry, :company_id, :prod_date, :exp_date, :place, :quantity)`,
                    {
                        name: d.name, type: d.type, barcode: d.barcode, dose: d.dose, code: d.code,
                        cost_price: d.costPrice, selling_price: d.sellingPrice, expiry: d.expiry,
                        company_id: companyId, prod_date: d.productionDate,
                        exp_date: d.expirationDate, place: d.place, quantity: d.quantity
                    }, { autoCommit: true }
                );
            } catch (e) { console.error('Error inserting drug:', e.message); }

            const newDrug = new Drug({
                name: d.name, type: d.type, barcode: d.barcode, dose: d.dose, code: d.code,
                cost_price: d.costPrice, selling_price: d.sellingPrice, expiry: d.expiry,
                company_name: d.companyName, production_date: d.productionDate,
                expiration_date: d.expirationDate, place: d.place, quantity: d.quantity
            });
            await newDrug.save();
        }

        // 5. HISTORY_SALES
        console.log('Populating HISTORY_SALES...');
        await HistorySales.insertMany(historySalesData.map(h => ({ ...h, user_name: 'ayesha' })));
        for (const h of historySalesData) {
            try {
                await conn.execute(
                    `INSERT INTO HISTORY_SALES (USER_ID, BARCODE, QUANTITY, PRICE, SALE_DATE, SALE_TIME)
                     VALUES (:user_id, :barcode, :quantity, :price, :s_date, :s_time)`,
                    {
                        user_id: h.user_id, barcode: h.barcode,
                        quantity: h.quantity, price: h.price,
                        s_date: h.date, s_time: h.time.toLocaleTimeString()
                    }, { autoCommit: true }
                );
            } catch (err) { console.error('Error inserting history_sales:', err.message); }
        }

        // 6. INBOX
        console.log('Populating INBOX...');
        await Inbox.insertMany(inboxMessages);
        for (const m of inboxMessages) {
            try {
                await conn.execute(
                    `INSERT INTO INBOX (MESSAGE_FROM, MESSAGE_TO, MESSAGE_TEXT) VALUES (:message_from, :message_to, :message_text)`,
                    m, { autoCommit: true }
                );
            } catch (err) { console.error('Error inserting inbox:', err.message); }
        }

        // 7. MESSAGE_HISTORY
        console.log('Populating MESSAGE_HISTORY...');
        await MessageHistory.insertMany(messageHistoryData);
        for (const m of messageHistoryData) {
            try {
                await conn.execute(
                    `INSERT INTO MESSAGE_HISTORY (MESSAGE_FROM, MESSAGE_TO, MESSAGE_TEXT) VALUES (:message_from, :message_to, :message_text)`,
                    m, { autoCommit: true }
                );
            } catch (err) { console.error('Error inserting message_history:', err.message); }
        }

        // 8. PURCHASES
        console.log('Populating PURCHASES...');
        await Purchase.insertMany(purchasesData);
        for (const p of purchasesData) {
            try {
                await conn.execute(
                    `INSERT INTO PURCHASES (BARCODE, COMPANY_ID, QUANTITY, PRICE, AMOUNT, PURCHASE_DATE, SUPPLIER_NAME)
                     VALUES (:barcode, :company_id, :quantity, :price, :amount, :p_date, :supplier_name)`,
                    {
                        barcode: p.barcode, company_id: p.company_id, quantity: p.quantity,
                        price: p.price, amount: p.amount, p_date: p.date,
                        supplier_name: p.company_name
                    }, { autoCommit: true }
                );
            } catch (err) { console.error('Error inserting purchase:', err.message); }
        }

        // 9. SALES
        console.log('Populating SALES...');
        await Sales.insertMany(salesData);
        for (const s of salesData) {
            try {
                await conn.execute(
                    `INSERT INTO SALES (BARCODE, QUANTITY, PRICE, AMOUNT, SALE_DATE, SALE_TIME, USER_ID)
                     VALUES (:barcode, :quantity, :price, :amount, :s_date, :s_time, :user_id)`,
                    {
                        barcode: s.barcode, quantity: s.quantity, price: s.price,
                        amount: s.amount, s_date: s.date, s_time: new Date().toLocaleTimeString(),
                        user_id: 1
                    }, { autoCommit: true }
                );
            } catch (err) { console.error('Error inserting sale:', err.message); }
        }

        console.log('All tables/collections populated successfully!');

    } catch (err) {
        console.error('Fatal Error:', err);
    } finally {
        if (conn) {
            try {
                await conn.close();
            } catch (e) {
                console.error('Error closing Oracle connection:', e);
            }
        }
        await mongoose.disconnect();
        process.exit(0);
    }
}

populateAll();
