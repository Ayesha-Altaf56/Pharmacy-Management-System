const oracledb = require('oracledb');
oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;

async function getConnection() {
  return await oracledb.getConnection({
    user: 'MADDIE_USER',
    password: 'maddieuser123',
    connectString: 'localhost:1521/orclpdb'
  });
}

module.exports = { getConnection };
