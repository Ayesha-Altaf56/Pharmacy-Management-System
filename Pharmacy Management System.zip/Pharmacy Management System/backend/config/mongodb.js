// backend/config/mongodb.js
'use strict';

const mongoose = require('mongoose');

// MongoDB connection string
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/pharmacy';

// Connect to MongoDB
mongoose.connect(MONGO_URI); // no options needed

// Get default connection
const db = mongoose.connection;

// Bind connection events
db.on('error', (err) => {
  console.error('MongoDB connection error:', err.message || err);
});

db.once('open', () => {
  console.log(`MongoDB connected successfully to ${MONGO_URI}`);
});

// Export the connection
module.exports = db;
