const { getConnection } = require('./config/oracledb');

async function addMissingColumns() {
    let conn;
    try {
        conn = await getConnection();

        console.log('Adding missing columns to SALES table...');

        // Add NAME column
        try {
            await conn.execute(`ALTER TABLE SALES ADD (NAME VARCHAR2(255))`);
            console.log('✓ Added NAME column');
        } catch (e) {
            if (e.errorNum === 1430) {
                console.log('- NAME column already exists');
            } else {
                throw e;
            }
        }

        // Add TYPE column
        try {
            await conn.execute(`ALTER TABLE SALES ADD (TYPE VARCHAR2(100))`);
            console.log('✓ Added TYPE column');
        } catch (e) {
            if (e.errorNum === 1430) {
                console.log('- TYPE column already exists');
            } else {
                throw e;
            }
        }

        // Add DOSE column
        try {
            await conn.execute(`ALTER TABLE SALES ADD (DOSE VARCHAR2(100))`);
            console.log('✓ Added DOSE column');
        } catch (e) {
            if (e.errorNum === 1430) {
                console.log('- DOSE column already exists');
            } else {
                throw e;
            }
        }

        await conn.commit();
        console.log('\n✅ Migration complete!');

    } catch (err) {
        console.error('Error:', err.message);
    } finally {
        if (conn) await conn.close();
    }
}

addMissingColumns();
