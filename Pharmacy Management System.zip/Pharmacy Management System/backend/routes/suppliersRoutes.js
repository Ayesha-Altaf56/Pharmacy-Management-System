const express = require('express');
const router = express.Router();
const suppliersController = require('../controllers/suppliersController');
const authenticate = require('../middlewares/authMiddleware');
const { ROLES } = require('../utils/constants');

router.get('/', authenticate(), suppliersController.getAllSuppliers);
router.post('/', authenticate([ROLES.ADMIN]), suppliersController.addSupplier);
router.delete('/:id', authenticate([ROLES.ADMIN]), suppliersController.deleteSupplier);

module.exports = router;
