const express = require('express');
const router = express.Router();
const { checkout, getReceipt } = require('../controllers/orderController');

router.post('/checkout', (req, res, next) => {
    console.log('Order checkout route hit');
    checkout(req, res, next);
});
router.get('/:id/receipt', getReceipt);

module.exports = router;
