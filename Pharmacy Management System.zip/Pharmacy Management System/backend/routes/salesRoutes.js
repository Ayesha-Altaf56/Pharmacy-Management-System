const express = require('express');
const router = express.Router();
const salesController = require('../controllers/salesController');
const authenticate = require('../middlewares/authMiddleware');
const { validateSale } = require('../middlewares/salesValidation');

// GET all sales - SECURED
router.get('/', authenticate(), salesController.getAllSales);

// POST a new sale - SECURED and Validated
router.post('/', authenticate(), validateSale, salesController.addSale);

module.exports = router;