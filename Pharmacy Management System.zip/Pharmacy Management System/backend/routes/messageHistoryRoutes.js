const express = require('express');
const router = express.Router();
const messageHistoryController = require('../controllers/messageHistoryController');
const authenticate = require('../middlewares/authMiddleware');
const { validateMessageHistory } = require('../middlewares/messageHistoryValidation');

// GET all message history records - SECURED
router.get('/', authenticate(), messageHistoryController.getAllMessageHistory);

// POST a new message history record - SECURED and Validated
router.post('/', authenticate(), validateMessageHistory, messageHistoryController.addMessageHistory);

module.exports = router;