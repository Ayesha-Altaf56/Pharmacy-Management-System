const express = require('express');
const router = express.Router();
const { getExpiryReport, removeExpiredStock } = require('../controllers/expiryController');

router.get('/', getExpiryReport);
router.delete('/:id', removeExpiredStock);

module.exports = router;