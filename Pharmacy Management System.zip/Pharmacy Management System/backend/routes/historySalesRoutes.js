const express = require('express');
const router = express.Router();
const historySalesController = require('../controllers/historySalesController');
const authenticate = require('../middlewares/authMiddleware');
const { validateHistorySale } = require('../middlewares/historySalesValidation');

// GET all history sales - SECURED
router.get('/', authenticate(), historySalesController.getAllHistorySales);

// POST a new history sale - SECURED and Validated
router.post('/', authenticate(), validateHistorySale, historySalesController.addHistorySale);

// DELETE a history sale - SECURED
router.delete('/:id', authenticate(), historySalesController.deleteHistorySale);

module.exports = router;