const express = require('express');
const router = express.Router();
const {
    getAllCompanies,
    addCompany,
    updateCompany,
    deleteCompany,
    getCompanyStats,
    getCompanyPurchaseHistory
} = require('../controllers/companyController');

router.get('/', getAllCompanies);
router.post('/', addCompany);
router.put('/:id', updateCompany);
router.delete('/:id', deleteCompany);
router.get('/stats', getCompanyStats);
router.get('/history', getCompanyPurchaseHistory);

module.exports = router;