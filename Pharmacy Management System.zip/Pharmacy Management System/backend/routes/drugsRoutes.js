const express = require('express');
const router = express.Router();
const drugsController = require('../controllers/drugsController');
const authenticate = require('../middlewares/authMiddleware');
const { validateDrug } = require('../middlewares/drugsValidation');
const { ROLES } = require('../utils/constants');

// GET all drugs - SECURED
router.get('/', authenticate(), drugsController.getAllDrugs);

// POST a new drug - SECURED and Validated
router.post('/', authenticate([ROLES.ADMIN]), validateDrug, drugsController.addDrug);

// DELETE a drug - SECURED
router.delete('/:barcode', authenticate([ROLES.ADMIN]), drugsController.deleteDrug);

// UPDATE a drug - SECURED and Validated
const { validateDrugUpdate } = require('../middlewares/drugsValidation');
router.put('/:barcode', authenticate([ROLES.ADMIN]), validateDrugUpdate, drugsController.updateDrug);

module.exports = router;