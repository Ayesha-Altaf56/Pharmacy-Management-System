const express = require('express');
const router = express.Router();
const purchaseController = require('../controllers/purchaseController');
const authenticate = require('../middlewares/authMiddleware');
const { validatePurchase } = require('../middlewares/purchaseValidation');
const { ROLES } = require('../utils/constants');

// GET all purchases - SECURED
router.get('/', authenticate(), purchaseController.getAllPurchases);

// POST a new purchase - SECURED and Validated
router.post('/', authenticate([ROLES.ADMIN]), validatePurchase, purchaseController.addPurchase);

module.exports = router;