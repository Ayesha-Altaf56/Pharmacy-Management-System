const express = require('express');
const router = express.Router();

// controller
const { login, getAllLoginRecords } = require('../controllers/loginController');

// middleware (if you want validation, otherwise remove)
const { validateLogin } = require('../middlewares/loginValidation');

// POST /api/login → Login user
router.post('/', validateLogin, login);

// GET /api/login → Get all login records (optional)
router.get('/', getAllLoginRecords);

module.exports = router;
