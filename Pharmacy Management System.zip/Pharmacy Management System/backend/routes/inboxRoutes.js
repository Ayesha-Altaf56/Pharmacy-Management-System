const express = require('express');
const router = express.Router();
const { getInboxMessages, getSentMessages, sendMessage, deleteMessage } = require('../controllers/inboxController');
const authenticate = require('../middlewares/authMiddleware');

// Base path: /api/inbox

router.get('/', authenticate(), getInboxMessages);
router.get('/sent', authenticate(), getSentMessages);
router.post('/', authenticate(), sendMessage);
router.delete('/:id', authenticate(), deleteMessage);

module.exports = router;