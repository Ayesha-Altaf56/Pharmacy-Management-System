const express = require('express');
const router = express.Router();
const { getCart, addToCart, removeFromCart, clearCart } = require('../controllers/cartController');

router.get('/:username', getCart);
router.post('/', addToCart);
router.delete('/:id', removeFromCart);
router.delete('/user/:username', clearCart);

module.exports = router;
