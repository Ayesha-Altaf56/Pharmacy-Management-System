const { getConnection } = require('./config/oracledb');

async function checkSalesColumns() {
    let conn;
    try {
        conn = await getConnection();
        const result = await conn.execute(
            `SELECT column_name FROM user_tab_columns WHERE table_name = 'SALES' ORDER BY column_id`,
            [],
            { outFormat: 4002 }
        );
        console.log('SALES table columns in database:');
        result.rows.forEach(row => {
            console.log(`  - "${row.COLUMN_NAME}"`);
        });
    } catch (err) {
        console.error('Error:', err.message);
    } finally {
        if (conn) await conn.close();
    }
}

checkSalesColumns();
