const { getConnection } = require('../../config/oracledb');

async function createExpiryTable() {
    // Expiry logic is currently handled by querying the DRUGS table directly.
    // This function is a placeholder to satisfy the application startup requirements.
    console.log('Expiry table creation skipped (logic uses DRUGS table).');
}

module.exports = { createExpiryTable };
