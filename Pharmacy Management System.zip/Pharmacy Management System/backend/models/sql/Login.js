const { getConnection } = require('../../config/oracledb');

async function createLoginTable() {
    let conn;
    try {
        conn = await getConnection();
        await conn.execute(`
      DECLARE
        t_count NUMBER;
      BEGIN
        SELECT count(*) INTO t_count FROM user_tables WHERE table_name = 'LOGIN';
        IF t_count = 0 THEN
          EXECUTE IMMEDIATE '
            CREATE TABLE LOGIN (
              USERNAME VARCHAR2(255) PRIMARY KEY,
              PASSWORD VARCHAR2(255) NOT NULL,
              USER_TYPE VARCHAR2(50) DEFAULT ''user'',
              LAST_LOGIN_DATE TIMESTAMP,
              LAST_LOGIN_TIME VARCHAR2(50)
            )
          ';
        END IF;
      END;
    `);
        console.log('Login table checked/created successfully.');
    } catch (err) {
        console.error('Error creating Login table:', err);
    } finally {
        if (conn) {
            try {
                await conn.close();
            } catch (e) {
                console.error('Error closing connection:', e);
            }
        }
    }
}

module.exports = { createLoginTable };
