const { getConnection } = require('../../config/oracledb');

async function createDrugsTable() {
    let conn;
    try {
        conn = await getConnection();
        await conn.execute(`
      DECLARE
        t_count NUMBER;
      BEGIN
        SELECT count(*) INTO t_count FROM user_tables WHERE table_name = 'DRUGS';
        IF t_count = 0 THEN
          EXECUTE IMMEDIATE '
            CREATE TABLE DRUGS (
              BARCODE VARCHAR2(255) PRIMARY KEY,
              NAME VARCHAR2(255) NOT NULL,
              TYPE VARCHAR2(100),
              DOSE VARCHAR2(100),
              CODE VARCHAR2(100),
                COST_PRICE NUMBER,
              SELLING_PRICE NUMBER,
              EXPIRY VARCHAR2(100),
              COMPANY_ID NUMBER,
              PRODUCTION_DATE DATE,
              EXPIRATION_DATE DATE,
              PLACE VARCHAR2(255),
              QUANTITY NUMBER DEFAULT 0,
              CONSTRAINT fk_company FOREIGN KEY (COMPANY_ID) REFERENCES COMPANIES(ID)
            )
          ';
        END IF;
      END;
    `);
        console.log('Drugs table checked/created successfully.');
    } catch (err) {
        console.error('Error creating Drugs table:', err);
    } finally {
        if (conn) {
            try {
                await conn.close();
            } catch (e) {
                console.error('Error closing connection:', e);
            }
        }
    }
}

module.exports = { createDrugsTable };
