const mongoose = require('mongoose');

const drugSchema = new mongoose.Schema({
  name: String,
  type: String,
  barcode: { type: String, required: true, unique: true },
  dose: String,
  code: String,
  cost_price: Number,
  selling_price: Number,
  expiry: String,
  company_name: String,
  production_date: Date,
  expiration_date: Date,
  place: String,
  quantity: Number
});

async function populateDrugs() {
  console.log('populateDrugs called (dummy)');
}

module.exports = { Drug: mongoose.model('Drug', drugSchema), populateDrugs };


