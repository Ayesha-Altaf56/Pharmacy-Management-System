const mongoose = require('mongoose');

const historySalesSchema = new mongoose.Schema({
  user_name: String,
  barcode: String,
  drugName: String, // Renamed from name to match frontend
  type: String,
  dose: String,
  quantity: Number,
  price: Number,
  amount: Number,
  date: Date,
  time: Date
});

async function populateHistorySales() {
  console.log('populateHistorySales called (dummy)');
}

module.exports = { HistorySales: mongoose.model('HistorySales', historySalesSchema), populateHistorySales };