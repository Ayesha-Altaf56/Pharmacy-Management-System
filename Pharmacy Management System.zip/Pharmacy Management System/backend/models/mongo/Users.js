const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  id: { type: Number, unique: true },
  name: String,
  username: String,
  role: String,
  dob: Date,
  address: String,
  phone: String,
  salary: Number,
  password: String,
  is_active: { type: Number, default: 1 }
});

const Users = mongoose.model('Users', userSchema);

async function populateUsers() {
  console.log('populateUsers called (dummy)');
}

module.exports = { Users, populateUsers };


