const mongoose = require('mongoose');

const messageHistorySchema = new mongoose.Schema({
  message_from: String,
  message_to: String,
  message_text: String
});

async function populateMessageHistory() {
  console.log('populateMessageHistory called (dummy)');
}

module.exports = { MessageHistory: mongoose.model('MessageHistory', messageHistorySchema), populateMessageHistory };


