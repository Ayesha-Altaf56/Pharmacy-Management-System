const mongoose = require('mongoose');

const purchaseSchema = new mongoose.Schema({
  barcode: String,
  drugName: String,
  type: String,
  company_name: String,
  quantity: Number,
  price: Number,
  amount: Number,
  date: { type: Date, default: Date.now },
  supplier_name: String
});

async function populatePurchases() {
  console.log('populatePurchases called (dummy)');
}

module.exports = { Purchase: mongoose.model('Purchase', purchaseSchema), populatePurchases };
