const mongoose = require('mongoose');

const companySchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  address: String,
  phone: String
});

const Company = mongoose.model('Company', companySchema);

const populateCompanies = async () => {
  try {
    const count = await Company.countDocuments();
    if (count === 0) {
      await Company.insertMany([
        { name: 'GSK', address: 'London, UK', phone: '+44 123 456 789' },
        { name: 'Abbott', address: 'Chicago, USA', phone: '+1 987 654 321' },
        { name: 'Sanofi', address: 'Paris, France', phone: '+33 1 23 45 67 89' },
        { name: 'Novartis', address: 'Basel, Switzerland', phone: '+41 61 324 11 11' },
        { name: 'Pfizer', address: 'New York, USA', phone: '+1 212 733 2323' }
      ]);
      console.log('Sample companies populated in MongoDB.');
    }
  } catch (err) {
    console.error('Error populating companies:', err);
  }
};

module.exports = { Company, populateCompanies };
