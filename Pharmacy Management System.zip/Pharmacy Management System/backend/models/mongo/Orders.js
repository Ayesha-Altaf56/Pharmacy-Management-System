const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    username: String,
    items: Array, // Store snapshot of items
    totalAmount: Number,
    orderDate: { type: Date, default: Date.now },
    status: { type: String, default: 'COMPLETED' }
});

async function populateOrders() {
    console.log('populateOrders called (dummy)');
}

module.exports = { Order: mongoose.model('Order', orderSchema), populateOrders };
