const mongoose = require('mongoose');

const inboxSchema = new mongoose.Schema({
  message_from: String,
  message_to: String,
  message_text: String
});

async function populateInbox() {
  console.log('populateInbox called (dummy)');
}

module.exports = { Inbox: mongoose.model('Inbox', inboxSchema), populateInbox };


