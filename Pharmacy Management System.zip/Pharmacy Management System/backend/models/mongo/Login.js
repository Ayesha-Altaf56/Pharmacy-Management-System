const mongoose = require('mongoose');

const loginSchema = new mongoose.Schema({
  username: String,
  password: String, // Added password field to match SQL login
  type: { type: String, default: 'user' },
  date: Date, // last login date (null initially)
  time: Date  // last login timestamp (null initially)
});

const Login = mongoose.model('Login', loginSchema);

async function populateLogins() {
  console.log('populateLogins called (dummy)');
}

module.exports = { Login, populateLogins };


