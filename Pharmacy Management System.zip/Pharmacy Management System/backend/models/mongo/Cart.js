const mongoose = require('mongoose');

const cartSchema = new mongoose.Schema({
    username: String,
    barcode: String,
    drugName: String,
    price: Number,
    quantity: Number,
    total: Number,
    createdAt: { type: Date, default: Date.now }
});

async function populateCart() {
    console.log('populateCart called (dummy)');
}

module.exports = { Cart: mongoose.model('Cart', cartSchema), populateCart };
