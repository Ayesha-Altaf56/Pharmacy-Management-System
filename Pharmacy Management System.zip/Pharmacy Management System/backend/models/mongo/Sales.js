const mongoose = require('mongoose');

const salesSchema = new mongoose.Schema({
  barcode: String,
  drugName: String, // Renamed from name to match frontend
  type: String,
  dose: String,
  quantity: Number,
  price: Number,
  amount: Number,
  date: Date
});

async function populateSales() {
  console.log('populateSales called (dummy)');
}

module.exports = { Sales: mongoose.model('Sales', salesSchema), populateSales };