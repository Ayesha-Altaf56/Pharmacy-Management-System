const mongoose = require('mongoose');

const expirySchema = new mongoose.Schema({
  drugName: String, // Renamed from product_name to match frontend
  product_code: String,
  expiryDate: Date, // Renamed from date_of_expiry to match frontend
  quantity_remain: Number
});

async function populateExpiry() {
  console.log('populateExpiry called (dummy)');
}

module.exports = { Expiry: mongoose.model('Expiry', expirySchema), populateExpiry };