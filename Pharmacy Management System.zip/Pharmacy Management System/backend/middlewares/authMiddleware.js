const jwt = require('jsonwebtoken');
// IMPORTANT: Replace 'YOUR_JWT_SECRET' with the actual secret key used to sign tokens
const JWT_SECRET = process.env.JWT_SECRET || 'pharmacy_app_secret_key_123';

/**
 * Middleware for authentication and role-based access control (RBAC).
 * It verifies the JWT and checks if the user's role is authorized for the route.
 * @param {string[]} [allowedRoles=[]] - Array of roles allowed to access the resource (e.g., ['admin', 'user']).
 */
const authenticate = (allowedRoles = []) => async (req, res, next) => {
  // 1. Check for token in the Authorization header
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization required. Token missing or malformed.' });
  }

  const token = authHeader.split(' ')[1];

  // 2. Verify the token
  try {
    const decoded = jwt.verify(token, JWT_SECRET);

    // 3. Attach user payload to request
    req.user = decoded;

    // 4. Role-Based Access Control (RBAC) Check
    if (allowedRoles.length > 0) {
      const userRole = req.user.Role || req.user.role || req.user.userType; // Check all casings

      if (!allowedRoles.includes(userRole)) {
        return res.status(403).json({ message: `Access denied. Role "${userRole}" is not authorized for this action.` });
      }
    }

    // Success: Continue to the next handler
    next();
  } catch (error) {
    // Token is invalid (expired, wrong signature, etc.)
    return res.status(403).json({ message: 'Invalid or expired token.', error: error.message });
  }
};

module.exports = authenticate;