/**
 * Global error handling middleware.
 * Ensures all unhandled errors return a consistent, structured JSON response.
 * This should be the last middleware loaded in your Express application.
 */
const errorMiddleware = (err, req, res, next) => {
  console.error(err.stack); // Log the error stack for debugging

  // Determine the appropriate HTTP status code
  // Use status code from error object if available, otherwise default to 500
  const statusCode = err.statusCode || 
                     err.status || 
                     res.statusCode === 200 ? 500 : res.statusCode;

  // Send a standardized JSON response
  res.status(statusCode).json({
    message: err.message || 'Internal Server Error',
    // Optionally include the error name/type for clarity (e.g., 'JsonWebTokenError')
    type: err.name || 'ServerError',
    // In production, you might hide the stack trace for security
    stack: process.env.NODE_ENV === 'production' ? null : err.stack,
  });
};

module.exports = errorMiddleware;