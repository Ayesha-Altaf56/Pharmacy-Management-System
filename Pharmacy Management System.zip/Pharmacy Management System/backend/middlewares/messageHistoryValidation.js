const { body, validationResult } = require('express-validator');

const validateMessageHistory = [
  body('messageFrom').notEmpty().withMessage('Message sender is required'),
  body('messageTo').notEmpty().withMessage('Message recipient is required'),
  body('messageText').notEmpty().withMessage('Message text is required'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    next();
  }
];

module.exports = { validateMessageHistory };