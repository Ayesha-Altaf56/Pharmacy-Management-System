const { body, validationResult } = require('express-validator');

const validateHistorySale = [
  body('userName').notEmpty().withMessage('User name is required'),
  body('barcode').notEmpty().withMessage('Barcode is required'),
  body('name').notEmpty().withMessage('Drug name is required'),
  body('type').notEmpty().withMessage('Drug type is required'),
  body('dose').notEmpty().withMessage('Dose is required'),
  body('quantity').isInt({ min: 1 }).withMessage('Quantity must be at least 1'),
  body('price').isNumeric().withMessage('Price must be a number'),
  body('amount').isNumeric().withMessage('Amount must be a number'),
  body('saleDate').isISO8601().withMessage('Sale date must be valid'),
  body('saleTime').matches(/^([01]\d|2[0-3]):([0-5]\d):([0-5]\d)$/).withMessage('Sale time must be in HH:mm:ss format'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    next();
  }
];

module.exports = { validateHistorySale };