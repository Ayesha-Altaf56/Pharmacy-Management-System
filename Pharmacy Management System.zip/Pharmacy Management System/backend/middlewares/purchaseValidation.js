const { body, validationResult } = require('express-validator');

const validatePurchase = [
  body('barcode').notEmpty().withMessage('Drug barcode is required'),
  body('drugName').notEmpty().withMessage('Drug name is required'),
  body('type').notEmpty().withMessage('Drug type is required'),
  body('company_name').notEmpty().withMessage('Company name is required'),
  body('quantity').isInt({ min: 1 }).withMessage('Quantity must be at least 1'),
  body('price').isNumeric().withMessage('Price must be a number'),
  // Amount is calculated on backend
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    next();
  }
];

module.exports = { validatePurchase };