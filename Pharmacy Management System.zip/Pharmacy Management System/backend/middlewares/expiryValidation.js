const { body, validationResult } = require('express-validator');

const validateExpiry = [
  body('productName').notEmpty().withMessage('Product name is required'),
  body('productCode').notEmpty().withMessage('Product code is required'),
  body('dateOfExpiry').isISO8601().withMessage('Expiry date must be a valid date'),
  body('quantityRemain')
    .isInt({ min: 1 })
    .withMessage('Quantity remaining must be a positive integer'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    next();
  }
];

module.exports = { validateExpiry };