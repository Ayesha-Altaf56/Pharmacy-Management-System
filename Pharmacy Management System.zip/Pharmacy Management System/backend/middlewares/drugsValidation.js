const { body, validationResult } = require('express-validator');

const validateDrug = [
  body('name').notEmpty().withMessage('Drug name is required'),
  body('type').notEmpty().withMessage('Drug type is required'),
  body('barcode').optional(),
  body('dose').optional(),
  body('code').optional(),
  body('costPrice').optional().isNumeric().withMessage('Cost price must be a number'),
  body('cost_price').optional().isNumeric().withMessage('Cost price must be a number'),
  body('sellingPrice').optional().isNumeric().withMessage('Selling price must be a number'),
  body('selling_price').optional().isNumeric().withMessage('Selling price must be a number'),
  body('expiry').optional(),
  body('companyName').optional(),
  body('company_name').optional(),
  body('productionDate').optional().isISO8601().withMessage('Production date must be a valid date'),
  body('expirationDate').optional().isISO8601().withMessage('Expiration date must be a valid date'),
  body('place').notEmpty().withMessage('Place is required'),
  body('quantity').isInt({ min: 1 }).withMessage('Quantity must be a positive integer'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    next();
  }
];

const validateDrugUpdate = [
  body('name').optional(),
  body('type').optional(),
  body('barcode').optional(), // Removed custom error
  body('dose').optional(),
  body('code').optional(),
  body('costPrice').optional().isNumeric(),
  body('cost_price').optional().isNumeric(),
  body('sellingPrice').optional().isNumeric(),
  body('selling_price').optional().isNumeric(),
  body('expiry').optional(),
  body('companyName').optional(),
  body('company_name').optional(),
  body('productionDate').optional().isISO8601(),
  body('expirationDate').optional().isISO8601(),
  body('place').optional(),
  body('quantity').optional().isInt(),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    next();
  }
];

module.exports = { validateDrug, validateDrugUpdate };