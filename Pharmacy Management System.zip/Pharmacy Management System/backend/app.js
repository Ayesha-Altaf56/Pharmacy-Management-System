// backend/app.js - Force Restart
'use strict';

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

// --- DATABASE CONFIGS ---
const { getConnection: getOracleConnection } = require('./config/oracledb');
const mongoDB = require('./config/mongodb');

// --- MONGO POPULATORS ---
const { populateCompanies } = require('./models/mongo/Company');
const { populateDrugs } = require('./models/mongo/Drug');
const { populateExpiry } = require('./models/mongo/Expiry');
const { populateHistorySales } = require('./models/mongo/HistorySales');
const { populateInbox } = require('./models/mongo/Inbox');
const { populateLogins } = require('./models/mongo/Login');
const { populateMessageHistory } = require('./models/mongo/MessageHistory');
const { populatePurchases } = require('./models/mongo/Purchase');
const { populateSales } = require('./models/mongo/Sales');
const { populateUsers } = require('./models/mongo/Users');
const { populateCart } = require('./models/mongo/Cart'); // Optional if we had one
const { populateOrders } = require('./models/mongo/Orders'); // Optional if we had one

// --- DATABASE DDL ---
const { createCompanyTable } = require('./models/sql/Company');
const { createDrugsTable } = require('./models/sql/Drug');
const { createExpiryTable } = require('./models/sql/Expiry');
const { createHistorySalesTable } = require('./models/sql/HistorySales');
const { createInboxTable } = require('./models/sql/Inbox');
const { createLoginTable } = require('./models/sql/Login');
const { createMessageHistoryTable } = require('./models/sql/MessageHistory');
const { createPurchaseTable } = require('./models/sql/Purchase');
const { createSalesTable } = require('./models/sql/Sales');
const { createUsersTable } = require('./models/sql/Users');
const { createSuppliersTable } = require('./models/sql/Supplier');
const { createCartTable } = require('./models/sql/Cart');
const { createOrdersTable } = require('./models/sql/Orders');

// --- MIDDLEWARES ---
const errorHandler = require('./middlewares/errorMiddleware');

// --- ROUTERS ---
const companyRoutes = require('./routes/companyRoutes');
const drugsRoutes = require('./routes/drugsRoutes');
const expiryRoutes = require('./routes/expiryRoutes');
const historySalesRoutes = require('./routes/historySalesRoutes');
const inboxRoutes = require('./routes/inboxRoutes');
const loginRoutes = require('./routes/loginRoutes');
const messageHistoryRoutes = require('./routes/messageHistoryRoutes');
const purchaseRoutes = require('./routes/purchaseRoutes');
const salesRoutes = require('./routes/salesRoutes');
const usersRoutes = require('./routes/usersRoutes');
const suppliersRoutes = require('./routes/suppliersRoutes');
const cartRoutes = require('./routes/cartRoutes');
const orderRoutes = require('./routes/orderRoutes');

const app = express();

// --- CORE MIDDLEWARE ---
app.use(cors());
app.use(bodyParser.json());

// --- SCHEMA INITIALIZATION ---
async function initializeSchema() {
  console.log('Initializing Oracle DB schema (DDL execution)...');
  try {
    await createCompanyTable();
    await createDrugsTable();
    await createExpiryTable();
    await createHistorySalesTable();
    await createInboxTable();
    await createLoginTable();
    await createMessageHistoryTable();
    await createPurchaseTable();
    await createSalesTable();
    await createUsersTable();
    await createSuppliersTable();
    await createCartTable();
    await createOrdersTable();
    console.log('Oracle DB schema initialization complete.');
  } catch (err) {
    console.error('CRITICAL DDL ERROR: Could not run schema scripts:', err.message);
  }
}

// --- API ROUTES ---
app.use('/api/companies', companyRoutes);
app.use('/api/drugs', drugsRoutes);
app.use('/api/expiry', expiryRoutes);
app.use('/api/history-sales', historySalesRoutes);
app.use('/api/inbox', inboxRoutes);
app.use('/api/login', loginRoutes);
app.use('/api/message-history', messageHistoryRoutes);
app.use('/api/purchases', purchaseRoutes);
app.use('/api/sales', salesRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/suppliers', suppliersRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/orders', orderRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// 404 Handler
app.use((req, res) => {
  res.status(404).json({ status: false, message: "Route not found" });
});

// Global Error Handler
app.use(errorHandler);

// --- SERVER START ---
async function testOracle() {
  try {
    const conn = await getOracleConnection();
    console.log('Oracle DB connected successfully!');
    await conn.close();
  } catch (err) {
    console.error('CRITICAL: Oracle DB connection failed:', err.message || err);
    throw err;
  }
}

function testMongo() {
  return new Promise((resolve, reject) => {
    if (mongoDB.readyState === 1) {
      console.log('MongoDB already connected!');
      return resolve();
    }
    mongoDB.once('open', () => {
      console.log('MongoDB connected successfully!');
      resolve();
    });
    mongoDB.on('error', (err) => {
      console.error('CRITICAL: MongoDB connection failed:', err.message || err);
      reject(err);
    });
  });
}

const withTimeout = (promise, ms, name) => {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`${name} connection timed out`)), ms))
  ]);
};

(async () => {
  console.log('Starting application, connecting to databases...');

  const [oracleStatus, mongoStatus] = await Promise.allSettled([
    withTimeout(testOracle(), 5000, 'OracleDB'),
    withTimeout(testMongo(), 5000, 'MongoDB')
  ]);

  if (oracleStatus.status === 'rejected') console.error(`OracleDB Status: FAILED (${oracleStatus.reason?.message})`);
  else console.log('OracleDB Status: CONNECTED');

  if (mongoStatus.status === 'rejected') console.error(`MongoDB Status: FAILED (${mongoStatus.reason?.message})`);
  else console.log('MongoDB Status: CONNECTED');

  const PORT = 4000; // Force 4000 to avoid conflicts

  if (oracleStatus.status === 'rejected' && mongoStatus.status === 'rejected') {
    console.error("SERVER ABORT: Could not establish connection to either Oracle or MongoDB. Exiting.");
  } else {
    // Initialize Schema (Oracle)
    if (oracleStatus.status === 'fulfilled') {
      await initializeSchema();
    }

    // Populate Mongo
    if (mongoStatus.status === 'fulfilled') {
      try {
        console.log('Populating MongoDB collections with sample data...');
        await populateCompanies();
        await populateDrugs();
        await populateExpiry();
        await populateHistorySales();
        await populateInbox();
        await populateLogins();
        await populateMessageHistory();
        await populatePurchases();
        await populateSales();
        await populateUsers();
        console.log('MongoDB population complete.');
      } catch (err) {
        console.error('Error populating MongoDB collections:', err.message || err);
      }
    }
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  }
})();