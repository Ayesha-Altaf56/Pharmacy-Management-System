const oracledb = require('oracledb');
const bcrypt = require('bcrypt');
const { getConnection } = require('../backend/config/oracledb');

async function resetPassword() {
    const args = process.argv.slice(2);
    if (args.length < 2) {
        console.log('Usage: node scripts/reset_user_password.js <username> <new_password>');
        process.exit(1);
    }

    const username = args[0];
    const newPassword = args[1];

    let conn;
    try {
        conn = await getConnection();
        console.log(`Resetting password for user: ${username}`);

        const hashedPassword = await bcrypt.hash(newPassword, 10);
        const now = new Date();

        const result = await conn.execute(
            `UPDATE LOGIN SET PASSWORD = :bPassword, LAST_LOGIN_DATE = :bDate, LAST_LOGIN_TIME = :bTime WHERE USERNAME = :bUsername`,
            {
                bPassword: hashedPassword,
                bDate: now,
                bTime: now.toLocaleTimeString(),
                bUsername: username
            },
            { autoCommit: true }
        );

        if (result.rowsAffected === 0) {
            console.log('User not found.');
        } else {
            console.log('Password updated successfully.');
        }

    } catch (err) {
        console.error('Error resetting password:', err.message);
    } finally {
        if (conn) {
            try {
                await conn.close();
            } catch (e) {
                console.error(e);
            }
        }
    }
}

resetPassword();
