const oracledb = require('oracledb');
const { getConnection } = require('../backend/config/oracledb');

async function fixSchema() {
    let conn;
    try {
        conn = await getConnection();
        console.log('Connected to OracleDB.');

        console.log('Altering LOGIN table to resize USER_TYPE column...');
        await conn.execute(
            `ALTER TABLE LOGIN MODIFY (USER_TYPE VARCHAR2(50))`,
            {},
            { autoCommit: true }
        );
        console.log('Schema updated successfully.');

    } catch (err) {
        console.error('Error updating schema:', err.message);
    } finally {
        if (conn) {
            try {
                await conn.close();
                console.log('Connection closed.');
            } catch (e) {
                console.error('Error closing connection:', e);
            }
        }
    }
}

fixSchema();
