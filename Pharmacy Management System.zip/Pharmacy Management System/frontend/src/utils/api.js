const API_BASE_URL = "/api"; // backend base URL via proxy

// Build headers
const createHeaders = (authToken = null) => {
  const headers = { "Content-Type": "application/json" };
  let token = authToken;
  if (!token && typeof localStorage !== 'undefined') {
    token = localStorage.getItem('authToken');
  }
  if (token) headers.Authorization = `Bearer ${token}`;
  return headers;
};

// GET request
export async function fetchData(endpoint, authToken = null) {
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint.slice(1) : endpoint;
  const res = await fetch(`${API_BASE_URL}/${cleanEndpoint}`, {
    method: "GET",
    headers: createHeaders(authToken),
  });
  if (!res.ok) throw new Error(`GET ${endpoint} failed: ${res.status}`);
  return await res.json();
}

// POST request
export async function postData(endpoint, payload, authToken = null) {
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint.slice(1) : endpoint;
  const res = await fetch(`${API_BASE_URL}/${cleanEndpoint}`, {
    method: "POST",
    headers: createHeaders(authToken),
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`POST ${endpoint} failed: ${res.status}`);
  return await res.json();
}

// PUT request
export async function putData(endpoint, payload, authToken = null) {
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint.slice(1) : endpoint;
  const res = await fetch(`${API_BASE_URL}/${cleanEndpoint}`, {
    method: "PUT",
    headers: createHeaders(authToken),
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`PUT ${endpoint} failed: ${res.status}`);
  return await res.json();
}

// DELETE request
export async function deleteData(endpoint, authToken = null) {
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint.slice(1) : endpoint;
  const res = await fetch(`${API_BASE_URL}/${cleanEndpoint}`, {
    method: "DELETE",
    headers: createHeaders(authToken),
  });
  if (!res.ok) throw new Error(`DELETE ${endpoint} failed: ${res.status}`);
  return await res.json();
}
