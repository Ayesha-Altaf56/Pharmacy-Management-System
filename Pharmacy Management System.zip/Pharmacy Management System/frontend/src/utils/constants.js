// frontend/src/utils/constants.js

// User Roles
export const ROLES = {
  ADMIN: 'admin',
  USER: 'user',
};

// Drug Types
export const DRUG_TYPES = {
  TABLET: 'Tablet',
  SYRUP: 'Syrup',
  INJECTION: 'Injection',
};

// Statuses
export const STATUS = {
  ACTIVE: 'Active',
  INACTIVE: 'Inactive',
  EXPIRED: 'Expired',
};

// Backend API Endpoints
const BASE_URL = 'http://localhost:3000/api';

export const API_ENDPOINTS = {
  COMPANY: `${BASE_URL}/company`,
  DRUGS: `${BASE_URL}/drugs`,
  EXPIRY: `${BASE_URL}/expiry`,
  HISTORY_SALES: `${BASE_URL}/history-sales`,
  INBOX: `${BASE_URL}/inbox`,
  LOGIN: `${BASE_URL}/login`,
  MESSAGE_HISTORY: `${BASE_URL}/message-history`,
  PURCHASE: `${BASE_URL}/purchase`,
  SALES: `${BASE_URL}/sales`,
  USERS: `${BASE_URL}/users`,
};
