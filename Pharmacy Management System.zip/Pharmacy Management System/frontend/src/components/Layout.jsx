import React from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import './Layout.css';

const Layout = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const username = localStorage.getItem('username') || 'Admin';

    const handleLogout = () => {
        localStorage.removeItem('authToken');
        localStorage.removeItem('username');
        localStorage.removeItem('role');
        navigate('/login');
    };

    const isDashboard = location.pathname === '/dashboard';

    return (
        <div className="app-layout">
            {/* Main Content (Full Width) */}
            <main className="main-content">
                <header className="top-header">
                    <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                        {!isDashboard && (
                            <button
                                onClick={() => navigate('/dashboard')}
                                className="btn"
                                style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    padding: '8px 16px',
                                    backgroundColor: 'transparent',
                                    color: '#007bff',
                                    border: '1px solid #007bff',
                                    borderRadius: '20px',
                                    fontWeight: '500',
                                    transition: 'all 0.2s',
                                    cursor: 'pointer'
                                }}
                                onMouseEnter={e => { e.currentTarget.style.backgroundColor = '#007bff'; e.currentTarget.style.color = 'white'; }}
                                onMouseLeave={e => { e.currentTarget.style.backgroundColor = 'transparent'; e.currentTarget.style.color = '#007bff'; }}
                            >
                                <span>&larr;</span> Dashboard
                            </button>
                        )}
                        <h3>Pharmacy System</h3>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                        <span>Welcome, {username}</span>
                        <button onClick={handleLogout} className="btn btn-danger btn-sm">Logout</button>
                    </div>
                </header>
                <div className="content-area">
                    <Outlet />
                </div>
            </main>
        </div>
    );
};

export default Layout;
