import React from 'react';
import { Outlet, Navigate } from 'react-router-dom';

const PrivateRoute = ({ allowedRoles }) => {
    const token = localStorage.getItem('authToken');
    const userRole = localStorage.getItem('role');

    if (!token) {
        return <Navigate to="/login" />;
    }

    if (allowedRoles && !allowedRoles.includes(userRole)) {
        // Redirect to appropriate dashboard based on role
        if (userRole === 'customer') return <Navigate to="/customer/dashboard" />;
        if (userRole === 'admin') return <Navigate to="/dashboard" />;
        return <Navigate to="/login" />;
    }

    return <Outlet />;
};

export default PrivateRoute;
