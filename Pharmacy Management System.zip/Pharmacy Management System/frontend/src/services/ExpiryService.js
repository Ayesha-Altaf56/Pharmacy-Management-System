import { fetchData, deleteData } from '../utils/api';

const BASE_ENDPOINT = 'expiry';

export const getExpiryReport = async () => {
  return fetchData(BASE_ENDPOINT);
};

export const removeExpiredStock = async (id) => {
  return deleteData(`${BASE_ENDPOINT}/${id}`);
};
