// frontend/services/DrugsService.js
import { fetchData, postData, putData, deleteData } from '../utils/api';

const BASE_ENDPOINT = 'drugs';

// Use named exports for direct imports in screens
export const getDrugs = async () => {
  return fetchData(BASE_ENDPOINT);
};

export const addDrug = async (drug) => {
  return postData(BASE_ENDPOINT, drug);
};

export const updateDrug = async (barcode, drug) => {
  return putData(`${BASE_ENDPOINT}/${barcode}`, drug);
};

export const deleteDrug = async (barcode) => {
  return deleteData(`${BASE_ENDPOINT}/${barcode}`);
};
