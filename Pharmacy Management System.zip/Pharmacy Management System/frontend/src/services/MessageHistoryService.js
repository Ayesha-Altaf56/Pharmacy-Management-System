// frontend/services/MessageHistoryService.js
import { fetchData, postData } from '../utils/api';

const BASE_ENDPOINT = 'message-history';

// Named exports for direct use in screens
export const getMessageHistory = async () => {
  const res = await fetchData(BASE_ENDPOINT);
  if (res && res.data) return res.data;
  return res;
};

export const addMessageHistory = async (message) => {
  return postData(BASE_ENDPOINT, message);
};
