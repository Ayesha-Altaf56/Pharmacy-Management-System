// frontend/services/HistorySalesService.js
import { fetchData, postData } from '../utils/api';

const BASE_ENDPOINT = 'history-sales';

// Named exports for direct use in screens
export const getHistorySales = async (params = {}) => {
  const queryString = new URLSearchParams(params).toString();
  return fetchData(`${BASE_ENDPOINT}?${queryString}`);
};

export const addHistorySale = async (sale) => {
  return postData(BASE_ENDPOINT, sale);
};
