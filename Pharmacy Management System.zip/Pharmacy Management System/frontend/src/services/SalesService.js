// frontend/services/SalesService.js
import { fetchData, postData } from '../utils/api';

const BASE_ENDPOINT = 'sales';

// Named exports for direct use in screens
export const getSales = async () => {
  return fetchData(BASE_ENDPOINT);
};

export const addSale = async (sale) => {
  return postData(BASE_ENDPOINT, sale);
};
