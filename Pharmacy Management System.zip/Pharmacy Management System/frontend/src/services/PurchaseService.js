// frontend/services/PurchaseService.js
import { fetchData, postData } from '../utils/api';

const BASE_ENDPOINT = 'purchase';

// Named exports for direct use in screens
export const getPurchases = async () => {
  return fetchData(BASE_ENDPOINT);
};

export const addPurchase = async (purchase) => {
  return postData(BASE_ENDPOINT, purchase);
};
