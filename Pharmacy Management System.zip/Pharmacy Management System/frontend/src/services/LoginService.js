import { postData } from "../utils/api";

const BASE_ENDPOINT = "login"; // matches backend route /api/login

/**
 * Sends login request to backend.
 * @param {{ username: string, password: string }} credentials
 */
export const loginUser = async (credentials) => {
  // Clear any existing session data
  localStorage.removeItem('authToken');
  localStorage.removeItem('username');
  localStorage.removeItem('role');

  const res = await postData(BASE_ENDPOINT, credentials);
  // If backend returns a token, store it for authenticated requests
  if (res && res.token) {
    try {
      localStorage.setItem('authToken', res.token);
      if (res.username) {
        localStorage.setItem('username', res.username);
      }
      if (res.userType || res.role) {
        localStorage.setItem('role', res.userType || res.role);
      }
    } catch (e) {
      // ignore storage errors in environments without localStorage
    }
  }
  return res;
};
