import { fetchData, postData, putData, deleteData } from '../utils/api';

const BASE_ENDPOINT = 'companies';

export const getAllCompanies = async () => {
  return fetchData(BASE_ENDPOINT);
};

export const getCompanies = getAllCompanies; // Alias for compatibility

export const addCompany = async (company) => {
  return postData(BASE_ENDPOINT, company);
};

export const updateCompany = async (id, company) => {
  return putData(`${BASE_ENDPOINT}/${id}`, company);
};

export const deleteCompany = async (id) => {
  return deleteData(`${BASE_ENDPOINT}/${id}`);
};

export const getCompanyStats = async (name) => {
  return fetchData(`${BASE_ENDPOINT}/stats?name=${encodeURIComponent(name)}`);
};

export const getCompanyPurchaseHistory = async (name) => {
  return fetchData(`${BASE_ENDPOINT}/history?name=${encodeURIComponent(name)}`);
};
