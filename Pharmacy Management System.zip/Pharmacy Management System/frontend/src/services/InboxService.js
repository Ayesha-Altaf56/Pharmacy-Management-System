import { fetchData, postData, deleteData } from '../utils/api';

const BASE_ENDPOINT = 'inbox';

export const getInboxMessages = async (user) => {
  return fetchData(`${BASE_ENDPOINT}?user=${user}`);
};

export const getSentMessages = async (user) => {
  return fetchData(`${BASE_ENDPOINT}/sent?user=${user}`);
};

export const sendMessage = async (messageData) => {
  return postData(`${BASE_ENDPOINT}`, messageData);
};

export const deleteMessage = async (id) => {
  return deleteData(`${BASE_ENDPOINT}/${id}`);
};
