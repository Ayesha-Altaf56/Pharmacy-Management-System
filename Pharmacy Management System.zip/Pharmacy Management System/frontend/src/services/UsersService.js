import { fetchData, postData, putData, deleteData } from '../utils/api';

const BASE_ENDPOINT = 'users';

export const getAllUsers = async () => {
  return fetchData(BASE_ENDPOINT);
};

export const addUser = async (user) => {
  return postData(BASE_ENDPOINT, user);
};

export const updateUser = async (id, user) => {
  return putData(`${BASE_ENDPOINT}/${id}`, user);
};

export const deleteUser = async (id) => {
  return deleteData(`${BASE_ENDPOINT}/${id}`);
};
