import React from 'react';

const ExpiryWidget = ({ expiry }) => {
  return (
    <div className="widget-card">
      <p>Drug ID: {expiry.DRUGID}</p>
      <p>Expiry Date: {expiry.EXPIRYDATE}</p>
    </div>
  );
};

export default ExpiryWidget;
