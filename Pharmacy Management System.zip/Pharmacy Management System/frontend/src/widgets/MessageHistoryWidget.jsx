import React from 'react';

const MessageHistoryWidget = ({ message }) => {
  return (
    <div className="widget-card">
      <p>From: {message.SENDER}</p>
      <p>Message: {message.MESSAGE}</p>
      <p>Sent At: {message.DATE}</p>
    </div>
  );
};

export default MessageHistoryWidget;
