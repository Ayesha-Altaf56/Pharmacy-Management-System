import React from 'react';

const CompanyWidget = ({ company }) => {
  return (
    <div className="widget-card">
      <h3>{company.NAME}</h3>
      <p>Address: {company.ADDRESS}</p>
      <p>Phone: {company.PHONE}</p>
    </div>
  );
};

export default CompanyWidget;
