import React from 'react';

const UserWidget = ({ user }) => {
  return (
    <div className="widget-card">
      <p>Username: {user.USERNAME}</p>
      <p>Email: {user.EMAIL}</p>
      <p>Role: {user.ROLE}</p>
    </div>
  );
};

export default UserWidget;
