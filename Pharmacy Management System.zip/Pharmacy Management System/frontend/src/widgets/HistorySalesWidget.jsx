import React from 'react';

const HistorySalesWidget = ({ sale }) => {
  return (
    <div className="widget-card">
      <p>Sale ID: {sale.ID}</p>
      <p>Drug ID: {sale.DRUGID}</p>
      <p>Quantity: {sale.QUANTITY}</p>
      <p>Date: {sale.DATE}</p>
    </div>
  );
};

export default HistorySalesWidget;
