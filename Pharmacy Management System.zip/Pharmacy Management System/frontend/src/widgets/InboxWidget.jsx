import React from 'react';

const InboxWidget = ({ message }) => {
  return (
    <div className="widget-card">
      <p>From: {message.SENDER}</p>
      <p>Message: {message.MESSAGE}</p>
      <p>Date: {message.DATE}</p>
    </div>
  );
};

export default InboxWidget;
