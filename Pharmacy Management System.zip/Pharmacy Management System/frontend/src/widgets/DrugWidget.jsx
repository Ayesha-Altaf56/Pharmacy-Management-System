import React from 'react';

const DrugWidget = ({ drug }) => {
  return (
    <div className="widget-card">
      <h3>{drug.NAME}</h3>
      <p>Company ID: {drug.COMPANYID}</p>
      <p>Price: {drug.PRICE}</p>
      <p>Stock: {drug.STOCK}</p>
    </div>
  );
};

export default DrugWidget;
