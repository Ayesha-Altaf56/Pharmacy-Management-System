import React from 'react';

const PurchaseWidget = ({ purchase }) => {
  return (
    <div className="widget-card">
      <p>Purchase ID: {purchase.ID}</p>
      <p>Drug ID: {purchase.DRUGID}</p>
      <p>Quantity: {purchase.QUANTITY}</p>
      <p>Date: {purchase.DATE}</p>
    </div>
  );
};

export default PurchaseWidget;
