// frontend/src/App.jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import './App.css'; // Import Global Styles

// Screens
import DashboardScreen from './screens/DashBoardScreen';
import DrugsScreen from './screens/DrugsScreen';
import SalesScreen from './screens/SalesScreen';
import UsersScreen from './screens/UsersScreen';
import CompanyScreen from './screens/CompanyScreen';
import ExpiryScreen from './screens/ExpiryScreen';
import PurchaseScreen from './screens/PurchaseScreen';
import HistorySalesScreen from './screens/HistorySalesScreen';
import InboxScreen from './screens/InboxScreen';
import MessageHistoryScreen from './screens/MessageHistoryScreen';
import LoginScreen from './screens/LoginScreen';
import SuppliersScreen from './screens/SuppliersScreen'; // Added
import PrivateRoute from './components/PrivateRoute';
import Layout from './components/Layout';

// Customer Screens
import CustomerDashboard from './screens/customer/CustomerDashboard';
import BrowseMedicines from './screens/customer/BrowseMedicines';
import CartScreen from './screens/customer/CartScreen';
import CheckoutScreen from './screens/customer/CheckoutScreen';
import CustomerMessages from './screens/customer/CustomerMessages';

const App = () => {
  console.log('App rendering...');
  return (
    <Router future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
      <Routes>
        {/* Default redirect to login */}
        <Route path="/" element={<Navigate to="/login" />} />

        {/* Login - Public */}
        <Route path="/login" element={<LoginScreen />} />

        {/* Admin Protected Routes */}
        <Route element={<PrivateRoute allowedRoles={['admin']} />}>
          <Route element={<Layout />}>
            <Route path="/dashboard" element={<DashboardScreen />} />
            <Route path="/drugs" element={<DrugsScreen />} />
            <Route path="/sales" element={<SalesScreen />} />
            <Route path="/users" element={<UsersScreen />} />
            <Route path="/companies" element={<CompanyScreen />} />
            <Route path="/expiry" element={<ExpiryScreen />} />
            <Route path="/purchases" element={<PurchaseScreen />} />
            <Route path="/history-sales" element={<HistorySalesScreen />} />
            <Route path="/inbox" element={<InboxScreen />} />
            <Route path="/message-history" element={<MessageHistoryScreen />} />
            <Route path="/suppliers" element={<SuppliersScreen />} />
          </Route>
        </Route>

        {/* Customer Protected Routes */}
        <Route element={<PrivateRoute allowedRoles={['customer']} />}>
          <Route path="/customer/dashboard" element={<CustomerDashboard />} />
          <Route path="/customer/browse" element={<BrowseMedicines />} />
          <Route path="/customer/cart" element={<CartScreen />} />
          <Route path="/customer/checkout" element={<CheckoutScreen />} />
          <Route path="/customer/messages" element={<CustomerMessages />} />
        </Route>

        {/* Catch all */}
        <Route path="*" element={<div>404 - Page Not Found</div>} />
      </Routes>
    </Router>
  );
};

export default App;
