import React from 'react';
import { useNavigate } from 'react-router-dom';
import './CustomerDashboard.css';

const CustomerDashboard = () => {
    const navigate = useNavigate();
    const username = localStorage.getItem('username') || 'Customer';

    const handleLogout = () => {
        localStorage.removeItem('authToken');
        localStorage.removeItem('username');
        localStorage.removeItem('role');
        navigate('/');
    };

    const menuItems = [
        { title: 'Browse Medicines', icon: '💊', path: '/customer/browse', color: '#4facfe' },
        { title: 'My Cart', icon: '🛒', path: '/customer/cart', color: '#00f2fe' },
        { title: 'Messages', icon: '💬', path: '/customer/messages', color: '#43e97b' }
    ];

    return (
        <div className="customer-dashboard">
            <header className="dashboard-header">
                <div className="header-content">
                    <div>
                        <h1>Welcome, {username}</h1>
                        <p>What would you like to do today?</p>
                    </div>
                    <button onClick={handleLogout} className="logout-btn">
                        Logout 🚪
                    </button>
                </div>
            </header>

            <div className="dashboard-grid">
                {menuItems.map((item, index) => (
                    <div
                        key={index}
                        className="dashboard-card"
                        onClick={() => navigate(item.path)}
                        style={{ borderTop: `4px solid ${item.color}` }}
                    >
                        <div className="card-icon" style={{ color: item.color }}>{item.icon}</div>
                        <h3>{item.title}</h3>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default CustomerDashboard;
