import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { postData } from '../../utils/api';
import './CustomerCommon.css';

const CheckoutScreen = () => {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);
    const [receipt, setReceipt] = useState(null);
    const username = localStorage.getItem('username') || 'Customer';

    const handleCheckout = async () => {
        setLoading(true);
        try {
            const res = await postData('orders/checkout', { username });
            // Fetch receipt details (mocked for now as order summary)
            setReceipt({
                orderId: res.orderId,
                message: res.message,
                date: new Date().toLocaleString(),
                items: res.items,
                totalAmount: res.totalAmount
            });
        } catch (err) {
            alert('Checkout failed: ' + err.message);
        } finally {
            setLoading(false);
        }
    };

    if (receipt) {
        return (
            <div className="customer-page">
                <div className="receipt-card">
                    <h2>✅ Order Confirmed!</h2>
                    <p><strong>Order ID:</strong> {receipt.orderId}</p>
                    <p><strong>Date:</strong> {receipt.date}</p>

                    <div className="invoice-details">
                        <h3>Invoice</h3>
                        <table className="invoice-table">
                            <thead>
                                <tr>
                                    <th>Item</th>
                                    <th>Qty</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                {receipt.items && receipt.items.map((item, idx) => (
                                    <tr key={idx}>
                                        <td>{item.DRUG_NAME || item.drugName}</td>
                                        <td>{item.QUANTITY || item.quantity}</td>
                                        <td>${item.PRICE || item.price}</td>
                                        <td>${item.TOTAL || item.total}</td>
                                    </tr>
                                ))}
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colSpan="3"><strong>Total Amount</strong></td>
                                    <td><strong>${receipt.totalAmount}</strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    <p className="thank-you">Thank you for your purchase!</p>
                    <button onClick={() => navigate('/customer/dashboard')} className="home-btn">Back to Home</button>
                </div>
            </div>
        );
    }

    return (
        <div className="customer-page">
            <div className="page-header">
                <button onClick={() => navigate('/customer/cart')} className="back-btn">← Back</button>
                <h2>Checkout</h2>
            </div>

            <div className="checkout-confirm">
                <p>Are you sure you want to place this order?</p>
                <button onClick={handleCheckout} disabled={loading} className="confirm-btn">
                    {loading ? 'Processing...' : 'Confirm Order'}
                </button>
            </div>
        </div>
    );
};

export default CheckoutScreen;
