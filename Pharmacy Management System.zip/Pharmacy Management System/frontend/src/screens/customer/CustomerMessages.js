import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchData as getData, postData } from '../../utils/api';
import './CustomerCommon.css';

const CustomerMessages = () => {
    const navigate = useNavigate();
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const username = localStorage.getItem('username') || 'Customer';

    useEffect(() => {
        fetchMessages();
    }, []);

    const fetchMessages = async () => {
        try {
            // Get messages sent TO this user (from Admin)
            const inbox = await getData(`inbox?user=${username}`);
            // Get messages sent BY this user (to Admin)
            const sent = await getData(`inbox/sent?user=${username}`);

            // Combine and sort
            const all = [...inbox, ...sent].sort((a, b) =>
                new Date(a.DATE_SENT || a.date_sent) - new Date(b.DATE_SENT || b.date_sent)
            );
            setMessages(all);
        } catch (err) {
            console.error('Error fetching messages:', err);
        }
    };

    const sendMessage = async (e) => {
        e.preventDefault();
        if (!newMessage.trim()) return;

        try {
            await postData('inbox', {
                from: username,
                to: 'Admin', // Always send to Admin
                message: newMessage
            });
            setNewMessage('');
            fetchMessages();
        } catch (err) {
            alert('Failed to send message');
        }
    };

    return (
        <div className="customer-page">
            <div className="page-header">
                <button onClick={() => navigate('/customer/dashboard')} className="back-btn">← Back</button>
                <h2>Messages with Admin</h2>
            </div>

            <div className="messages-list">
                {messages.length === 0 ? (
                    <p className="no-data">No messages yet.</p>
                ) : (
                    messages.map((msg, idx) => {
                        const isMe = (msg.MESSAGE_FROM || msg.message_from) === username;
                        return (
                            <div key={idx} className={`message-bubble ${isMe ? 'my-message' : 'admin-message'}`}>
                                <p>{msg.MESSAGE_TEXT || msg.message_text}</p>
                                <span className="msg-time">{new Date(msg.DATE_SENT || msg.date_sent).toLocaleTimeString()}</span>
                            </div>
                        );
                    })
                )}
            </div>

            <form onSubmit={sendMessage} className="message-input-area">
                <input
                    type="text"
                    value={newMessage}
                    onChange={e => setNewMessage(e.target.value)}
                    placeholder="Type a message..."
                />
                <button type="submit">Send</button>
            </form>
        </div>
    );
};

export default CustomerMessages;
