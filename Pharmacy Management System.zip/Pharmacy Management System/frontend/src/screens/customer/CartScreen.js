import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchData as getData, deleteData } from '../../utils/api';
import './CustomerCommon.css';

const CartScreen = () => {
    const navigate = useNavigate();
    const [cartItems, setCartItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const username = localStorage.getItem('username') || 'Customer';

    useEffect(() => {
        fetchCart();
    }, []);

    const fetchCart = async () => {
        try {
            const data = await getData(`cart/${username}`);
            setCartItems(data);
        } catch (err) {
            console.error('Error fetching cart:', err);
        } finally {
            setLoading(false);
        }
    };

    const removeFromCart = async (id) => {
        try {
            await deleteData(`cart/${id}`);
            fetchCart();
        } catch (err) {
            alert('Failed to remove item');
        }
    };

    const total = cartItems.reduce((sum, item) => sum + (item.TOTAL || item.total), 0);

    return (
        <div className="customer-page">
            <div className="page-header">
                <button onClick={() => navigate('/customer/dashboard')} className="back-btn">← Back</button>
                <h2>My Cart</h2>
                <button
                    onClick={fetchCart}
                    style={{ marginLeft: 'auto', padding: '8px 16px', backgroundColor: '#17a2b8', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
                >
                    Refresh Data
                </button>
            </div>

            {loading ? <p>Loading...</p> : (
                <>
                    <div className="cart-list">
                        {cartItems.length === 0 ? <p>Your cart is empty.</p> : (
                            cartItems.map((item, idx) => (
                                <div key={idx} className="cart-item">
                                    <div className="item-info">
                                        <h4>{item.DRUG_NAME || item.drugName}</h4>
                                        <p>Qty: {item.QUANTITY || item.quantity} x ${item.PRICE || item.price}</p>
                                    </div>
                                    <div className="item-total">
                                        <p>${item.TOTAL || item.total}</p>
                                        <button onClick={() => removeFromCart(item.ID || item._id)} className="remove-btn">×</button>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>

                    {cartItems.length > 0 && (
                        <div className="cart-summary">
                            <h3>Total: ${total.toFixed(2)}</h3>
                            <button onClick={() => navigate('/customer/checkout')} className="checkout-btn">Proceed to Checkout</button>
                        </div>
                    )}
                </>
            )}
        </div>
    );
};

export default CartScreen;
