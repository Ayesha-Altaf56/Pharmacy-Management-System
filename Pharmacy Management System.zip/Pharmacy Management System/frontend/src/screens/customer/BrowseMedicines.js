import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchData as getData, postData } from '../../utils/api';
import './CustomerCommon.css';

const BrowseMedicines = () => {
    const navigate = useNavigate();
    const [medicines, setMedicines] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const username = localStorage.getItem('username') || 'Customer';

    useEffect(() => {
        fetchMedicines();
    }, []);

    const fetchMedicines = async () => {
        try {
            const data = await getData('drugs');
            setMedicines(data);
        } catch (err) {
            console.error('Error fetching medicines:', err);
        } finally {
            setLoading(false);
        }
    };

    const addToCart = async (drug) => {
        try {
            await postData('cart', {
                username,
                barcode: drug.BARCODE || drug.barcode,
                quantity: 1
            });
            alert('Added to cart!');
        } catch (err) {
            alert('Failed to add to cart: ' + err.message);
        }
    };

    const filteredMedicines = medicines.filter(m =>
        (m.NAME || m.name || '').toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="customer-page">
            <div className="page-header">
                <button onClick={() => navigate('/customer/dashboard')} className="back-btn">← Back</button>
                <h2>Browse Medicines</h2>
                <button
                    onClick={fetchMedicines}
                    style={{ marginLeft: '10px', padding: '8px 16px', backgroundColor: '#17a2b8', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
                >
                    Refresh Data
                </button>
                <button onClick={() => navigate('/customer/cart')} className="cart-btn">🛒 Cart</button>
            </div>

            <div className="search-bar">
                <input
                    type="text"
                    placeholder="Search medicines..."
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                />
            </div>

            {loading ? <p>Loading...</p> : (
                <div className="medicines-grid">
                    {filteredMedicines.length === 0 ? (
                        <p className="no-data">No medicines found. Please ask Admin to add stock.</p>
                    ) : (
                        filteredMedicines.map((drug, idx) => (
                            <div key={idx} className="medicine-card">
                                <h3>{drug.NAME || drug.name}</h3>
                                <p className="price">${drug.SELLING_PRICE || drug.selling_price}</p>
                                <p className="stock">Stock: {drug.QUANTITY || drug.quantity}</p>
                                <button
                                    onClick={() => addToCart(drug)}
                                    disabled={(drug.QUANTITY || drug.quantity) <= 0}
                                >
                                    {(drug.QUANTITY || drug.quantity) > 0 ? 'Add to Cart' : 'Out of Stock'}
                                </button>
                            </div>
                        ))
                    )}
                </div>
            )}
        </div>
    );
};

export default BrowseMedicines;
