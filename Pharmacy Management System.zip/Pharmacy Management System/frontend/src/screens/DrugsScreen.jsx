import React, { useState, useEffect } from 'react';
import { fetchData, postData, putData, deleteData } from '../utils/api';

const DrugsScreen = () => {
  const [drugs, setDrugs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterCompany, setFilterCompany] = useState('');

  // Form State
  const [isEditing, setIsEditing] = useState(false);
  const [currentDrugBarcode, setCurrentDrugBarcode] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    type: '',
    barcode: '',
    dose: '',
    code: '',
    cost_price: '',
    selling_price: '',
    expiry: '',
    company_name: '',
    production_date: '',
    expiration_date: '',
    place: '',
    quantity: ''
  });

  useEffect(() => {
    loadDrugs();
  }, []);

  const loadDrugs = async () => {
    try {
      setLoading(true);
      const data = await fetchData('/drugs');
      setDrugs(data || []);
    } catch (error) {
      console.error('Error loading drugs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (isEditing) {
        await putData(`/drugs/${currentDrugBarcode}`, formData);
        alert('Drug updated successfully!');
      } else {
        await postData('/drugs', formData);
        alert('Drug added successfully!');
      }
      resetForm();
      loadDrugs();
    } catch (error) {
      console.error('Error saving drug:', error);
      alert('Failed to save drug');
    }
  };

  const handleEdit = (drug) => {
    setIsEditing(true);
    setCurrentDrugBarcode(drug.BARCODE || drug.barcode);
    setFormData({
      name: drug.NAME || drug.name || '',
      type: drug.TYPE || drug.type || '',
      barcode: drug.BARCODE || drug.barcode || '',
      dose: drug.DOSE || drug.dose || '',
      code: drug.CODE || drug.code || '',
      cost_price: drug.COST_PRICE || drug.cost_price || '',
      selling_price: drug.SELLING_PRICE || drug.selling_price || '',
      expiry: drug.EXPIRY || drug.expiry || '',
      company_name: drug.COMPANY_NAME || drug.company_name || '',
      production_date: drug.PRODUCTION_DATE || drug.production_date ? new Date(drug.PRODUCTION_DATE || drug.production_date).toISOString().split('T')[0] : '',
      expiration_date: drug.EXPIRATION_DATE || drug.expiration_date ? new Date(drug.EXPIRATION_DATE || drug.expiration_date).toISOString().split('T')[0] : '',
      place: drug.PLACE || drug.place || '',
      quantity: drug.QUANTITY || drug.quantity || ''
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (barcode) => {
    if (window.confirm('Are you sure you want to delete this drug?')) {
      try {
        await deleteData(`/drugs/${barcode}`);
        alert('Drug deleted successfully!');
        loadDrugs();
      } catch (error) {
        console.error('Error deleting drug:', error);
        alert('Failed to delete drug');
      }
    }
  };

  const resetForm = () => {
    setIsEditing(false);
    setCurrentDrugBarcode(null);
    setFormData({
      name: '', type: '', barcode: '', dose: '', code: '', cost_price: '', selling_price: '',
      expiry: '', company_name: '', production_date: '', expiration_date: '', place: '', quantity: ''
    });
  };

  // Filter Logic
  const filteredDrugs = drugs.filter(drug => {
    const name = (drug.NAME || drug.name || '').toLowerCase();
    const barcode = (drug.BARCODE || drug.barcode || '').toLowerCase();
    const type = (drug.TYPE || drug.type || '').toLowerCase();
    const company = (drug.COMPANY_NAME || drug.company_name || '').toLowerCase();

    const matchesSearch = name.includes(searchQuery.toLowerCase()) || barcode.includes(searchQuery.toLowerCase());
    const matchesType = filterType ? type.includes(filterType.toLowerCase()) : true;
    const matchesCompany = filterCompany ? company.includes(filterCompany.toLowerCase()) : true;

    return matchesSearch && matchesType && matchesCompany;
  });

  // Helper for row styling
  const getRowStyle = (drug) => {
    const qty = parseInt(drug.QUANTITY || drug.quantity || 0);
    const expiryDate = new Date(drug.EXPIRATION_DATE || drug.expiration_date);
    const today = new Date();
    const diffDays = Math.ceil((expiryDate - today) / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return { backgroundColor: '#ffcccc' }; // Expired (Red)
    if (diffDays < 30) return { backgroundColor: '#ffebcc' }; // < 30 days (Orange)
    if (diffDays < 90) return { backgroundColor: '#ffffcc' }; // < 90 days (Yellow)
    if (qty < 10) return { backgroundColor: '#ffe6e6' }; // Low Stock (Light Red)
    return {};
  };

  if (loading) return <div>Loading Drugs...</div>;

  return (
    <div style={{ padding: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
        <h1>Drug Inventory</h1>
        <button
          onClick={loadDrugs}
          style={{ padding: '8px 16px', backgroundColor: '#17a2b8', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
        >
          Refresh Data
        </button>
      </div>

      {/* Search & Filter Bar */}
      <div style={{ marginBottom: '20px', display: 'flex', gap: '10px' }}>
        <input
          placeholder="Search by Name or Barcode"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={{ padding: '8px', flex: 1 }}
        />
        <input
          placeholder="Filter by Type"
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          style={{ padding: '8px' }}
        />
        <input
          placeholder="Filter by Company"
          value={filterCompany}
          onChange={(e) => setFilterCompany(e.target.value)}
          style={{ padding: '8px' }}
        />
      </div>

      {/* Add/Edit Form */}
      <div style={{ marginBottom: '30px', border: '1px solid #ccc', padding: '20px', borderRadius: '8px', backgroundColor: '#f9f9f9' }}>
        <h3>{isEditing ? 'Edit Drug' : 'Add New Drug'}</h3>
        <form onSubmit={handleSubmit} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '15px' }}>
          <input name="name" placeholder="Drug Name" value={formData.name} onChange={handleInputChange} required style={{ padding: '8px' }} />
          <input name="type" placeholder="Type (e.g. Tablet)" value={formData.type} onChange={handleInputChange} required style={{ padding: '8px' }} />
          <input name="barcode" placeholder="Barcode (Optional)" value={formData.barcode} onChange={handleInputChange} style={{ padding: '8px' }} disabled={isEditing} />
          <input name="dose" placeholder="Dose" value={formData.dose} onChange={handleInputChange} style={{ padding: '8px' }} />
          <input name="code" placeholder="Code" value={formData.code} onChange={handleInputChange} style={{ padding: '8px' }} />
          <input name="company_name" placeholder="Company Name" value={formData.company_name} onChange={handleInputChange} required style={{ padding: '8px' }} />
          <input name="place" placeholder="Place (e.g. Rack 1)" value={formData.place} onChange={handleInputChange} required style={{ padding: '8px' }} />
          <input name="quantity" type="number" placeholder="Quantity" value={formData.quantity} onChange={handleInputChange} required style={{ padding: '8px' }} />
          <input name="cost_price" type="number" placeholder="Cost Price" value={formData.cost_price} onChange={handleInputChange} style={{ padding: '8px' }} />
          <input name="selling_price" type="number" placeholder="Selling Price" value={formData.selling_price} onChange={handleInputChange} required style={{ padding: '8px' }} />
          <input name="expiry" placeholder="Expiry String (e.g. 2025)" value={formData.expiry} onChange={handleInputChange} style={{ padding: '8px' }} />

          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <label style={{ fontSize: '12px' }}>Production Date</label>
            <input name="production_date" type="date" value={formData.production_date} onChange={handleInputChange} style={{ padding: '8px' }} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <label style={{ fontSize: '12px' }}>Expiration Date</label>
            <input name="expiration_date" type="date" value={formData.expiration_date} onChange={handleInputChange} style={{ padding: '8px' }} />
          </div>

          <div style={{ gridColumn: 'span 3', display: 'flex', gap: '10px' }}>
            <button type="submit" style={{ padding: '10px 20px', backgroundColor: isEditing ? '#ffc107' : '#28a745', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
              {isEditing ? 'Update Drug' : 'Add Drug'}
            </button>
            {isEditing && (
              <button type="button" onClick={resetForm} style={{ padding: '10px 20px', backgroundColor: '#6c757d', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Drugs List */}
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: '#f2f2f2', textAlign: 'left' }}>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Name</th>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Barcode</th>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Type</th>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Company</th>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Qty</th>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Cost</th>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Price</th>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Margin</th>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Expiry</th>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Place</th>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredDrugs.map((drug, idx) => {
            const cost = parseFloat(drug.COST_PRICE || drug.cost_price || 0);
            const price = parseFloat(drug.SELLING_PRICE || drug.selling_price || 0);
            const margin = price - cost;
            const marginStyle = margin < 0 ? { color: 'red', fontWeight: 'bold' } : { color: 'green' };

            return (
              <tr key={drug.BARCODE || drug.barcode || idx} style={getRowStyle(drug)}>
                <td style={{ padding: '10px', border: '1px solid #ccc' }}>{drug.NAME || drug.name}</td>
                <td style={{ padding: '10px', border: '1px solid #ccc' }}>{drug.BARCODE || drug.barcode}</td>
                <td style={{ padding: '10px', border: '1px solid #ccc' }}>{drug.TYPE || drug.type}</td>
                <td style={{ padding: '10px', border: '1px solid #ccc' }}>{drug.COMPANY_NAME || drug.company_name}</td>
                <td style={{ padding: '10px', border: '1px solid #ccc' }}>{drug.QUANTITY || drug.quantity}</td>
                <td style={{ padding: '10px', border: '1px solid #ccc' }}>{cost.toFixed(2)}</td>
                <td style={{ padding: '10px', border: '1px solid #ccc' }}>{price.toFixed(2)}</td>
                <td style={{ padding: '10px', border: '1px solid #ccc', ...marginStyle }}>{margin.toFixed(2)}</td>
                <td style={{ padding: '10px', border: '1px solid #ccc' }}>
                  {drug.EXPIRATION_DATE || drug.expiration_date ? new Date(drug.EXPIRATION_DATE || drug.expiration_date).toLocaleDateString() : (drug.EXPIRY || drug.expiry)}
                </td>
                <td style={{ padding: '10px', border: '1px solid #ccc' }}>{drug.PLACE || drug.place}</td>
                <td style={{ padding: '10px', border: '1px solid #ccc' }}>
                  <button onClick={() => handleEdit(drug)} style={{ marginRight: '5px', cursor: 'pointer' }}>Edit</button>
                  <button onClick={() => handleDelete(drug.BARCODE || drug.barcode)} style={{ color: 'red', cursor: 'pointer' }}>Delete</button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default DrugsScreen;
