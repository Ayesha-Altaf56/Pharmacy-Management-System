import React, { useEffect, useState } from 'react';
import {
  getAllCompanies, addCompany, updateCompany, deleteCompany,
  getCompanyStats, getCompanyPurchaseHistory
} from '../services/CompanyService';

const CompanyScreen = () => {
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Form State
  const [showModal, setShowModal] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentId, setCurrentId] = useState(null);
  const [formData, setFormData] = useState({ name: '', address: '', phone: '' });

  // Details View State
  const [selectedCompany, setSelectedCompany] = useState(null);
  const [stats, setStats] = useState(null);
  const [purchaseHistory, setPurchaseHistory] = useState([]);
  const [detailsLoading, setDetailsLoading] = useState(false);

  useEffect(() => {
    loadCompanies();
  }, []);

  const loadCompanies = async () => {
    try {
      setLoading(true);
      const data = await getAllCompanies();
      setCompanies(data || []);
    } catch (err) {
      console.error('Error loading companies:', err);
      setError('Failed to load companies');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (isEditing) {
        await updateCompany(currentId, formData);
      } else {
        await addCompany(formData);
      }
      setShowModal(false);
      resetForm();
      loadCompanies();
    } catch (err) {
      console.error('Error saving company:', err);
      alert('Failed to save company');
    }
  };

  const handleEdit = (company) => {
    setFormData({
      name: company.NAME || company.name,
      address: company.ADDRESS || company.address,
      phone: company.PHONE || company.phone
    });
    setCurrentId(company.ID || company.id);
    setIsEditing(true);
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this company?')) return;
    try {
      await deleteCompany(id);
      loadCompanies();
    } catch (err) {
      console.error('Error deleting company:', err);
      alert('Failed to delete company');
    }
  };

  const resetForm = () => {
    setFormData({ name: '', address: '', phone: '' });
    setIsEditing(false);
    setCurrentId(null);
  };

  const handleViewDetails = async (company) => {
    setSelectedCompany(company);
    setDetailsLoading(true);
    try {
      const name = company.NAME || company.name;
      const [statsData, historyData] = await Promise.all([
        getCompanyStats(name),
        getCompanyPurchaseHistory(name)
      ]);
      setStats(statsData);
      setPurchaseHistory(historyData || []);
    } catch (err) {
      console.error('Error loading details:', err);
    } finally {
      setDetailsLoading(false);
    }
  };

  // --- Render Helpers ---

  if (loading) return <div>Loading Companies...</div>;

  return (
    <div style={{ padding: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
        <h1>Company Management</h1>
        <button
          onClick={loadCompanies}
          style={{ padding: '8px 16px', backgroundColor: '#17a2b8', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
        >
          Refresh Data
        </button>
      </div>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <button
        onClick={() => { resetForm(); setShowModal(true); }}
        style={{ marginBottom: '20px', padding: '10px 20px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
      >
        Add New Company
      </button>

      {/* Main Table */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '40px' }}>
        <thead>
          <tr style={{ backgroundColor: '#f8f9fa' }}>
            <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Name</th>
            <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Address</th>
            <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Phone</th>
            <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {companies.map((c, idx) => (
            <tr key={c.ID || c.id || idx}>
              <td style={{ padding: 10, border: '1px solid #dee2e6' }}>{c.NAME || c.name}</td>
              <td style={{ padding: 10, border: '1px solid #dee2e6' }}>{c.ADDRESS || c.address}</td>
              <td style={{ padding: 10, border: '1px solid #dee2e6' }}>{c.PHONE || c.phone}</td>
              <td style={{ padding: 10, border: '1px solid #dee2e6', textAlign: 'center' }}>
                <button onClick={() => handleViewDetails(c)} style={{ marginRight: '5px', padding: '5px 10px', backgroundColor: '#17a2b8', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>View</button>
                <button onClick={() => handleEdit(c)} style={{ marginRight: '5px', padding: '5px 10px', backgroundColor: '#ffc107', color: 'black', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Edit</button>
                <button onClick={() => handleDelete(c.ID || c.id)} style={{ padding: '5px 10px', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Add/Edit Modal */}
      {showModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <div style={{ backgroundColor: 'white', padding: '20px', borderRadius: '8px', width: '400px' }}>
            <h2>{isEditing ? 'Edit Company' : 'Add Company'}</h2>
            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: '15px' }}>
                <label>Name</label>
                <input name="name" value={formData.name} onChange={handleInputChange} required style={{ width: '100%', padding: '8px', marginTop: '5px' }} />
              </div>
              <div style={{ marginBottom: '15px' }}>
                <label>Address</label>
                <input name="address" value={formData.address} onChange={handleInputChange} style={{ width: '100%', padding: '8px', marginTop: '5px' }} />
              </div>
              <div style={{ marginBottom: '15px' }}>
                <label>Phone</label>
                <input name="phone" value={formData.phone} onChange={handleInputChange} style={{ width: '100%', padding: '8px', marginTop: '5px' }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                <button type="button" onClick={() => setShowModal(false)} style={{ padding: '8px 15px', cursor: 'pointer' }}>Cancel</button>
                <button type="submit" style={{ padding: '8px 15px', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Save</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Details Modal */}
      {selectedCompany && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000 }}>
          <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '8px', width: '800px', maxWidth: '90%', maxHeight: '90vh', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <h2>{selectedCompany.NAME || selectedCompany.name} - Details</h2>
              <button onClick={() => setSelectedCompany(null)} style={{ padding: '5px 10px', cursor: 'pointer' }}>Close</button>
            </div>

            {detailsLoading ? <p>Loading details...</p> : (
              <>
                {/* Stats Cards */}
                <div style={{ display: 'flex', gap: '20px', marginBottom: '30px' }}>
                  <div style={{ flex: 1, padding: '15px', backgroundColor: '#e3f2fd', borderRadius: '8px', textAlign: 'center' }}>
                    <h3>Total Products</h3>
                    <p style={{ fontSize: '24px', fontWeight: 'bold' }}>{stats?.productCount || 0}</p>
                  </div>
                  <div style={{ flex: 1, padding: '15px', backgroundColor: '#e8f5e9', borderRadius: '8px', textAlign: 'center' }}>
                    <h3>Total Stock</h3>
                    <p style={{ fontSize: '24px', fontWeight: 'bold' }}>{stats?.totalStock || 0}</p>
                  </div>
                  <div style={{ flex: 1, padding: '15px', backgroundColor: '#fff3e0', borderRadius: '8px', textAlign: 'center' }}>
                    <h3>Total Sales Value</h3>
                    <p style={{ fontSize: '24px', fontWeight: 'bold' }}>${(stats?.totalSales || 0).toFixed(2)}</p>
                  </div>
                </div>

                {/* Purchase History */}
                <h3>Purchase History</h3>
                {purchaseHistory.length === 0 ? <p>No purchase history found.</p> : (
                  <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead>
                      <tr style={{ backgroundColor: '#f2f2f2' }}>
                        <th style={{ padding: 8, border: '1px solid #ccc' }}>Date</th>
                        <th style={{ padding: 8, border: '1px solid #ccc' }}>Drug</th>
                        <th style={{ padding: 8, border: '1px solid #ccc' }}>Qty</th>
                        <th style={{ padding: 8, border: '1px solid #ccc' }}>Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      {purchaseHistory.map((p, idx) => (
                        <tr key={idx}>
                          <td style={{ padding: 8, border: '1px solid #ccc' }}>{new Date(p.PURCHASE_DATE || p.purchase_date).toLocaleDateString()}</td>
                          <td style={{ padding: 8, border: '1px solid #ccc' }}>{p.DRUG_NAME || p.drug_name}</td>
                          <td style={{ padding: 8, border: '1px solid #ccc' }}>{p.QUANTITY || p.quantity}</td>
                          <td style={{ padding: 8, border: '1px solid #ccc' }}>${(p.AMOUNT || p.amount).toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default CompanyScreen;
