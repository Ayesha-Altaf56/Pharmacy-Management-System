import React, { useState, useEffect } from 'react';
import { fetchData, postData, deleteData } from '../utils/api'; // Added deleteData

const SalesScreen = () => {
  const [sales, setSales] = useState([]);
  const [drugs, setDrugs] = useState([]); // Store available drugs
  const [loading, setLoading] = useState(true);

  // New Sale Form State
  const [barcode, setBarcode] = useState('');
  const [quantity, setQuantity] = useState('');
  const [drugDetails, setDrugDetails] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [drugSearch, setDrugSearch] = useState(''); // Filter for inventory table

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [salesData, drugsData] = await Promise.all([
        fetchData('/history-sales'), // Changed to history-sales to get the ID for deletion
        fetchData('/drugs')
      ]);
      setSales(salesData || []);
      setDrugs(drugsData || []);
    } catch (err) {
      console.error('Error fetching data', err);
    } finally {
      setLoading(false);
    }
  };

  // Helper to find drug
  const findDrug = (inputBarcode) => {
    if (!inputBarcode) return null;
    const trimmedBarcode = inputBarcode.trim().toLowerCase();
    return drugs.find(d =>
      (d.BARCODE && d.BARCODE.toLowerCase() === trimmedBarcode) ||
      (d.barcode && d.barcode.toLowerCase() === trimmedBarcode)
    );
  };

  const handleBarcodeBlur = () => {
    const drug = findDrug(barcode);
    if (drug) {
      setDrugDetails(drug);
      setBarcode(drug.BARCODE || drug.barcode);
      setError('');
    } else {
      setDrugDetails(null);
    }
  };

  const handleSale = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    let targetDrug = drugDetails || findDrug(barcode);

    if (!targetDrug) {
      setError(`Drug with barcode "${barcode}" not found.`);
      return;
    }

    try {
      const price = targetDrug.SELLING_PRICE || targetDrug.selling_price || 0;
      const qty = parseInt(quantity);
      const amount = price * qty;

      const response = await postData('/sales', {
        barcode: targetDrug.BARCODE || targetDrug.barcode,
        quantity: qty,
        name: targetDrug.NAME || targetDrug.name,
        price: price,
        amount: amount
      });

      setSuccess(`Sale successful! Total: ${response.sale.amount.toFixed(2)}`);
      setBarcode('');
      setQuantity('');
      setDrugDetails(null);
      loadData(); // Refresh both sales history and stock levels
    } catch (err) {
      console.error('Sale failed:', err);
      setError(err.response?.data?.message || 'Sale failed');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this sale? Stock will be restored.')) return;
    try {
      await deleteData(`/history-sales/${id}`);
      setSuccess('Sale deleted and stock restored.');
      loadData();
    } catch (err) {
      console.error('Delete failed:', err);
      setError('Failed to delete sale.');
    }
  };

  const selectDrug = (drug) => {
    setBarcode(drug.BARCODE || drug.barcode);
    setDrugDetails(drug);
    setError('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Filter drugs for inventory list
  const filteredDrugs = drugs.filter(d =>
    (d.NAME || d.name || '').toLowerCase().includes(drugSearch.toLowerCase()) ||
    (d.BARCODE || d.barcode || '').toLowerCase().includes(drugSearch.toLowerCase())
  );

  if (loading) return <div>Loading...</div>;

  return (
    <div style={{ padding: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
        <h1>Sales Transactions</h1>
        <button
          onClick={loadData}
          style={{ padding: '8px 16px', backgroundColor: '#17a2b8', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
        >
          Refresh Data
        </button>
      </div>

      <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>

        {/* Left Column: New Sale Form */}
        <div style={{ flex: 1, minWidth: '300px' }}>
          <div style={{ marginBottom: '30px', border: '1px solid #ccc', padding: '20px', borderRadius: '8px', backgroundColor: '#f0f8ff' }}>
            <h3>New Sale</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>

              <form onSubmit={handleSale} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <input
                  placeholder="Scan Barcode"
                  value={barcode}
                  onChange={(e) => setBarcode(e.target.value)}
                  onBlur={handleBarcodeBlur}
                  required
                  style={{ padding: '10px' }}
                />
                <input
                  type="number"
                  placeholder="Quantity"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  required
                  min="1"
                  style={{ padding: '10px' }}
                />
                <button type="submit" style={{ padding: '10px', backgroundColor: '#28a745', color: 'white', border: 'none', cursor: 'pointer' }}>
                  Complete Sale
                </button>
              </form>

              {drugDetails && (
                <div style={{ padding: '15px', border: '1px solid #ddd', borderRadius: '4px', backgroundColor: 'white' }}>
                  <h4>Selected Drug</h4>
                  <p><strong>Name:</strong> {drugDetails.NAME || drugDetails.name}</p>
                  <p><strong>Price:</strong> ${(drugDetails.SELLING_PRICE || drugDetails.selling_price || 0).toFixed(2)}</p>
                  <p><strong>Stock:</strong> {drugDetails.QUANTITY || drugDetails.quantity}</p>
                  <p style={{ color: (new Date(drugDetails.EXPIRATION_DATE || drugDetails.expiry) < new Date()) ? 'red' : 'green' }}>
                    <strong>Expiry:</strong> {drugDetails.EXPIRATION_DATE || drugDetails.expiration_date || drugDetails.expiry}
                  </p>
                  {quantity && (
                    <p style={{ marginTop: '10px', fontWeight: 'bold' }}>
                      Total: ${((drugDetails.SELLING_PRICE || drugDetails.selling_price || 0) * quantity).toFixed(2)}
                    </p>
                  )}
                </div>
              )}

              {error && <p style={{ color: 'red' }}>{error}</p>}
              {success && <p style={{ color: 'green' }}>{success}</p>}
            </div>
          </div>
        </div>

        {/* Right Column: Available Inventory */}
        <div style={{ flex: 2, minWidth: '400px' }}>
          <h3>Available Inventory</h3>
          <input
            placeholder="Search Inventory..."
            value={drugSearch}
            onChange={(e) => setDrugSearch(e.target.value)}
            style={{ padding: '8px', marginBottom: '10px', width: '100%' }}
          />
          <div style={{ maxHeight: '400px', overflowY: 'auto', border: '1px solid #ccc' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead style={{ position: 'sticky', top: 0, backgroundColor: '#f2f2f2' }}>
                <tr>
                  <th style={{ padding: 8, textAlign: 'left' }}>Name</th>
                  <th style={{ padding: 8, textAlign: 'left' }}>Barcode</th>
                  <th style={{ padding: 8, textAlign: 'left' }}>Stock</th>
                  <th style={{ padding: 8, textAlign: 'left' }}>Price</th>
                  <th style={{ padding: 8, textAlign: 'left' }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredDrugs.map((d, idx) => (
                  <tr key={idx} style={{ borderBottom: '1px solid #eee' }}>
                    <td style={{ padding: 8 }}>{d.NAME || d.name}</td>
                    <td style={{ padding: 8 }}>{d.BARCODE || d.barcode}</td>
                    <td style={{ padding: 8 }}>{d.QUANTITY || d.quantity}</td>
                    <td style={{ padding: 8 }}>{(d.SELLING_PRICE || d.selling_price || 0).toFixed(2)}</td>
                    <td style={{ padding: 8 }}>
                      <button
                        onClick={() => selectDrug(d)}
                        style={{ padding: '5px 10px', backgroundColor: '#007bff', color: 'white', border: 'none', cursor: 'pointer', fontSize: '12px' }}
                      >
                        Select
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Sales History Table */}
      <h3 style={{ marginTop: '30px' }}>Sales History</h3>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: '#f2f2f2' }}>
            <th style={{ border: '1px solid #ccc', padding: 8 }}>Date</th>
            <th style={{ border: '1px solid #ccc', padding: 8 }}>Barcode</th>
            <th style={{ border: '1px solid #ccc', padding: 8 }}>Drug</th>
            <th style={{ border: '1px solid #ccc', padding: 8 }}>Qty</th>
            <th style={{ border: '1px solid #ccc', padding: 8 }}>Amount</th>
            <th style={{ border: '1px solid #ccc', padding: 8 }}>Action</th>
          </tr>
        </thead>
        <tbody>
          {sales.map((s, idx) => (
            <tr key={s.ID || s.id || idx}>
              <td style={{ border: '1px solid #ccc', padding: 8 }}>{new Date(s.SALE_DATE || s.date).toLocaleString()}</td>
              <td style={{ border: '1px solid #ccc', padding: 8 }}>{s.BARCODE || s.barcode}</td>
              <td style={{ border: '1px solid #ccc', padding: 8 }}>{s.NAME || s.drugName}</td>
              <td style={{ border: '1px solid #ccc', padding: 8 }}>{s.QUANTITY || s.quantity}</td>
              <td style={{ border: '1px solid #ccc', padding: 8 }}>{(s.AMOUNT || s.amount || 0).toFixed(2)}</td>
              <td style={{ border: '1px solid #ccc', padding: 8 }}>
                <button
                  onClick={() => handleDelete(s.ID || s.id)}
                  style={{ padding: '5px 10px', backgroundColor: '#dc3545', color: 'white', border: 'none', cursor: 'pointer', fontSize: '12px' }}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default SalesScreen;
