import React, { useState, useEffect } from 'react';
import { fetchData, postData, deleteData } from '../utils/api';

const SuppliersScreen = () => {
    const [suppliers, setSuppliers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [newSupplier, setNewSupplier] = useState({
        name: '',
        contact_person: '',
        email: '',
        phone: '',
        address: ''
    });

    useEffect(() => {
        loadSuppliers();
    }, []);

    const loadSuppliers = async () => {
        try {
            setLoading(true);
            const data = await fetchData('/suppliers');
            setSuppliers(data || []);
        } catch (error) {
            console.error('Error loading suppliers:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleInputChange = (e) => {
        setNewSupplier({ ...newSupplier, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await postData('/suppliers', newSupplier);
            alert('Supplier added successfully!');
            setNewSupplier({ name: '', contact_person: '', email: '', phone: '', address: '' });
            loadSuppliers();
        } catch (error) {
            console.error('Error adding supplier:', error);
            alert('Failed to add supplier');
        }
    };

    const handleDelete = async (id) => {
        if (window.confirm('Are you sure you want to delete this supplier?')) {
            try {
                await deleteData(`/suppliers/${id}`);
                alert('Supplier deleted successfully!');
                loadSuppliers();
            } catch (error) {
                console.error('Error deleting supplier:', error);
                alert('Failed to delete supplier');
            }
        }
    };

    if (loading) return <div>Loading Suppliers...</div>;

    return (
        <div style={{ padding: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                <h1>Supplier Management</h1>
                <button
                    onClick={loadSuppliers}
                    style={{ padding: '8px 16px', backgroundColor: '#17a2b8', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
                >
                    Refresh Data
                </button>
            </div>

            {/* Add Supplier Form */}
            <div style={{ marginBottom: '30px', border: '1px solid #ccc', padding: '20px', borderRadius: '8px', backgroundColor: '#f9f9f9' }}>
                <h3>Add New Supplier</h3>
                <form onSubmit={handleSubmit} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
                    <input name="name" placeholder="Supplier Name" value={newSupplier.name} onChange={handleInputChange} required style={{ padding: '10px' }} />
                    <input name="contact_person" placeholder="Contact Person" value={newSupplier.contact_person} onChange={handleInputChange} style={{ padding: '10px' }} />
                    <input name="email" type="email" placeholder="Email" value={newSupplier.email} onChange={handleInputChange} style={{ padding: '10px' }} />
                    <input name="phone" placeholder="Phone" value={newSupplier.phone} onChange={handleInputChange} style={{ padding: '10px' }} />
                    <input name="address" placeholder="Address" value={newSupplier.address} onChange={handleInputChange} style={{ padding: '10px', gridColumn: 'span 2' }} />

                    <button type="submit" style={{ gridColumn: 'span 2', padding: '10px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
                        Add Supplier
                    </button>
                </form>
            </div>

            {/* Suppliers List */}
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                    <tr style={{ backgroundColor: '#f2f2f2', textAlign: 'left' }}>
                        <th style={{ padding: '10px', border: '1px solid #ccc' }}>Name</th>
                        <th style={{ padding: '10px', border: '1px solid #ccc' }}>Contact Person</th>
                        <th style={{ padding: '10px', border: '1px solid #ccc' }}>Email</th>
                        <th style={{ padding: '10px', border: '1px solid #ccc' }}>Phone</th>
                        <th style={{ padding: '10px', border: '1px solid #ccc' }}>Address</th>
                        <th style={{ padding: '10px', border: '1px solid #ccc' }}>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {suppliers.map((s) => (
                        <tr key={s.ID || s._id}>
                            <td style={{ padding: '10px', border: '1px solid #ccc' }}>{s.NAME || s.name}</td>
                            <td style={{ padding: '10px', border: '1px solid #ccc' }}>{s.CONTACT_PERSON || s.contact_person}</td>
                            <td style={{ padding: '10px', border: '1px solid #ccc' }}>{s.EMAIL || s.email}</td>
                            <td style={{ padding: '10px', border: '1px solid #ccc' }}>{s.PHONE || s.phone}</td>
                            <td style={{ padding: '10px', border: '1px solid #ccc' }}>{s.ADDRESS || s.address}</td>
                            <td style={{ padding: '10px', border: '1px solid #ccc' }}>
                                <button onClick={() => handleDelete(s.ID || s._id)} style={{ color: 'red', cursor: 'pointer', border: 'none', background: 'none' }}>
                                    Delete
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default SuppliersScreen;
