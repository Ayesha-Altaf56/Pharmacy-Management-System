import React, { useState, useEffect } from 'react';
import { fetchData, postData } from '../utils/api';

const PurchaseScreen = () => {
  const [purchases, setPurchases] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [drugs, setDrugs] = useState([]);
  const [loading, setLoading] = useState(true);

  const [newPurchase, setNewPurchase] = useState({
    supplier_name: '',
    barcode: '', // Will store barcode but user selects Drug Name
    quantity: '',
    price: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [purchasesData, suppliersData, drugsData] = await Promise.all([
        fetchData('/purchases'),
        fetchData('/suppliers'),
        fetchData('/drugs')
      ]);
      setPurchases(purchasesData || []);
      setSuppliers(suppliersData || []);
      setDrugs(drugsData || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    setNewPurchase({ ...newPurchase, [e.target.name]: e.target.value });
  };

  const handleDrugSelect = (e) => {
    const selectedBarcode = e.target.value;
    setNewPurchase({ ...newPurchase, barcode: selectedBarcode });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Find drug details to send (name, type, company)
    const selectedDrug = drugs.find(d => (d.BARCODE || d.barcode) === newPurchase.barcode);
    if (!selectedDrug) {
      alert('Please select a valid drug');
      return;
    }

    const payload = {
      ...newPurchase,
      drugName: selectedDrug.NAME || selectedDrug.name,
      type: selectedDrug.TYPE || selectedDrug.type,
      company_name: selectedDrug.COMPANY_NAME || selectedDrug.company_name,
      quantity: parseInt(newPurchase.quantity),
      price: parseFloat(newPurchase.price)
    };

    try {
      await postData('/purchases', payload);
      alert('Purchase recorded and stock updated!');
      setNewPurchase({ supplier_name: '', barcode: '', quantity: '', price: '' });
      loadData(); // Refresh list
    } catch (error) {
      console.error('Error recording purchase:', error);
      alert('Failed to record purchase');
    }
  };

  if (loading) return <div>Loading Purchases...</div>;

  return (
    <div style={{ padding: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
        <h1>Purchase Management</h1>
        <button
          onClick={loadData}
          style={{ padding: '8px 16px', backgroundColor: '#17a2b8', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
        >
          Refresh Data
        </button>
      </div>

      {/* New Purchase Form */}
      <div style={{ marginBottom: '30px', border: '1px solid #ccc', padding: '20px', borderRadius: '8px', backgroundColor: '#f9f9f9' }}>
        <h3>Record New Purchase</h3>
        <form onSubmit={handleSubmit} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>

          {/* Supplier Select */}
          <div>
            <label style={{ display: 'block', marginBottom: '5px' }}>Supplier</label>
            <select name="supplier_name" value={newPurchase.supplier_name} onChange={handleInputChange} required style={{ width: '100%', padding: '10px' }}>
              <option value="">Select Supplier</option>
              {suppliers.map(s => (
                <option key={s.ID || s._id} value={s.NAME || s.name}>{s.NAME || s.name}</option>
              ))}
            </select>
          </div>

          {/* Drug Select */}
          <div>
            <label style={{ display: 'block', marginBottom: '5px' }}>Drug</label>
            <select name="barcode" value={newPurchase.barcode} onChange={handleDrugSelect} required style={{ width: '100%', padding: '10px' }}>
              <option value="">Select Drug</option>
              {drugs.map(d => (
                <option key={d.BARCODE || d.barcode} value={d.BARCODE || d.barcode}>
                  {d.NAME || d.name} ({d.BARCODE || d.barcode})
                </option>
              ))}
            </select>
          </div>

          <input name="quantity" type="number" placeholder="Quantity" value={newPurchase.quantity} onChange={handleInputChange} required style={{ padding: '10px' }} />
          <input name="price" type="number" step="0.01" placeholder="Unit Price" value={newPurchase.price} onChange={handleInputChange} required style={{ padding: '10px' }} />

          <button type="submit" style={{ gridColumn: 'span 2', padding: '10px', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
            Record Purchase
          </button>
        </form>
      </div>

      {/* Purchase History */}
      <h3>Recent Purchases</h3>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: '#f2f2f2', textAlign: 'left' }}>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Date</th>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Supplier</th>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Drug</th>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Qty</th>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Price</th>
            <th style={{ padding: '10px', border: '1px solid #ccc' }}>Amount</th>
          </tr>
        </thead>
        <tbody>
          {purchases.map((p, idx) => (
            <tr key={p.ID || p._id || idx}>
              <td style={{ padding: '10px', border: '1px solid #ccc' }}>
                {p.PURCHASE_DATE || p.date ? new Date(p.PURCHASE_DATE || p.date).toLocaleDateString() : 'N/A'}
              </td>
              <td style={{ padding: '10px', border: '1px solid #ccc' }}>{p.SUPPLIER_NAME || p.supplier_name}</td>
              <td style={{ padding: '10px', border: '1px solid #ccc' }}>{p.DRUG_NAME || p.drugName}</td>
              <td style={{ padding: '10px', border: '1px solid #ccc' }}>{p.QUANTITY || p.quantity}</td>
              <td style={{ padding: '10px', border: '1px solid #ccc' }}>{p.PRICE || p.price}</td>
              <td style={{ padding: '10px', border: '1px solid #ccc' }}>{p.AMOUNT || p.amount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PurchaseScreen;
