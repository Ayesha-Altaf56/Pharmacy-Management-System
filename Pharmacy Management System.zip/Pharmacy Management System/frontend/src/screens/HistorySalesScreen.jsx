import React, { useEffect, useState } from 'react';
import { getHistorySales } from '../services/HistorySalesService';
import { deleteData } from '../utils/api';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';

const HistorySalesScreen = () => {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Filters
  const [search, setSearch] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Invoice Modal
  const [selectedSale, setSelectedSale] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const params = {};
      if (search) params.search = search;
      if (startDate) params.startDate = startDate;
      if (endDate) params.endDate = endDate;

      const data = await getHistorySales(params);
      setHistory(data || []);
    } catch (err) {
      console.error('Error fetching history sales', err);
      setError('Failed to load sales history.');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    loadData();
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this sale? Stock will be restored.')) return;
    try {
      await deleteData(`/history-sales/${id}`);
      setSuccess('Sale deleted and stock restored.');
      setError('');
      loadData();
    } catch (err) {
      console.error('Delete failed:', err);
      setError('Failed to delete sale.');
      setSuccess('');
    }
  };

  // --- Export Functions ---
  const exportPDF = () => {
    const doc = new jsPDF();
    doc.text('Sales History Report', 14, 10);

    const tableColumn = ["Date", "Barcode", "Drug", "Qty", "Price", "Amount", "User"];
    const tableRows = [];

    history.forEach(sale => {
      const saleData = [
        new Date(sale.SALE_DATE || sale.date).toLocaleDateString(),
        sale.BARCODE || sale.barcode,
        sale.NAME || sale.drugName,
        sale.QUANTITY || sale.quantity,
        (sale.PRICE || sale.price).toFixed(2),
        (sale.AMOUNT || sale.amount).toFixed(2),
        sale.USER_NAME || sale.user_name
      ];
      tableRows.push(saleData);
    });

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 20,
    });

    doc.save('sales_history.pdf');
  };

  const exportExcel = () => {
    const workSheet = XLSX.utils.json_to_sheet(history.map(s => ({
      Date: new Date(s.SALE_DATE || s.date).toLocaleDateString(),
      Time: s.SALE_TIME || s.time,
      Barcode: s.BARCODE || s.barcode,
      Drug: s.NAME || s.drugName,
      Type: s.TYPE || s.type,
      Dose: s.DOSE || s.dose,
      Quantity: s.QUANTITY || s.quantity,
      Price: s.PRICE || s.price,
      Amount: s.AMOUNT || s.amount,
      User: s.USER_NAME || s.user_name
    })));

    const workBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workBook, workSheet, "Sales History");
    XLSX.writeFile(workBook, "sales_history.xlsx");
  };

  // --- Invoice Modal Component ---
  const InvoiceModal = ({ sale, onClose }) => {
    if (!sale) return null;

    return (
      <div style={{
        position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
        backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000
      }}>
        <div style={{
          backgroundColor: 'white', padding: '30px', borderRadius: '8px', width: '400px', maxWidth: '90%',
          boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{ textAlign: 'center', borderBottom: '1px solid #eee', paddingBottom: '10px' }}>INVOICE</h2>

          <div style={{ margin: '20px 0' }}>
            <p><strong>Date:</strong> {new Date(sale.SALE_DATE || sale.date).toLocaleString()}</p>
            <p><strong>Transaction ID:</strong> {sale.ID || sale.id || sale._id}</p>
            <p><strong>Served By:</strong> {sale.USER_NAME || sale.user_name}</p>
            <hr style={{ margin: '15px 0', border: '0', borderTop: '1px dashed #ccc' }} />

            <p><strong>Item:</strong> {sale.NAME || sale.drugName}</p>
            <p><strong>Type:</strong> {sale.TYPE || sale.type} ({sale.DOSE || sale.dose})</p>
            <p><strong>Barcode:</strong> {sale.BARCODE || sale.barcode}</p>

            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '15px' }}>
              <span>Price:</span>
              <span>${(sale.PRICE || sale.price).toFixed(2)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>Quantity:</span>
              <span>x {sale.QUANTITY || sale.quantity}</span>
            </div>
            <hr style={{ margin: '15px 0', border: '0', borderTop: '1px solid #333' }} />

            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', fontSize: '1.2em' }}>
              <span>TOTAL:</span>
              <span>${(sale.AMOUNT || sale.amount).toFixed(2)}</span>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
            <button onClick={() => window.print()} style={{ padding: '8px 15px', cursor: 'pointer' }}>Print</button>
            <button onClick={onClose} style={{ padding: '8px 15px', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Close</button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div style={{ padding: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
        <h1>Sales History</h1>
        <button
          onClick={loadData}
          style={{ padding: '8px 16px', backgroundColor: '#17a2b8', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
        >
          Refresh Data
        </button>
      </div>

      {/* Filters & Actions Bar */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '15px', marginBottom: '20px', alignItems: 'flex-end', backgroundColor: '#f8f9fa', padding: '15px', borderRadius: '8px' }}>
        <form onSubmit={handleSearch} style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', flex: 1 }}>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <label style={{ fontSize: '12px', marginBottom: '5px' }}>Search</label>
            <input
              placeholder="Barcode or Name"
              value={search}
              onChange={e => setSearch(e.target.value)}
              style={{ padding: '8px', border: '1px solid #ccc', borderRadius: '4px' }}
            />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <label style={{ fontSize: '12px', marginBottom: '5px' }}>Start Date</label>
            <input
              type="date"
              value={startDate}
              onChange={e => setStartDate(e.target.value)}
              style={{ padding: '8px', border: '1px solid #ccc', borderRadius: '4px' }}
            />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <label style={{ fontSize: '12px', marginBottom: '5px' }}>End Date</label>
            <input
              type="date"
              value={endDate}
              onChange={e => setEndDate(e.target.value)}
              style={{ padding: '8px', border: '1px solid #ccc', borderRadius: '4px' }}
            />
          </div>
          <button type="submit" style={{ padding: '8px 15px', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', height: '35px', alignSelf: 'flex-end' }}>
            Filter
          </button>
          <button type="button" onClick={() => { setSearch(''); setStartDate(''); setEndDate(''); loadData(); }} style={{ padding: '8px 15px', backgroundColor: '#6c757d', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', height: '35px', alignSelf: 'flex-end' }}>
            Reset
          </button>
        </form>

        <div style={{ display: 'flex', gap: '10px' }}>
          <button onClick={exportPDF} style={{ padding: '8px 15px', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
            Export PDF
          </button>
          <button onClick={exportExcel} style={{ padding: '8px 15px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
            Export Excel
          </button>
        </div>
      </div>

      {error && <p style={{ color: 'red' }}>{error}</p>}
      {success && <p style={{ color: 'green' }}>{success}</p>}

      {loading ? (
        <div>Loading Sales History...</div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '800px' }}>
            <thead>
              <tr style={{ backgroundColor: '#343a40', color: 'white' }}>
                <th style={{ padding: 12, textAlign: 'left' }}>Date</th>
                <th style={{ padding: 12, textAlign: 'left' }}>Time</th>
                <th style={{ padding: 12, textAlign: 'left' }}>Barcode</th>
                <th style={{ padding: 12, textAlign: 'left' }}>Drug Name</th>
                <th style={{ padding: 12, textAlign: 'left' }}>Qty</th>
                <th style={{ padding: 12, textAlign: 'left' }}>Amount</th>
                <th style={{ padding: 12, textAlign: 'left' }}>User</th>
                <th style={{ padding: 12, textAlign: 'center' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {history.length === 0 ? (
                <tr><td colSpan="8" style={{ padding: 20, textAlign: 'center' }}>No sales found.</td></tr>
              ) : (
                history.map((s, idx) => (
                  <tr key={s.ID || s.id || idx} style={{ borderBottom: '1px solid #dee2e6', backgroundColor: idx % 2 === 0 ? 'white' : '#f8f9fa' }}>
                    <td style={{ padding: 12 }}>{new Date(s.SALE_DATE || s.date).toLocaleDateString()}</td>
                    <td style={{ padding: 12 }}>{s.SALE_TIME || s.time}</td>
                    <td style={{ padding: 12 }}>{s.BARCODE || s.barcode}</td>
                    <td style={{ padding: 12 }}>{s.NAME || s.drugName}</td>
                    <td style={{ padding: 12 }}>{s.QUANTITY || s.quantity}</td>
                    <td style={{ padding: 12 }}>${(s.AMOUNT || s.amount || 0).toFixed(2)}</td>
                    <td style={{ padding: 12 }}>{s.USER_NAME || s.user_name}</td>
                    <td style={{ padding: 12, textAlign: 'center', display: 'flex', gap: '5px', justifyContent: 'center' }}>
                      <button
                        onClick={() => setSelectedSale(s)}
                        style={{ padding: '5px 10px', backgroundColor: '#17a2b8', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontSize: '12px' }}
                      >
                        View Invoice
                      </button>
                      <button
                        onClick={() => handleDelete(s.ID || s.id)}
                        style={{ padding: '5px 10px', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontSize: '12px' }}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {selectedSale && <InvoiceModal sale={selectedSale} onClose={() => setSelectedSale(null)} />}
    </div>
  );
};

export default HistorySalesScreen;
