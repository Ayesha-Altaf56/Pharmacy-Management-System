import React, { useEffect, useState } from 'react';
import { getMessageHistory } from '../services/MessageHistoryService';

const MessageHistoryScreen = () => {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const data = await getMessageHistory();
        setMessages(data || []);
      } catch (err) {
        console.error('Error fetching message history', err);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  if (loading) return <div>Loading Message History...</div>;

  return (
    <div style={{ padding: '20px' }}>
      <h1>Message History</h1>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th style={{ border: '1px solid #ccc', padding: 8 }}>From</th>
            <th style={{ border: '1px solid #ccc', padding: 8 }}>To</th>
            <th style={{ border: '1px solid #ccc', padding: 8 }}>Message</th>
          </tr>
        </thead>
        <tbody>
          {messages.map((m, idx) => (
            <tr key={(m.MESSAGE_FROM || m.message_from || '') + idx}>
              <td style={{ border: '1px solid #ccc', padding: 8 }}>{m.MESSAGE_FROM || m.message_from || m.from}</td>
              <td style={{ border: '1px solid #ccc', padding: 8 }}>{m.MESSAGE_TO || m.message_to || m.to}</td>
              <td style={{ border: '1px solid #ccc', padding: 8 }}>{m.MESSAGE_TEXT || m.message_text || m.text}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MessageHistoryScreen;
