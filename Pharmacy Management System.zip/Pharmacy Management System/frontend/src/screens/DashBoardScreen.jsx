import React from 'react';
import { useNavigate } from 'react-router-dom';

const DashboardScreen = () => {
  const navigate = useNavigate();

  const modules = [
    { title: 'Drug Inventory', path: '/drugs', icon: '💊', color: '#28a745', desc: 'Manage drugs & stock' },
    { title: 'Sales Transactions', path: '/sales', icon: '🛒', color: '#007bff', desc: 'Process new sales' },
    { title: 'Sales History', path: '/history-sales', icon: '📄', color: '#17a2b8', desc: 'View past transactions' },
    { title: 'Companies', path: '/companies', icon: '🏢', color: '#6c757d', desc: 'Manage manufacturers' },
    { title: 'Suppliers', path: '/suppliers', icon: '🚚', color: '#6610f2', desc: 'Manage suppliers' },
    { title: 'Purchases', path: '/purchases', icon: '📦', color: '#fd7e14', desc: 'Track purchase orders' },
    { title: 'Expiry Management', path: '/expiry', icon: '⚠️', color: '#dc3545', desc: 'Check expiring stock' },
    { title: 'Inbox and Messaging', path: '/inbox', icon: '✉️', color: '#e83e8c', desc: 'Messages & Notifications' },
    { title: 'User Management', path: '/users', icon: '👥', color: '#343a40', desc: 'Manage staff accounts' },
  ];

  return (
    <div>
      <h1 className="mb-4">Dashboard</h1>

      <div className="dashboard-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', gap: '20px' }}>
        {modules.map((mod, idx) => (
          <div
            key={idx}
            className="card module-card"
            onClick={() => navigate(mod.path)}
            style={{
              cursor: 'pointer',
              transition: 'transform 0.2s, box-shadow 0.2s',
              borderLeft: `5px solid ${mod.color}`,
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center'
            }}
            onMouseEnter={e => {
              e.currentTarget.style.transform = 'translateY(-5px)';
              e.currentTarget.style.boxShadow = '0 10px 20px rgba(0,0,0,0.1)';
            }}
            onMouseLeave={e => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 2px 4px rgba(0,0,0,0.05)';
            }}
          >
            <div style={{ fontSize: '2rem', marginBottom: '10px' }}>{mod.icon}</div>
            <h3 style={{ margin: 0, color: '#333' }}>{mod.title}</h3>
            <p style={{ margin: '5px 0 0', color: '#666', fontSize: '0.9rem' }}>{mod.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DashboardScreen;
