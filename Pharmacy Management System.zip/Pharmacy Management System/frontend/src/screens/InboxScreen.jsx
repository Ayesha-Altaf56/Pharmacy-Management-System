import React, { useEffect, useState } from 'react';
import { getInboxMessages, getSentMessages, sendMessage, deleteMessage } from '../services/InboxService';

const InboxScreen = () => {
  const [messages, setMessages] = useState([]);
  const [activeTab, setActiveTab] = useState('inbox'); // 'inbox' or 'sent'
  const [loading, setLoading] = useState(true);
  const [showCompose, setShowCompose] = useState(false);

  // Current User (Mocked for now, ideally from Auth Context)
  const currentUser = 'Admin';

  const [newMessage, setNewMessage] = useState({ to: '', message: '' });

  useEffect(() => {
    loadMessages();
  }, [activeTab]);

  const loadMessages = async () => {
    setLoading(true);
    try {
      let data;
      if (activeTab === 'inbox') {
        data = await getInboxMessages(currentUser);
      } else {
        data = await getSentMessages(currentUser);
      }
      setMessages(data || []);
    } catch (err) {
      console.error('Error loading messages:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSend = async (e) => {
    e.preventDefault();
    try {
      await sendMessage({ from: currentUser, to: newMessage.to, message: newMessage.message });
      alert('Message sent!');
      setShowCompose(false);
      setNewMessage({ to: '', message: '' });
      if (activeTab === 'sent') loadMessages();
    } catch (err) {
      console.error('Error sending message:', err);
      alert('Failed to send message');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this message?')) return;
    try {
      await deleteMessage(id);
      loadMessages();
    } catch (err) {
      console.error('Error deleting message:', err);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h1>Inbox & Messaging</h1>
        <button
          onClick={() => setShowCompose(true)}
          style={{ padding: '10px 20px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
        >
          Compose Message
        </button>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', borderBottom: '1px solid #ccc', marginBottom: '20px' }}>
        <div
          onClick={() => setActiveTab('inbox')}
          style={{ padding: '10px 20px', cursor: 'pointer', borderBottom: activeTab === 'inbox' ? '3px solid #007bff' : 'none', fontWeight: activeTab === 'inbox' ? 'bold' : 'normal' }}
        >
          Inbox
        </div>
        <div
          onClick={() => setActiveTab('sent')}
          style={{ padding: '10px 20px', cursor: 'pointer', borderBottom: activeTab === 'sent' ? '3px solid #007bff' : 'none', fontWeight: activeTab === 'sent' ? 'bold' : 'normal' }}
        >
          Sent Messages
        </div>
      </div>

      {/* Message List */}
      {loading ? <div>Loading...</div> : (
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ backgroundColor: '#f8f9fa' }}>
              <th style={{ padding: 10, border: '1px solid #dee2e6', textAlign: 'left' }}>{activeTab === 'inbox' ? 'From' : 'To'}</th>
              <th style={{ padding: 10, border: '1px solid #dee2e6', textAlign: 'left' }}>Message</th>
              <th style={{ padding: 10, border: '1px solid #dee2e6', textAlign: 'left' }}>Date</th>
              <th style={{ padding: 10, border: '1px solid #dee2e6', textAlign: 'center' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {messages.length === 0 ? (
              <tr><td colSpan="4" style={{ padding: 20, textAlign: 'center' }}>No messages found.</td></tr>
            ) : (
              messages.map((m) => (
                <tr key={m.ID} style={{ borderBottom: '1px solid #dee2e6' }}>
                  <td style={{ padding: 10 }}>{activeTab === 'inbox' ? m.MESSAGE_FROM : m.MESSAGE_TO}</td>
                  <td style={{ padding: 10 }}>{m.MESSAGE_TEXT}</td>
                  <td style={{ padding: 10 }}>{m.DATE_SENT ? new Date(m.DATE_SENT).toLocaleString() : 'N/A'}</td>
                  <td style={{ padding: 10, textAlign: 'center' }}>
                    <button onClick={() => handleDelete(m.ID)} style={{ color: 'red', border: 'none', background: 'none', cursor: 'pointer' }}>Delete</button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      )}

      {/* Compose Modal */}
      {showCompose && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', justifyContent: 'center', alignItems: 'center'
        }}>
          <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '8px', width: '400px' }}>
            <h2>New Message</h2>
            <form onSubmit={handleSend}>
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>To (User or 'All'):</label>
                <input
                  required
                  value={newMessage.to}
                  onChange={e => setNewMessage({ ...newMessage, to: e.target.value })}
                  style={{ width: '100%', padding: '8px', boxSizing: 'border-box' }}
                  placeholder="e.g. John, or All"
                />
              </div>
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>Message:</label>
                <textarea
                  required
                  value={newMessage.message}
                  onChange={e => setNewMessage({ ...newMessage, message: e.target.value })}
                  style={{ width: '100%', padding: '8px', height: '100px', boxSizing: 'border-box' }}
                />
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                <button type="button" onClick={() => setShowCompose(false)} style={{ padding: '8px 15px', cursor: 'pointer' }}>Cancel</button>
                <button type="submit" style={{ padding: '8px 15px', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Send</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default InboxScreen;
