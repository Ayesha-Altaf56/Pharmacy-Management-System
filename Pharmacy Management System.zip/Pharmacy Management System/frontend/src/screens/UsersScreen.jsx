import React, { useEffect, useState } from 'react';
import { getAllUsers, addUser, updateUser, deleteUser } from '../services/UsersService';

const UsersScreen = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState(null);

  const [formData, setFormData] = useState({
    name: '', username: '', password: '', role: 'Staff',
    dob: '', phone: '', address: '', salary: 0, is_active: 1
  });

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const data = await getAllUsers();
      setUsers(data || []);
    } catch (err) {
      console.error('Error loading users:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingUser) {
        await updateUser(editingUser.ID, formData);
        alert('User updated successfully');
      } else {
        await addUser(formData);
        alert('User added successfully');
      }
      setShowModal(false);
      setEditingUser(null);
      setFormData({ name: '', username: '', password: '', role: 'Staff', dob: '', phone: '', address: '', salary: 0, is_active: 1 });
      loadUsers();
    } catch (err) {
      console.error('Error saving user:', err);
      alert('Failed to save user');
    }
  };

  const handleEdit = (user) => {
    setEditingUser(user);
    setFormData({
      name: user.NAME,
      username: user.USERNAME,
      password: user.PASSWORD, // Usually shouldn't be exposed, but for edit maybe keep empty
      role: user.ROLE,
      dob: user.DOB ? new Date(user.DOB).toISOString().split('T')[0] : '',
      phone: user.PHONE,
      address: user.ADDRESS,
      salary: user.SALARY,
      is_active: user.IS_ACTIVE
    });
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;
    try {
      await deleteUser(id);
      loadUsers();
    } catch (err) {
      console.error('Error deleting user:', err);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h1>User Management</h1>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            onClick={loadUsers}
            style={{ padding: '10px 20px', backgroundColor: '#17a2b8', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
          >
            Refresh
          </button>
          <button
            onClick={() => { setEditingUser(null); setFormData({ name: '', username: '', password: '', role: 'Staff', dob: '', phone: '', address: '', salary: 0, is_active: 1 }); setShowModal(true); }}
            style={{ padding: '10px 20px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
          >
            Add New User
          </button>
        </div>
      </div>

      {loading ? <div>Loading Users...</div> : (
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ backgroundColor: '#f8f9fa' }}>
              <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Name</th>
              <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Username</th>
              <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Role</th>
              <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Phone</th>
              <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Salary</th>
              <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Status</th>
              <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.ID} style={{ borderBottom: '1px solid #dee2e6' }}>
                <td style={{ padding: 10 }}>{u.NAME}</td>
                <td style={{ padding: 10 }}>{u.USERNAME}</td>
                <td style={{ padding: 10 }}>{u.ROLE}</td>
                <td style={{ padding: 10 }}>{u.PHONE}</td>
                <td style={{ padding: 10 }}>${u.SALARY}</td>
                <td style={{ padding: 10 }}>
                  <span style={{ padding: '4px 8px', borderRadius: '4px', backgroundColor: u.IS_ACTIVE ? '#d4edda' : '#f8d7da', color: u.IS_ACTIVE ? '#155724' : '#721c24' }}>
                    {u.IS_ACTIVE ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td style={{ padding: 10, textAlign: 'center' }}>
                  <button onClick={() => handleEdit(u)} style={{ marginRight: '10px', padding: '5px 10px', cursor: 'pointer' }}>Edit</button>
                  <button onClick={() => handleDelete(u.ID)} style={{ padding: '5px 10px', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {/* Modal */}
      {showModal && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', justifyContent: 'center', alignItems: 'center', overflowY: 'auto'
        }}>
          <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '8px', width: '500px', maxHeight: '90vh', overflowY: 'auto' }}>
            <h2>{editingUser ? 'Edit User' : 'Add New User'}</h2>
            <form onSubmit={handleSubmit}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
                <div>
                  <label>Name</label>
                  <input required value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} style={{ width: '100%', padding: '8px' }} />
                </div>
                <div>
                  <label>Username</label>
                  <input required value={formData.username} onChange={e => setFormData({ ...formData, username: e.target.value })} style={{ width: '100%', padding: '8px' }} />
                </div>
                <div>
                  <label>Password</label>
                  <input required={!editingUser} type="password" value={formData.password} onChange={e => setFormData({ ...formData, password: e.target.value })} style={{ width: '100%', padding: '8px' }} />
                </div>
                <div>
                  <label>Role</label>
                  <select value={formData.role} onChange={e => setFormData({ ...formData, role: e.target.value })} style={{ width: '100%', padding: '8px' }}>
                    <option value="Staff">Staff</option>
                    <option value="Admin">Admin</option>
                    <option value="Pharmacist">Pharmacist</option>
                    <option value="Cashier">Cashier</option>
                    <option value="Inventory Manager">Inventory Manager</option>
                  </select>
                </div>
                <div>
                  <label>DOB</label>
                  <input type="date" value={formData.dob} onChange={e => setFormData({ ...formData, dob: e.target.value })} style={{ width: '100%', padding: '8px' }} />
                </div>
                <div>
                  <label>Phone</label>
                  <input value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} style={{ width: '100%', padding: '8px' }} />
                </div>
                <div>
                  <label>Salary</label>
                  <input type="number" value={formData.salary} onChange={e => setFormData({ ...formData, salary: e.target.value })} style={{ width: '100%', padding: '8px' }} />
                </div>
                <div>
                  <label>Status</label>
                  <select value={formData.is_active} onChange={e => setFormData({ ...formData, is_active: parseInt(e.target.value) })} style={{ width: '100%', padding: '8px' }}>
                    <option value={1}>Active</option>
                    <option value={0}>Inactive</option>
                  </select>
                </div>
              </div>
              <div style={{ marginTop: '15px' }}>
                <label>Address</label>
                <textarea value={formData.address} onChange={e => setFormData({ ...formData, address: e.target.value })} style={{ width: '100%', padding: '8px', height: '60px' }} />
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '20px' }}>
                <button type="button" onClick={() => setShowModal(false)} style={{ padding: '8px 15px', cursor: 'pointer' }}>Cancel</button>
                <button type="submit" style={{ padding: '8px 15px', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Save</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UsersScreen;
