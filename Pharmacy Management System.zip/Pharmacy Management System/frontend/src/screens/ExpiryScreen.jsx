import React, { useEffect, useState } from 'react';
import { getExpiryReport, removeExpiredStock } from '../services/ExpiryService';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';

const ExpiryScreen = () => {
  const [report, setReport] = useState({ expired: [], expiring7: [], expiring30: [], expiring90: [], all: [] });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all'); // all, expired, 7, 30, 90

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const data = await getExpiryReport();
      setReport(data || { expired: [], expiring7: [], expiring30: [], expiring90: [], all: [] });
    } catch (err) {
      console.error('Error loading expiry report:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRemove = async (id) => {
    if (!window.confirm('Are you sure you want to remove this stock (Set Quantity to 0)?')) return;
    try {
      await removeExpiredStock(id);
      loadData();
    } catch (err) {
      console.error('Error removing stock:', err);
      alert('Failed to remove stock');
    }
  };

  const getActiveList = () => {
    switch (activeTab) {
      case 'expired': return report.expired;
      case '7': return report.expiring7;
      case '30': return report.expiring30;
      case '90': return report.expiring90;
      default: return report.all;
    }
  };

  // --- Export Functions ---
  const exportPDF = () => {
    const doc = new jsPDF();
    doc.text(`Expiry Report - ${activeTab.toUpperCase()}`, 14, 10);

    const tableColumn = ["Drug", "Barcode", "Company", "Qty", "Expiry Date"];
    const tableRows = [];

    getActiveList().forEach(item => {
      const row = [
        item.NAME || item.name,
        item.BARCODE || item.barcode,
        item.COMPANY_NAME || item.company_name,
        item.QUANTITY || item.quantity,
        new Date(item.EXPIRATION_DATE || item.expiration_date).toLocaleDateString()
      ];
      tableRows.push(row);
    });

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 20,
    });

    doc.save(`expiry_report_${activeTab}.pdf`);
  };

  const exportExcel = () => {
    const workSheet = XLSX.utils.json_to_sheet(getActiveList().map(item => ({
      Drug: item.NAME || item.name,
      Barcode: item.BARCODE || item.barcode,
      Company: item.COMPANY_NAME || item.company_name,
      Quantity: item.QUANTITY || item.quantity,
      ExpiryDate: new Date(item.EXPIRATION_DATE || item.expiration_date).toLocaleDateString()
    })));
    const workBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workBook, workSheet, "Expiry Report");
    XLSX.writeFile(workBook, `expiry_report_${activeTab}.xlsx`);
  };

  if (loading) return <div>Loading Expiry Data...</div>;

  return (
    <div style={{ padding: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
        <h1>Expiry Management</h1>
        <button
          onClick={loadData}
          style={{ padding: '8px 16px', backgroundColor: '#17a2b8', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
        >
          Refresh Data
        </button>
      </div>

      {/* Dashboard Cards */}
      <div style={{ display: 'flex', gap: '20px', marginBottom: '30px', flexWrap: 'wrap' }}>
        <Card title="Already Expired" count={report.expired.length} color="#ffcccc" onClick={() => setActiveTab('expired')} active={activeTab === 'expired'} />
        <Card title="Expiring in 7 Days" count={report.expiring7.length} color="#ffe6cc" onClick={() => setActiveTab('7')} active={activeTab === '7'} />
        <Card title="Expiring in 30 Days" count={report.expiring30.length} color="#fff5cc" onClick={() => setActiveTab('30')} active={activeTab === '30'} />
        <Card title="Expiring in 90 Days" count={report.expiring90.length} color="#e6ffcc" onClick={() => setActiveTab('90')} active={activeTab === '90'} />
        <Card title="All Inventory" count={report.all.length} color="#e6f2ff" onClick={() => setActiveTab('all')} active={activeTab === 'all'} />
      </div>

      {/* Actions */}
      <div style={{ marginBottom: '20px', display: 'flex', gap: '10px' }}>
        <button onClick={exportPDF} style={{ padding: '8px 15px', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Export PDF</button>
        <button onClick={exportExcel} style={{ padding: '8px 15px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Export Excel</button>
      </div>

      {/* List */}
      <h3>{activeTab === 'all' ? 'All Inventory' : activeTab === 'expired' ? 'Expired Items' : `Expiring within ${activeTab} Days`}</h3>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: '#f8f9fa' }}>
            <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Drug Name</th>
            <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Barcode</th>
            <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Company</th>
            <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Quantity</th>
            <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Expiry Date</th>
            <th style={{ padding: 10, border: '1px solid #dee2e6' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {getActiveList().length === 0 ? (
            <tr><td colSpan="6" style={{ padding: 20, textAlign: 'center' }}>No items found in this category.</td></tr>
          ) : (
            getActiveList().map((item, idx) => (
              <tr key={item.BARCODE || idx} style={{ backgroundColor: activeTab === 'expired' ? '#fff5f5' : 'white' }}>
                <td style={{ padding: 10, border: '1px solid #dee2e6' }}>{item.NAME || item.name}</td>
                <td style={{ padding: 10, border: '1px solid #dee2e6' }}>{item.BARCODE || item.barcode}</td>
                <td style={{ padding: 10, border: '1px solid #dee2e6' }}>{item.COMPANY_NAME || item.company_name}</td>
                <td style={{ padding: 10, border: '1px solid #dee2e6' }}>{item.QUANTITY || item.quantity}</td>
                <td style={{ padding: 10, border: '1px solid #dee2e6', color: activeTab === 'expired' ? 'red' : 'inherit', fontWeight: activeTab === 'expired' ? 'bold' : 'normal' }}>
                  {new Date(item.EXPIRATION_DATE || item.expiration_date).toLocaleDateString()}
                </td>
                <td style={{ padding: 10, border: '1px solid #dee2e6', textAlign: 'center' }}>
                  {activeTab === 'expired' && (
                    <button onClick={() => handleRemove(item.BARCODE || item.barcode)} style={{ padding: '5px 10px', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
                      Remove Stock
                    </button>
                  )}
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

const Card = ({ title, count, color, onClick, active }) => (
  <div
    onClick={onClick}
    style={{
      flex: '1 1 200px',
      padding: '20px',
      backgroundColor: color,
      borderRadius: '8px',
      cursor: 'pointer',
      border: active ? '2px solid #333' : '1px solid transparent',
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
    }}
  >
    <h3 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>{title}</h3>
    <p style={{ margin: 0, fontSize: '24px', fontWeight: 'bold' }}>{count}</p>
  </div>
);

export default ExpiryScreen;
