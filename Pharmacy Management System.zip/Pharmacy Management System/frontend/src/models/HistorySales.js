// frontend/models/HistorySales.js
export class HistorySales {
  constructor(ID, SaleID, DrugID, Quantity, TotalPrice, SaleDate) {
    this.ID = ID;
    this.SaleID = SaleID;
    this.DrugID = DrugID;
    this.Quantity = Quantity;
    this.TotalPrice = TotalPrice;
    this.SaleDate = SaleDate;
  }
}
