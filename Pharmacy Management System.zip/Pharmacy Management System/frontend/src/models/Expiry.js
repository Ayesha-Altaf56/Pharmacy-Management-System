// frontend/models/Expiry.js
export class Expiry {
  constructor(ID, DrugID, ExpiryDate) {
    this.ID = ID;
    this.DrugID = DrugID;
    this.ExpiryDate = ExpiryDate;
  }
}
