// frontend/models/Drug.js
export class Drug {
  constructor(ID, Name, CompanyID, Price, Stock) {
    this.ID = ID;
    this.Name = Name;
    this.CompanyID = CompanyID;
    this.Price = Price;
    this.Stock = Stock;
  }
}
