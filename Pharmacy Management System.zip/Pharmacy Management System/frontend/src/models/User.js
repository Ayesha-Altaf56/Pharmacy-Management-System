// frontend/models/Users.js
export class User {
  constructor(ID, Username, Password, Role, Email, Contact) {
    this.ID = ID;
    this.Username = Username;
    this.Password = Password;
    this.Role = Role;
    this.Email = Email;
    this.Contact = Contact;
  }
}
