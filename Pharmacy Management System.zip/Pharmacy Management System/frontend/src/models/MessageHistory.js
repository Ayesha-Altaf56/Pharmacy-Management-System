// frontend/models/MessageHistory.js
export class MessageHistory {
  constructor(ID, SenderID, ReceiverID, Message, Timestamp) {
    this.ID = ID;
    this.SenderID = SenderID;
    this.ReceiverID = ReceiverID;
    this.Message = Message;
    this.Timestamp = Timestamp;
  }
}
