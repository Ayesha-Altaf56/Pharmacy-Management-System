// frontend/models/Company.js
export class Company {
  constructor(ID, Name, Address, Contact) {
    this.ID = ID;
    this.Name = Name;
    this.Address = Address;
    this.Contact = Contact;
  }
}
