// frontend/models/Login.js
export class Login {
  constructor(ID, Username, Password, Role) {
    this.ID = ID;
    this.Username = Username;
    this.Password = Password;
    this.Role = Role;
  }
}
