// frontend/models/Sales.js
export class Sales {
  constructor(ID, DrugID, CustomerID, Quantity, TotalPrice, SaleDate) {
    this.ID = ID;
    this.DrugID = DrugID;
    this.CustomerID = CustomerID;
    this.Quantity = Quantity;
    this.TotalPrice = TotalPrice;
    this.SaleDate = SaleDate;
  }
}
