// frontend/models/Purchase.js
export class Purchase {
  constructor(ID, DrugID, SupplierID, Quantity, TotalPrice, PurchaseDate) {
    this.ID = ID;
    this.DrugID = DrugID;
    this.SupplierID = SupplierID;
    this.Quantity = Quantity;
    this.TotalPrice = TotalPrice;
    this.PurchaseDate = PurchaseDate;
  }
}
