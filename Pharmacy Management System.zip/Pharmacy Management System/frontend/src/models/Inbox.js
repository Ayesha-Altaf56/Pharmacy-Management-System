// frontend/models/Inbox.js
export class Inbox {
  constructor(ID, UserID, Message, Timestamp, ReadStatus) {
    this.ID = ID;
    this.UserID = UserID;
    this.Message = Message;
    this.Timestamp = Timestamp;
    this.ReadStatus = ReadStatus;
  }
}
